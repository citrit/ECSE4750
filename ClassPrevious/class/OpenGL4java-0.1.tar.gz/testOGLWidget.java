/*
 * Leo Chan
 *
 * October 1995
 */

/*
 * we want to use everything defined in the OpenGL package here
 */
import OpenGL.*;

/**
 * this java file defines the main test program for the OpenGL widget
 */

class testOGLWidget {

	public static void main( String args[] ) {
	OpenGLwidget test_widget = null;
	
	/* try to instantiate an OpenGL widget */
	try {
		test_widget = new OpenGLwidget( "My Widget" );
	}
		catch (OpenGLwidgetOpenFailedException e) {
		System.out.println("can't open the OGL library");
		System.exit(-1);
	}
	
	/* initialize the widget */
	test_widget.clearColor( 0.8f, 0.8f, 1.0f, 1.0f );
	test_widget.frontFace( test_widget.CW );
	test_widget.enable( test_widget.DEPTH_TEST );

	int width  = test_widget.getWidth();
	int height = test_widget.getHeight();

	test_widget.viewport( 0, 0, width, height );

	test_widget.matrixMode( test_widget.PROJECTION );
	test_widget.loadIdentity();

	double fov    = 45.0,
		   aspect = width / height,
		   near   = 1.0,
		   far    = 200.0;
	test_widget.perspective( fov, aspect, near, far );

	/* render three rotated cylinders */
	test_widget.clear( test_widget.COLOR_BUFFER_BIT );
	test_widget.clear( test_widget.DEPTH_BUFFER_BIT );

	test_widget.matrixMode( test_widget.MODELVIEW );
	
	if( test_widget.use() == false ) {
		System.out.println("problem in use() method");
	}

	/* enable lighting */
	test_widget.enable( test_widget.LIGHTING );
	float lightArr[] = new float[4];
	lightArr[0] = 1.0f; lightArr[1] = 1.0f; 
	lightArr[2] = 1.0f; lightArr[3] = 1.0f;
	test_widget.light( test_widget.LIGHT0, test_widget.DIFFUSE, lightArr );
	lightArr[0] = 90.0f; lightArr[1] = 90.0f; 
	lightArr[2] = 0.0f; lightArr[3] = 0.0f;
	test_widget.light( test_widget.LIGHT0, test_widget.POSITION, lightArr );
	lightArr[0] = 0.1f; lightArr[1] = 0.1f; 
	lightArr[2] = 0.1f; lightArr[3] = 1.0f;
	test_widget.light( test_widget.LIGHT0, test_widget.AMBIENT, lightArr );
	test_widget.lightModel( test_widget.LIGHT_MODEL_TWO_SIDE, 1 );
	test_widget.enable( test_widget.LIGHT0 );

	/* test materials */
	float farr[] = new float[4];

	test_widget.material( test_widget.FRONT, test_widget.SHININESS, 30.0f );

	farr[0] = 0.0f; farr[1] = 0.0f; farr[2] = 0.0f; farr[3] = 1.0f;
	test_widget.material( test_widget.FRONT, test_widget.SPECULAR, farr );

	farr[0] = 0.0f; farr[1] = 1.0f; farr[2] = 0.0f; farr[3] = 1.0f;
	test_widget.material( test_widget.FRONT, test_widget.DIFFUSE, farr );

	test_widget.material( test_widget.BACK, test_widget.SHININESS, 50.0f );

	farr[0] = 0.0f; farr[1] = 0.0f; farr[2] = 1.0f; farr[3] = 1.0f;
	test_widget.material( test_widget.BACK, test_widget.SPECULAR, farr );

	farr[0] = 1.0f; farr[1] = 1.0f; farr[2] = 0.0f; farr[3] = 1.0f;
	test_widget.material( test_widget.BACK, test_widget.DIFFUSE, farr );

	Cylinder cyl = new Cylinder();

	test_widget.pushMatrix();
        test_widget.translate( 0.0, 0.0, -65.0 );
        test_widget.rotate(  40.0, 0.0, 0.0, 1.0 );
        test_widget.rotate( 190.0, 0.0, 1.0, 0.0 );
        test_widget.rotate( 200.0, 1.0, 0.0, 0.0 );
        test_widget.pushMatrix();
            test_widget.scale( 1.0, 1.0, 10.0 );
			cyl.draw( test_widget );
        test_widget.popMatrix();
        test_widget.pushMatrix();
            test_widget.rotate( 90.0, 0.0, 1.0, 0.0 );
            test_widget.scale( 1.0, 1.0, 10.0 );
			cyl.draw( test_widget );
        test_widget.popMatrix();
        test_widget.pushMatrix();
            test_widget.rotate( 90.0, 1.0, 0.0, 0.0 );
            test_widget.scale( 1.0, 1.0, 10.0 );
			cyl.draw( test_widget );
        test_widget.popMatrix();
    test_widget.popMatrix();

	test_widget.swap();
	test_widget.flush();

	System.out.println( "Hit Enter to exit ..." );
	try {
		System.in.read();
	} 
	catch (java.io.IOException e) {
		System.out.println( "java.io.IOException" );
		System.exit(-1);
	}

	} /* main */

}

class Cylinder {
	public Cylinder() {
	}

	public void draw( OpenGLwidget in ) {
	    in.begin( in.TRIANGLE_STRIP );
            in.normal ( 1.0, 0.0, -5.0 );
            in.vertex ( 1.0, 0.0, -5.0 );
            in.normal ( 1.0, 0.0, -5.0 );
            in.vertex (1.000000, 0.000000, 5.000000);
            in.normal (0.707107, 0.707107, -5.000000);
            in.vertex (0.707107, 0.707107, -5.000000);
            in.normal (0.707107, 0.707107, -5.000000);
            in.vertex (0.707107, 0.707107, 5.000000);
            in.normal (0.000000, 1.000000, -5.000000);
            in.vertex (0.000000, 1.000000, -5.000000);
            in.normal (0.000000, 1.000000, -5.000000);
            in.vertex (0.000000, 1.000000, 5.000000);
            in.normal (-0.707107, 0.707107, -5.00000);
            in.vertex (-0.707107, 0.707107, -5.00000);
            in.normal (-0.707107, 0.707107, -5.00000);
            in.vertex (-0.707107, 0.707107, 5.00000);
            in.normal (-1.000000, 0.000000, -5.000000);
            in.vertex (-1.000000, 0.000000, -5.000000);
            in.normal (-1.000000, 0.000000, -5.000000);
            in.vertex (-1.000000, 0.000000, 5.00000);
            in.normal (-0.707107, -0.707107, -5.000000);
            in.vertex (-0.707107, -0.707107, -5.000000);
            in.normal (-0.707107, -0.707107, -5.000000);
            in.vertex (-0.707107, -0.707107, 5.00000);
            in.normal (0.000000, -1.000000, -5.000000);
            in.vertex (0.000000, -1.000000, -5.000000);
            in.normal (0.000000, -1.000000, -5.000000);
            in.vertex (0.000000, -1.000000, 5.00000);
            in.normal (0.707107, -0.707107, -5.00000);
            in.vertex (0.707107, -0.707107, -5.00000);
            in.normal (0.707107, -0.707107, -5.00000);
            in.vertex (0.707107, -0.707107, 5.000000);
            in.normal (1.000000, 0.000000, -5.00000);
            in.vertex (1.000000, 0.000000, -5.00000);
            in.normal (1.000000, 0.000000, -5.00000);
            in.vertex (1.000000, 0.000000, 5.00000);
		in.end();
	} /* drawCylinder */

}
