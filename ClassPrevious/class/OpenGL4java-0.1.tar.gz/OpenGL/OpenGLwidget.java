/*
 * OpenGLWidget class
 *
 * October 19, 1995, Leo Chan
 *
 * creates an Open GL widget to implement 3D graphics
 */

/*
 * want this file to be part of the OpenGL package
 */
package OpenGL;

/**
 * OpenGLwidget
 *
 * Define a class OpenGLwidget which depends on native methods to implement
 * 3D graphics through OpenGL
 */
public class OpenGLwidget {

	/**
	 * Link with the native OpenGL library.  If we cannot link, an exception
	 * is thrown.  The name of the library is named "OpenGL4java" at the 
	 * Java level, or libOpenGL4java.so at the solaris level.
	 * since this is a static intitializer, it is loaded when the class\
	 * is loaded.
	 */
	static {
		try {
			System.loadLibrary( "OpenGL4java" );
		} catch ( UnsatisfiedLinkError e) {
			System.out.println( "Sorry, can't find the OpenGL4java library");
			System.exit(-1);
		}
	}

	/* class instance data */
	/**
	 * Xwindow data for the widget
	 */
	protected int widgetHandle,	  // unique handle for this widget's window
				  rootHandle,	  // unqiue handle to the root window 
				  width = 500,	  // default width of the widget
				  height = 500,	  // default of the widget
				  RGBAcomponentSize = 4,	// buffer sizes
				  borderWidth = 0;	// default border width

	protected boolean doubleBuffer = true;	

	protected String title = "OpenGL Widget";

	/* OpenGL constants */
	public static final int	CURRENT_BIT      = 0x00000001,
							POINT_BIT        = 0x00000002,
							LINE_BIT     = 0x00000004,
							POLYGON_BIT      = 0x00000008,
							POLYGON_STIPPLE_BIT  = 0x00000010,
							PIXEL_MODE_BIT   = 0x00000020,
							LIGHTING_BIT     = 0x00000040,
							FOG_BIT      = 0x00000080,
							DEPTH_BUFFER_BIT = 0x00000100,
							ACCUM_BUFFER_BIT = 0x00000200,
							STENCIL_BUFFER_BIT   = 0x00000400,
							VIEWPORT_BIT     = 0x00000800,
							TRANSFORM_BIT    = 0x00001000,
							ENABLE_BIT       = 0x00002000,
							COLOR_BUFFER_BIT = 0x00004000,
							HINT_BIT     = 0x00008000,
							EVAL_BIT     = 0x00010000,
							LIST_BIT     = 0x00020000,
							TEXTURE_BIT      = 0x00040000,
							SCISSOR_BIT      = 0x00080000,
							ALL_ATTRIB_BIT   = 0x000fffff,

							/* GLenum */
							/* Boolean values */
							FALSE			= 0,
							TRUE				= 1,

							/* Data types */
							GL_BYTE				= 0x1400,
							GL_UNSIGNED_BYTE		= 0x1401,
							GL_SHORT			= 0x1402,
							GL_UNSIGNED_SHORT		= 0x1403,
							GL_INT				= 0x1404,
							GL_UNSIGNED_INT			= 0x1405,
							GL_FLOAT			= 0x1406,
							GL_2_BYTES			= 0x1407,
							GL_3_BYTES			= 0x1408,
							GL_4_BYTES			= 0x1409,

							/* Primitives */
							LINES			= 0x0001,
							POINTS			= 0x0000,
							LINE_STRIP			= 0x0003,
							LINE_LOOP			= 0x0002,
							TRIANGLES			= 0x0004,
							TRIANGLE_STRIP		= 0x0005,
							TRIANGLE_FAN			= 0x0006,
							QUADS			= 0x0007,
							QUAD_STRIP			= 0x0008,
							POLYGON			= 0x0009,
							EDGE_FLAG			= 0x0B43,

							/* Matrix Mode */
							MATRIX_MODE			= 0x0BA0,
							MODELVIEW			= 0x1700,
							PROJECTION			= 0x1701,
							TEXTURE			= 0x1702,

							/* Points */
							POINT_SMOOTH			= 0x0B10,
							POINT_SIZE			= 0x0B11,
							POINT_SIZE_GRANULARITY 	= 0x0B13,
							POINT_SIZE_RANGE		= 0x0B12,

							/* Lines */
							LINE_SMOOTH			= 0x0B20,
							LINE_STIPPLE			= 0x0B24,
							LINE_STIPPLE_PATTERN		= 0x0B25,
							LINE_STIPPLE_REPEAT		= 0x0B26,
							LINE_WIDTH			= 0x0B21,
							LINE_WIDTH_GRANULARITY	= 0x0B23,
							LINE_WIDTH_RANGE		= 0x0B22,

							/* Polygons */
							POINT			= 0x1B00,
							LINE				= 0x1B01,
							FILL				= 0x1B02,
							CCW				= 0x0901,
							CW				= 0x0900,
							FRONT			= 0x0404,
							BACK				= 0x0405,
							CULL_FACE			= 0x0B44,
							CULL_FACE_MODE		= 0x0B45,
							POLYGON_SMOOTH		= 0x0B41,
							POLYGON_STIPPLE		= 0x0B42,
							FRONT_FACE			= 0x0B46,
							POLYGON_MODE			= 0x0B40,

							/* Display Lists */
							COMPILE			= 0x1300,
							COMPILE_AND_EXECUTE		= 0x1301,
							LIST_BASE			= 0x0B32,
							LIST_INDEX			= 0x0B33,
							LIST_MODE			= 0x0B30,

							/* Depth buffer */
							NEVER			= 0x0200,
							LESS				= 0x0201,
							GEQUAL			= 0x0206,
							LEQUAL			= 0x0203,
							GREATER			= 0x0204,
							NOTEQUAL			= 0x0205,
							EQUAL			= 0x0202,
							ALWAYS			= 0x0207,
							DEPTH_TEST			= 0x0B71,
							DEPTH_BITS			= 0x0D56,
							DEPTH_CLEAR_VALUE		= 0x0B73,
							DEPTH_FUNC			= 0x0B74,
							DEPTH_RANGE			= 0x0B70,
							DEPTH_WRITEMASK		= 0x0B72,
							DEPTH_COMPONENT		= 0x1902,

							/* Lighting */
							LIGHTING			= 0x0B50,
							LIGHT0			= 0x4000,
							LIGHT1			= 0x4001,
							LIGHT2			= 0x4002,
							LIGHT3			= 0x4003,
							LIGHT4			= 0x4004,
							LIGHT5			= 0x4005,
							LIGHT6			= 0x4006,
							LIGHT7			= 0x4007,
							SPOT_EXPONENT		= 0x1205,
							SPOT_CUTOFF			= 0x1206,
							CONSTANT_ATTENUATION		= 0x1207,
							LINEAR_ATTENUATION		= 0x1208,
							QUADRATIC_ATTENUATION	= 0x1209,
							AMBIENT			= 0x1200,
							DIFFUSE			= 0x1201,
							SPECULAR			= 0x1202,
							SHININESS			= 0x1601,
							EMISSION			= 0x1600,
							POSITION			= 0x1203,
							SPOT_DIRECTION		= 0x1204,
							AMBIENT_AND_DIFFUSE		= 0x1602,
							COLOR_INDEXES		= 0x1603,
							LIGHT_MODEL_TWO_SIDE		= 0x0B52,
							LIGHT_MODEL_LOCAL_VIEWER	= 0x0B51,
							LIGHT_MODEL_AMBIENT		= 0x0B53,
							FRONT_AND_BACK		= 0x0408,
							SHADE_MODEL			= 0x0B54,
							FLAT				= 0x1D00,
							SMOOTH			= 0x1D01,
							COLOR_MATERIAL		= 0x0B57,
							COLOR_MATERIAL_FACE		= 0x0B55,
							COLOR_MATERIAL_PARAMETER	= 0x0B56,
							NORMALIZE			= 0x0BA1,

							/* User clipping planes */
							CLIP_PLANE0			= 0x3000,
							CLIP_PLANE1			= 0x3001,
							CLIP_PLANE2			= 0x3002,
							CLIP_PLANE3			= 0x3003,
							CLIP_PLANE4			= 0x3004,
							CLIP_PLANE5			= 0x3005,

							/* Accumulation buffer */
							ACCUM_RED_BITS		= 0x0D58,
							ACCUM_GREEN_BITS		= 0x0D59,
							ACCUM_BLUE_BITS		= 0x0D5A,
							ACCUM_ALPHA_BITS		= 0x0D5B,
							ACCUM_CLEAR_VALUE		= 0x0B80,
							ACCUM			= 0x0100,
							ADD				= 0x0104,
							LOAD				= 0x0101,
							MULT				= 0x0103,
							RETURN			= 0x0102,

							/* Alpha testing */
							ALPHA_TEST			= 0x0BC0,
							ALPHA_TEST_REF		= 0x0BC2,
							ALPHA_TEST_FUNC		= 0x0BC1,

							/* Blending */
							BLEND			= 0x0BE2,
							BLEND_SRC			= 0x0BE1,
							BLEND_DST			= 0x0BE0,
							ZERO				= 0,
							ONE				= 1,
							SRC_COLOR			= 0x0300,
							ONE_MINUS_SRC_COLOR		= 0x0301,
							DST_COLOR			= 0x0306,
							ONE_MINUS_DST_COLOR		= 0x0307,
							SRC_ALPHA			= 0x0302,
							ONE_MINUS_SRC_ALPHA		= 0x0303,
							DST_ALPHA			= 0x0304,
							ONE_MINUS_DST_ALPHA		= 0x0305,
							SRC_ALPHA_SATURATE		= 0x0308,

							/* Render Mode */
							FEEDBACK			= 0x1C01,
							RENDER			= 0x1C00,
							SELECT			= 0x1C02,

							/* Feedback */
							GL_2D				= 0x0600,
							GL_3D				= 0x0601,
							GL_3D_COLOR			= 0x0602,
							GL_3D_COLOR_TEXTURE		= 0x0603,
							GL_4D_COLOR_TEXTURE		= 0x0604,
							POINT_TOKEN			= 0x0701,
							LINE_TOKEN			= 0x0702,
							LINE_RESET_TOKEN		= 0x0707,
							POLYGON_TOKEN		= 0x0703,
							BITMAP_TOKEN			= 0x0704,
							DRAW_PIXEL_TOKEN		= 0x0705,
							COPY_PIXEL_TOKEN		= 0x0706,
							PASS_THROUGH_TOKEN		= 0x0700,

							/* Fog */
							FOG				= 0x0B60,
							FOG_MODE			= 0x0B65,
							FOG_DENSITY			= 0x0B62,
							FOG_COLOR			= 0x0B66,
							FOG_INDEX			= 0x0B61,
							FOG_START			= 0x0B63,
							FOG_END			= 0x0B64,
							LINEAR			= 0x2601,
							EXP				= 0x0800,
							EXP2				= 0x0801,

							/* Logic Ops */
							LOGIC_OP			= 0x0BF1,
							LOGIC_OP_MODE		= 0x0BF0,
							CLEAR			= 0x1500,
							SET				= 0x150F,
							COPY				= 0x1503,
							COPY_INVERTED		= 0x150C,
							NOOP				= 0x1505,
							INVERT			= 0x150A,
							AND				= 0x1501,
							NAND				= 0x150E,
							OR				= 0x1507,
							NOR				= 0x1508,
							XOR				= 0x1506,
							EQUIV			= 0x1509,
							AND_REVERSE			= 0x1502,
							AND_INVERTED			= 0x1504,
							OR_REVERSE			= 0x150B,
							OR_INVERTED			= 0x150D,

							/* Stencil */
							STENCIL_TEST			= 0x0B90,
							STENCIL_WRITEMASK		= 0x0B98,
							STENCIL_BITS			= 0x0D57,
							STENCIL_FUNC			= 0x0B92,
							STENCIL_VALUE_MASK		= 0x0B93,
							STENCIL_REF			= 0x0B97,
							STENCIL_FAIL			= 0x0B94,
							STENCIL_PASS_DEPTH_PASS	= 0x0B96,
							STENCIL_PASS_DEPTH_FAIL	= 0x0B95,
							STENCIL_CLEAR_VALUE		= 0x0B91,
							STENCIL_INDEX		= 0x1901,
							KEEP				= 0x1E00,
							REPLACE			= 0x1E01,
							INCR				= 0x1E02,
							DECR				= 0x1E03,

							/* Buffers, Pixel Drawing/Reading */
							NONE				= 0,
							LEFT				= 0x0406,
							RIGHT			= 0x0407,
							/*FRONT			= 0x0404, */
							/*BACK			= 0x0405, */
							/*FRONT_AND_BACK		= 0x0408, */
							FRONT_LEFT			= 0x0400,
							FRONT_RIGHT			= 0x0401,
							BACK_LEFT			= 0x0402,
							BACK_RIGHT			= 0x0403,
							AUX0				= 0x0409,
							AUX1				= 0x040A,
							AUX2				= 0x040B,
							AUX3				= 0x040C,
							COLOR_INDEX			= 0x1900,
							RED				= 0x1903,
							GREEN			= 0x1904,
							BLUE				= 0x1905,
							ALPHA			= 0x1906,
							LUMINANCE			= 0x1909,
							LUMINANCE_ALPHA		= 0x190A,
							ALPHA_BITS			= 0x0D55,
							RED_BITS			= 0x0D52,
							GREEN_BITS			= 0x0D53,
							BLUE_BITS			= 0x0D54,
							INDEX_BITS			= 0x0D51,
							SUBPIXEL_BITS		= 0x0D50,
							AUX_BUFFERS			= 0x0C00,
							READ_BUFFER			= 0x0C02,
							DRAW_BUFFER			= 0x0C01,
							DOUBLEBUFFER			= 0x0C32,
							STEREO			= 0x0C33,
							BITMAP			= 0x1A00,
							COLOR			= 0x1800,
							DEPTH			= 0x1801,
							STENCIL			= 0x1802,
							DITHER			= 0x0BD0,
							RGB				= 0x1907,
							RGBA				= 0x1908,

							/* Implementation limits */
							MAX_MODELVIEW_STACK_DEPTH	= 0x0D36,
							MAX_PROJECTION_STACK_DEPTH	= 0x0D38,
							MAX_TEXTURE_STACK_DEPTH	= 0x0D39,
							MAX_ATTRIB_STACK_DEPTH	= 0x0D35,
							MAX_NAME_STACK_DEPTH		= 0x0D37,
							MAX_LIST_NESTING		= 0x0B31,
							MAX_LIGHTS			= 0x0D31,
							MAX_CLIP_PLANES		= 0x0D32,
							MAX_VIEWPORT_DIMS		= 0x0D3A,
							MAX_PIXEL_MAP_TABLE		= 0x0D34,
							MAX_EVAL_ORDER		= 0x0D30,
							MAX_TEXTURE_SIZE		= 0x0D33,

							/* Gets */
							ATTRIB_STACK_DEPTH		= 0x0BB0,
							COLOR_CLEAR_VALUE		= 0x0C22,
							COLOR_WRITEMASK		= 0x0C23,
							CURRENT_INDEX		= 0x0B01,
							CURRENT_COLOR		= 0x0B00,
							CURRENT_NORMAL		= 0x0B02,
							CURRENT_RASTER_COLOR		= 0x0B04,
							CURRENT_RASTER_DISTANCE	= 0x0B09,
							CURRENT_RASTER_INDEX		= 0x0B05,
							CURRENT_RASTER_POSITION	= 0x0B07,
							CURRENT_RASTER_TEXTURE_COORDS = 0x0B06,
							CURRENT_RASTER_POSITION_VALID = 0x0B08,
							CURRENT_TEXTURE_COORDS	= 0x0B03,
							INDEX_CLEAR_VALUE		= 0x0C20,
							INDEX_MODE			= 0x0C30,
							INDEX_WRITEMASK		= 0x0C21,
							MODELVIEW_MATRIX		= 0x0BA6,
							MODELVIEW_STACK_DEPTH	= 0x0BA3,
							NAME_STACK_DEPTH		= 0x0D70,
							PROJECTION_MATRIX		= 0x0BA7,
							PROJECTION_STACK_DEPTH	= 0x0BA4,
							RENDER_MODE			= 0x0C40,
							RGBA_MODE			= 0x0C31,
							TEXTURE_MATRIX		= 0x0BA8,
							TEXTURE_STACK_DEPTH		= 0x0BA5,
							VIEWPORT			= 0x0BA2,


							/* Evaluators */
							AUTO_NORMAL			= 0x0D80,
							MAP1_COLOR_4			= 0x0D90,
							MAP1_GRID_DOMAIN		= 0x0DD0,
							MAP1_GRID_SEGMENTS		= 0x0DD1,
							MAP1_INDEX			= 0x0D91,
							MAP1_NORMAL			= 0x0D92,
							MAP1_TEXTURE_COORD_1		= 0x0D93,
							MAP1_TEXTURE_COORD_2		= 0x0D94,
							MAP1_TEXTURE_COORD_3		= 0x0D95,
							MAP1_TEXTURE_COORD_4		= 0x0D96,
							MAP1_VERTEX_3		= 0x0D97,
							MAP1_VERTEX_4		= 0x0D98,
							MAP2_COLOR_4			= 0x0DB0,
							MAP2_GRID_DOMAIN		= 0x0DD2,
							MAP2_GRID_SEGMENTS		= 0x0DD3,
							MAP2_INDEX			= 0x0DB1,
							MAP2_NORMAL			= 0x0DB2,
							MAP2_TEXTURE_COORD_1		= 0x0DB3,
							MAP2_TEXTURE_COORD_2		= 0x0DB4,
							MAP2_TEXTURE_COORD_3		= 0x0DB5,
							MAP2_TEXTURE_COORD_4		= 0x0DB6,
							MAP2_VERTEX_3		= 0x0DB7,
							MAP2_VERTEX_4		= 0x0DB8,
							COEFF			= 0x0A00,
							DOMAIN			= 0x0A02,
							ORDER			= 0x0A01,

							/* Hints */
							FOG_HINT			= 0x0C54,
							LINE_SMOOTH_HINT		= 0x0C52,
							PERSPECTIVE_CORRECTION_HINT	= 0x0C50,
							POINT_SMOOTH_HINT		= 0x0C51,
							POLYGON_SMOOTH_HINT		= 0x0C53,
							DONT_CARE			= 0x1100,
							FASTEST			= 0x1101,
							NICEST			= 0x1102,

							/* Scissor box */
							SCISSOR_TEST			= 0x0C11,
							SCISSOR_BOX			= 0x0C10,

							/* Pixel Mode / Transfer */
							MAP_COLOR			= 0x0D10,
							MAP_STENCIL			= 0x0D11,
							INDEX_SHIFT			= 0x0D12,
							INDEX_OFFSET			= 0x0D13,
							RED_SCALE			= 0x0D14,
							RED_BIAS			= 0x0D15,
							GREEN_SCALE			= 0x0D18,
							GREEN_BIAS			= 0x0D19,
							BLUE_SCALE			= 0x0D1A,
							BLUE_BIAS			= 0x0D1B,
							ALPHA_SCALE			= 0x0D1C,
							ALPHA_BIAS			= 0x0D1D,
							DEPTH_SCALE			= 0x0D1E,
							DEPTH_BIAS			= 0x0D1F,
							PIXEL_MAP_S_TO_S_SIZE	= 0x0CB1,
							PIXEL_MAP_I_TO_I_SIZE	= 0x0CB0,
							PIXEL_MAP_I_TO_R_SIZE	= 0x0CB2,
							PIXEL_MAP_I_TO_G_SIZE	= 0x0CB3,
							PIXEL_MAP_I_TO_B_SIZE	= 0x0CB4,
							PIXEL_MAP_I_TO_A_SIZE	= 0x0CB5,
							PIXEL_MAP_R_TO_R_SIZE	= 0x0CB6,
							PIXEL_MAP_G_TO_G_SIZE	= 0x0CB7,
							PIXEL_MAP_B_TO_B_SIZE	= 0x0CB8,
							PIXEL_MAP_A_TO_A_SIZE	= 0x0CB9,
							PIXEL_MAP_S_TO_S		= 0x0C71,
							PIXEL_MAP_I_TO_I		= 0x0C70,
							PIXEL_MAP_I_TO_R		= 0x0C72,
							PIXEL_MAP_I_TO_G		= 0x0C73,
							PIXEL_MAP_I_TO_B		= 0x0C74,
							PIXEL_MAP_I_TO_A		= 0x0C75,
							PIXEL_MAP_R_TO_R		= 0x0C76,
							PIXEL_MAP_G_TO_G		= 0x0C77,
							PIXEL_MAP_B_TO_B		= 0x0C78,
							PIXEL_MAP_A_TO_A		= 0x0C79,
							PACK_ALIGNMENT		= 0x0D05,
							PACK_LSB_FIRST		= 0x0D01,
							PACK_ROW_LENGTH		= 0x0D02,
							PACK_SKIP_PIXELS		= 0x0D04,
							PACK_SKIP_ROWS		= 0x0D03,
							PACK_SWAP_BYTES		= 0x0D00,
							UNPACK_ALIGNMENT		= 0x0CF5,
							UNPACK_LSB_FIRST		= 0x0CF1,
							UNPACK_ROW_LENGTH		= 0x0CF2,
							UNPACK_SKIP_PIXELS		= 0x0CF4,
							UNPACK_SKIP_ROWS		= 0x0CF3,
							UNPACK_SWAP_BYTES		= 0x0CF0,
							ZOOM_X			= 0x0D16,
							ZOOM_Y			= 0x0D17,

							/* Texture mapping */
							TEXTURE_ENV			= 0x2300,
							TEXTURE_ENV_MODE		= 0x2200,
							TEXTURE_1D			= 0x0DE0,
							TEXTURE_2D			= 0x0DE1,
							TEXTURE_WRAP_S		= 0x2802,
							TEXTURE_WRAP_T		= 0x2803,
							TEXTURE_MAG_FILTER		= 0x2800,
							TEXTURE_MIN_FILTER		= 0x2801,
							TEXTURE_ENV_COLOR		= 0x2201,
							TEXTURE_GEN_S		= 0x0C60,
							TEXTURE_GEN_T		= 0x0C61,
							TEXTURE_GEN_MODE		= 0x2500,
							TEXTURE_BORDER_COLOR		= 0x1004,
							TEXTURE_WIDTH		= 0x1000,
							TEXTURE_HEIGHT		= 0x1001,
							TEXTURE_BORDER		= 0x1005,
							TEXTURE_COMPONENTS		= 0x1003,
							NEAREST_MIPMAP_NEAREST	= 0x2700,
							NEAREST_MIPMAP_LINEAR	= 0x2702,
							LINEAR_MIPMAP_NEAREST	= 0x2700,
							LINEAR_MIPMAP_LINEAR		= 0x2703,
							OBJECT_LINEAR		= 0x2401,
							OBJECT_PLANE			= 0x2501,
							EYE_LINEAR			= 0x2400,
							EYE_PLANE			= 0x2502,
							SPHERE_MAP			= 0x2402,
							DECAL			= 0x2101,
							MODULATE			= 0x2100,
							NEAREST			= 0x2600,
							REPEAT			= 0x2901,
							CLAMP			= 0x2900,
							S				= 0x2000,
							T				= 0x2001,
							R				= 0x2002,
							Q				= 0x2003,
							TEXTURE_GEN_R		= 0x0C62,
							TEXTURE_GEN_Q		= 0x0C63,

							/* Utility */
							VENDOR			= 0x1F00,
							RENDERER			= 0x1F01,
							VERSION			= 0x1F02,
							EXTENSIONS			= 0x1F03,

							/* Errors */
							INVALID_VALUE		= 0x0501,
							INVALID_ENUM			= 0x0500,
							INVALID_OPERATION		= 0x0502,
							STACK_OVERFLOW		= 0x0503,
							STACK_UNDERFLOW		= 0x0504,
							OUT_OF_MEMORY		= 0x0505,

							/* Extensions */
							CONSTANT_COLOR_EXT		= 0x8001,
							ONE_MINUS_CONSTANT_COLOR_EXT	= 0x8002,
							CONSTANT_ALPHA_EXT		= 0x8003,
							ONE_MINUS_CONSTANT_ALPHA_EXT	= 0x8004,
							BLEND_EQUATION_EXT		= 0x8009,
							MIN_EXT			= 0x8007,
							MAX_EXT			= 0x8008,
							FUNC_ADD_EXT			= 0x8006,
							FUNC_SUBTRACT_EXT		= 0x800A,
							FUNC_REVERSE_SUBTRACT_EXT	= 0x800B,
							BLEND_COLOR_EXT		= 0x8005,
							REPLACE_EXT			= 0x8062;

	/**
	 * constructor for the OpenGLwidget object given the name of the
	 * widget.
	 * opens the OpenGLwidget window and sets up the graphics context
	 */
	public OpenGLwidget( String title ) throws OpenGLwidgetOpenFailedException {
		this.title = title;

		if( this.openOpenGLwidget() == false ) {
			throw new OpenGLwidgetOpenFailedException();
		}
	}

	/**
	 * default constructor for the OpenGLwidget object
	 * opens the OpenGLwidget window and sets up the graphics context
	 */
	public OpenGLwidget() throws OpenGLwidgetOpenFailedException {

		if( this.openOpenGLwidget() == false ) {
			throw new OpenGLwidgetOpenFailedException();
		}
	}

	/**
	 * native C function to open the OpenGLwidget
	 */
	protected native boolean openOpenGLwidget();

	/**
	 * get methods
	 */
	public int getWidth() {
		return this.width;
	 }
	public int getHeight() {
		return this.height;
	 }

	/**
	 * use and swap methods are for double buffering
	 */
	public native boolean use();

	/**
	 * use and swap methods are for double buffering
	 */
	public native void swap();

	/*
	 * public OpenGL routines.
	 *
	 * calling these methods will implement the corresponding OpenGL
	 * function in native C code.  The naming conventions are as in
	 * OpenGL.
	 */
	
	/**
	 * ACCUM, LOAD, ADD, MULT and RETURN are accepted op values
	 */
	public native void
	accum( int op, float value );

	/**
	 * NEVER, LESS, EQUAL. LEQUAL, GREATER, NOTEQUAL, ALWAYS are accepted
	 * func values
	 */
	public native void
	alphaFunc( int func, float ref );

	/**
	 * POINTS, LINES, LINE_STRIP, LINE_LOOP, TRIANGLES, TRIANGLE_STRIP,
	 * TRIANGLE_FAN, QUADS, QUAD_STRIP, POLYGON are accepted mode
	 * values
	 */
	public native void
	begin( int mode );

	/**
	 * ZERO, ONE, COLOR, ONE_MINUS_DST_COLOR, SRC_ALPHA, ONE_MINUUS_SRC_ALPHA,
	 * DST_ALPHA, ONE_MINUS_DEST_ALPHA, SRC_ALPHA_SATURATE are accepted
	 * sfactor values.
	 * ZERO, ONE, SRC_COLOR, ONE_MINUS_SRC_COLOR, SRC_ALPHA, 
	 * ONE_MINUS_SRC_ALPHA, DST_ALPHA, ONE_MINUS_DST_ALPHA are accepted
	 * dfactor values
	 */
	public native void
	blendFunc( int sfactor, int dfactor );

	/**
	 * COLOR_BUFFER_BIT, DEPTH_BUFFER_BIT, ACCUM_BUFFER_BIT, 
	 * STENCIL_BUFFER_BIT are accepted values for mask
	 */
	public native void
	clear( int mask );

	public native void
	clearAccum( float red, float green, float blue, float alpha );

	public native void
	clearColor( float red, float green, float blue, float alpha );
	
	public native void
	clearDepth( double depth );

	public native void
	clearIndex( float c );

	public native void
	clearStencil( int s );

	/**
	 * CLIP_PLANEi where is between 0 and MAX_CLIP_PLANES are accepted
	 * values for plane
	 * A,B,C,D are coefficients of the plane equation.
	 */
	public native void
	clipPlane( int plane, double A, double B, double C, double D );

	public void
	color( byte red, byte green, byte blue ) {
		color3b( red, green, blue );
	}
		private native void
		color3b( byte red, byte green, byte blue );

	public void
	color( double red, double green, double blue ) {
		color3d( red, green, blue );
	}
		private native void
		color3d( double red, double green, double blue );

	public void
	color( float red, float green, float blue ) {
		color3f( red, green, blue );
	}
		private native void
		color3f( float red, float green, float blue );

	public void
	color( int red, int green, int blue ) {
		color3i( red, green, blue );
	}
		private native void
		color3i( int red, int green, int blue );

	public void
	color( short red, short green, short blue ) {
		color3s( red, green, blue );
	}
		private native void
		color3s( short red, short green, short blue );

	public void
	color( byte red, byte green, byte blue, byte alpha ) {
		color4b( red, green, blue, alpha );
	}
		private native void
		color4b( byte red, byte green, byte blue, byte alpha );

	public void
	color( double red, double green, double blue, double alpha ) {
		color4d( red, green, blue, alpha );
	}
		private native void
		color4d( double red, double green, double blue, double alpha );

	public void
	color( float red, float green, float blue, float alpha ) {
		color4f( red, green, blue, alpha );
	}
		private native void
		color4f( float red, float green, float blue, float alpha );

	public void
	color( int red, int green, int blue, int alpha ) {
		color4i( red, green, blue, alpha );
	}
		private native void
		color4i( int red, int green, int blue, int alpha );

	public void
	color( short red, short green, short blue, short alpha ) {
		color4s( red, green, blue, alpha );
	}
		private native void
		color4s( short red, short green, short blue, short alpha );

	public native void
	colorMask( boolean red, boolean green, boolean blue, boolean alpha );

	/**
	 * FRONT, BACK, FRONT_AND_BACK are accepted values for face.
	 * EMISSION, AMBIENT, DIFFUSE, SPECULAR, AMBIENT_AND_DIFFUSE are accepted
	 * values for mode
	 */
	public native void
	colorMaterial( int face, int mode );

	/**
	 * COLOR, DEPTH, STENCIL are accepted values for type
	 */
	public native void
	copyPixels( int x, int y, int width, int height, int type );

	/**
	 * FRONT, BACK are accepted values for mode 
	 */
	public native void
	cullFace( int mode );

	/**
	 * NEVER,  LESS, EQUAL, LEQUAL, GREATER, NOTEQUAL, GEQUAL, ALWAYS are
	 * accepted values for func.  
	 * The default is LESS
	 */
	public native void
	depthFunc( int func );

	public native void
	depthMask( boolean flag );

	/**
	 * near and far should be between zero and one
	 */
	public native void
	depthRange( double near, double far );

	/**
	 * NONE, FRONT_LEFT, FRONT_RIGHT, BACK_LEFT, BACK_RIGHT, FRONT, BACK,
	 * LEFT, RIGHT, FRONT_AND_BACK, AUXi are accepted values for mode.
	 */
	public native void
	drawBuffer( int mode );

	public native void
	edgeFlag( boolean flag );

	/**
	 * ALPHA_TEST, AUTO_NORMAL, BLEND, CLIP_PLANE, COLOR_MATERIAL,
	 * CULL_FACE, DEPTH_TEST, DITHER, FOG, LIGHTS, LIGHTING, LINE_SMOOTH,
	 * LINE_STIPPLE, LOGIC_OP, MAP1_COLOR_4, MAP1_INDEX, MAP1_NORMAL,
	 * MAP1_TEXTURE_COORD, MAP1_TEXTURE_COORD_2, MAP1_TEXTURE_COORD_3,
	 * MAP1_TEXTURE_COORD_4, MAP1_VERTEX_3, MAP1_VERTEX_4, 
	 * MAP2_COLOR_4, MAP2_INDEX, MAP2_TEXTURE_COORD_1, 
	 * MAP2_TEXTURE_COORD_2, MAP2_TEXTURE_COORD_3, MAP2_VERTEX_3,
	 * MAP2_VERTEX_4, NORMALIZE, POINT_SMOOTH, POLYGON_SMOOTH,
	 * POLYGON_STIPPLE, SCISSOR_TEST, STENCIL_TEST, TEXTURE_1D,
	 * TEXTURE_2D, TEXTURE_GEN_Q, TEXTURE_GEN_R, TEXTURE_GEN_S,
	 * TEXTURE_GEN_T are accepted values for capability
	 */
	public native void
	enable( int capability );

	public native void
	end();

	public void evalCoord( double u ) {
		evalCoord1d( u );
	}
		private native void
		evalCoord1d( double u );

	public void evalCoord( float u ) {
		evalCoord1f( u );
	}
		private native void
		evalCoord1f( float u );

	public void evalCoord( double u, double v ) {
		evalCoord2d( u,v );
	}
		private native void
		evalCoord2d( double u, double v );

	public void evalCoord( float u, float v ) {
		evalCoord2f( u,v );
	}
		private native void
		evalCoord2f( float u, float v );
	
	/**
	 * POINT and LINE are accepted values for mode
	 */
	public void evalMesh( int mode, int i1, int i2 ) {
		evalMesh1( mode, i1, i2 );
	}
		private native void
		evalMesh1( int mode, int i1, int i2 );

	/**
	 * POINT, LINE and FILL are accepted values for mode
	 */
	public void evalMesh( int mode, int i1, int i2, int j1, int j2 ) {
		evalMesh2( mode, i1, i2, j1, j2 );
	}
		private native void
		evalMesh2( int mode, int i1, int i2, int j1, int j2 );
	
	public void evalPoint( int i ) {
		evalPoint1( i );
	}
		private native void
		evalPoint1( int i );
	
	public void evalPoint( int i, int j ) {
		evalPoint2( i, j );
	}
		private native void
		evalPoint2( int i, int j );

	public native void
	finish();

	public native void
	flush();

	/**
	 * FOG_MODE, FOG_DENSITY, FOG_START, FOG_END, FOG_INDEX are 
	 * accepted values for name
	 */
	public void fog( int name, float param ) {
		fogf( name, param );
	}

		private native void
		fogf( int name, float param );

	/**
	 * FOG_MODE, FOG_DENSITY, FOG_START, FOG_END, FOG_INDEX are 
	 * accepted values for name
	 */
	public void fog( int name, int param ) {
		fogi( name, param );
	}

		private native void
		fogi( int name, int param );

	public void fogColour( float r, float g, float b, float a ) {
		fogColourf( r,g,b,a );
	}
		private native void
		fogColourf( float r, float g, float b, float a );

	public void fogColour( int r, int g, int b, int a ) {
		fogColouri( r,g,b,a );
	}
		private native void
		fogColouri( int r, int g, int b, int a );

	/**
	 * CW, CCW are accepted values for mode 
	 */
	public native void
	frontFace( int mode );

	public native void
	frustum( double left, double right, double bottom, 
			 double top, double near, double far );

	public void get( int pname, boolean params[] ) {
		getb( pname, params );
	}
		private native void
		getb( int pname, boolean params[] );

	public void get( int pname, double params[] ) {
		getd( pname, params );
	}
		private native void
		getd( int pname, double params[] );

	public void get( int pname, float params[] ) {
		getf( pname, params );
	}
		private native void
		getf( int pname, float params[] );

	public void get( int pname, int params[] ) {
		geti( pname, params );
	}
		private native void
		geti( int pname, int params[] );

	/*	
	 * FOG_HINT, LINE_SMOOTH_HINT, PERSPECTIVE_CORRECTION_HINT, 
	 * POINT_SMOOTH_HINT, POLYGON_SMOOTH_HINT are accepted values for target
	 * FASTEST, NICEST, DONT_CARE are accepted values for mode
	 */
	public native void
	hint( int target, int mode );
	
	public void
	index( double c) {
		indexd( c );
	}
		private native void
		indexd( double c );

	public void
	index( float c) {
		indexf( c );
	}
		private native void
		indexf( float c );

	public void
	index( int c) {
		indexi( c );
	}
		private native void
		indexi( int c );

	public void
	index( short c) {
		indexs( c );
	}
		private native void
		indexs( short c );
	
	public native void 
		indexMask( int mask );

	/**
	 * ALPHA_TEST, AUTO_NORMAL, BLEND, CLIP_PLANE, COLOR_MATERIAL,
	 * CULL_FACE, DEPTH_TEST, DITHER, FOG, LIGHTS, LIGHTING, LINE_SMOOTH,
	 * LINE_STIPPLE, LOGIC_OP, MAP1_COLOR_4, MAP1_INDEX, MAP1_NORMAL,
	 * MAP1_TEXTURE_COORD, MAP1_TEXTURE_COORD_2, MAP1_TEXTURE_COORD_3,
	 * MAP1_TEXTURE_COORD_4, MAP1_VERTEX_3, MAP1_VERTEX_4, 
	 * MAP2_COLOR_4, MAP2_INDEX, MAP2_TEXTURE_COORD_1, 
	 * MAP2_TEXTURE_COORD_2, MAP2_TEXTURE_COORD_3, MAP2_VERTEX_3,
	 * MAP2_VERTEX_4, NORMALIZE, POINT_SMOOTH, POLYGON_SMOOTH,
	 * POLYGON_STIPPLE, SCISSOR_TEST, STENCIL_TEST, TEXTURE_1D,
	 * TEXTURE_2D, TEXTURE_GEN_Q, TEXTURE_GEN_R, TEXTURE_GEN_S,
	 * TEXTURE_GEN_T are accepted values for capability
	 */
	public native boolean 
	isEnabled( int capability );

	public void
	light( int light, int pname, float param ) {
		lightf( light, pname, param );
	}

		private native void
		lightf( int light, int pname, float param );
	
	/**
	 * LIGHTi is accepted for light, where i is between 0 and MAX_LIGHTS
	 * SPOT_EXPONENT, SPOT_CUTOFF, CONSTANT_ATTENUATION, LINEAR_ATTENUATION,
	 * QUADRATIC_ATTENUATION are accepted values for pname
	 */
	public void
	light( int light, int pname, int param ) {
		lighti( light, pname, param );
	}
		private native void
		lighti( int light, int pname, int param );

	/**
	 * LIGHTi is accepted for light, where i is between 0 and MAX_LIGHTS
	 * AMBIENT,DIFFUSE, SPECULAR, POSITION,
	 * SPOT_DIRECTION, SPOT_EXPONENT,
	 * SPOT_CUTOFF, CONSTANT_ATTENUATION,
	 * LINEAR_ATTENUATION, QUADRATIC_ATTENUATION are accepted values 
	 * for pname
	 */
	public void
	light( int light, int pname, int params[] ) {
		switch( pname ) {
		case AMBIENT:			// requires four elems
		case DIFFUSE:
		case SPECULAR:
		case POSITION:
			if( params.length >= 4 )
				lightiv( light, pname, params[0], params[1],
							params[2], params[3] );
			else
				return;			// TO DO: throw an exception here
			break;
		case SPOT_DIRECTION:	// requires three elems
		case CONSTANT_ATTENUATION:
		case LINEAR_ATTENUATION:
		case QUADRATIC_ATTENUATION:
			if( params.length >= 3 )
				lightiv( light, pname, params[0], params[1], params[2], 0 );
			else
				return;			// TO DO: throw an exception here
			break;
		case SPOT_EXPONENT:		// requires one elem
		case SPOT_CUTOFF:
			if( params.length >= 1 )
				lightiv( light, pname, params[0], 0,0,0 );
			else
				return;			// TO DO: throw an exception here
			break;
		}
	}
		private native void
		lightiv( int light, int pname, int param1, int param2, int param3,
				 int param4 );

	/**
	 * LIGHTi is accepted for light, where i is between 0 and MAX_LIGHTS
	 * AMBIENT,DIFFUSE, SPECULAR, POSITION,
	 * SPOT_DIRECTION, SPOT_EXPONENT,
	 * SPOT_CUTOFF, CONSTANT_ATTENUATION,
	 * LINEAR_ATTENUATION, QUADRATIC_ATTENUATION are accepted values 
	 * for pname
	 */
	public void
	light( int light, int pname, float params[] ) {
		switch( pname ) {
		case AMBIENT:			// requires four elems
		case DIFFUSE:
		case SPECULAR:
		case POSITION:
			if( params.length >= 4 )
				lightfv( light, pname, params[0], params[1],
							params[2], params[3] );
			else
				return;			// TO DO: throw an exception here
			break;
		case SPOT_DIRECTION:	// requires three elems
		case CONSTANT_ATTENUATION:
		case LINEAR_ATTENUATION:
		case QUADRATIC_ATTENUATION:
			if( params.length >= 3 )
				lightfv( light, pname, params[0], params[1],
							params[2], 0.0f );
			else
				return;			// TO DO: throw an exception here
			break;
		case SPOT_EXPONENT:		// requires one elem
		case SPOT_CUTOFF:
			if( params.length >= 1 )
				lightfv( light, pname, params[0], 0.0f, 0.0f, 0.0f );
			else
				return;			// TO DO: throw an exception here
			break;
		}
	}
		private native void
		lightfv( int light, int pname, float param1, float param2, float param3,
				 float param4 );

	/**
	 * LIGHT_MODEL_LOCAL_VIEWER, LIGHT_MODEL_TWO_SIDE are accepted values
	 * for pname
	 */
	public void 
	lightModel( int pname, int param ) {
		lightModeli( pname, param );
	}
		private native void
		lightModeli( int pname, int param );


	/**
	 * LIGHT_MODEL_LOCAL_VIEWER, LIGHT_MODEL_TWO_SIDE are accepted values
	 * for pname
	 */
	public void 
	lightModel( int pname, float param ) {
		lightModelf( pname, param );
	}
		private native void
		lightModelf( int pname, float param );

	/**
	 * LIGHT_MODEL_AMBIENT, LIGHT_MODEL_LOCAL_VIEWER and
	 * LIGHT_MODEL_TWO_SIDE are accepted values for pname
	 */
	public void 
	lightModel( int pname, int param[] ) {
		switch( pname ) {
		case LIGHT_MODEL_AMBIENT:		// four elems required
			lightModeliv( pname, param );
			break;
		case LIGHT_MODEL_LOCAL_VIEWER:	// single elem required
		case LIGHT_MODEL_TWO_SIDE:
			lightModeliv( pname, param );
		}
	}
		private native void
		lightModeliv( int pname, int param[] );

	/**
	 * LIGHT_MODEL_AMBIENT, LIGHT_MODEL_LOCAL_VIEWER and
	 * LIGHT_MODEL_TWO_SIDE are accepted values for pname
	 */
	public void 
	lightModel( int pname, float param[] ) {
		switch( pname ) {
		case LIGHT_MODEL_AMBIENT:		// four elems required
			lightModelfv( pname, param );
			break;
		case LIGHT_MODEL_LOCAL_VIEWER:	// single elem required
		case LIGHT_MODEL_TWO_SIDE:
			lightModelfv( pname, param );
		}
	}
		private native void
		lightModelfv( int pname, float param[] );

	public native void
	lineStipple( int factor, short pattern );

	public native void
	lineWidth( float width );

	public native void
	loadIdentity();

	public void
	loadMatrix( double darr[] ) {
		if( darr.length == 16 )
			loadMatrixd( darr );
	}
		private native void
		loadMatrixd( double darr[] );

	public void
	loadMatrix( float farr[] ) {
		if( farr.length == 16 )
			loadMatrixf( farr );
	}
		public native void
		loadMatrixf( float farr[] );


	public native void
	loadName( int name );

	/**
	 * CLEAR, SET, COPY, COPY_INVERTED, NOOP, INVERT, AND, NAND,
	 * OR, NOR, XOR, EQUIV, AND_REVERSE, AND_INVERTED, OR_REVERSE,
	 * OR_INVERTED are accepted values for opcode
	 */
	public native void
	logicOp( int opcode );

	public void
	mapGrid1( int un, double u1, double u2 ) {
		mapGrid1d( un, u1, u2 );
	}
		private native void
		mapGrid1d( int un, double u1, double u2 );

	public void
	mapGrid1( int un, float u1, float u2 ) {
		mapGrid1f( un, u1, u2 );
	}
		private native void
		mapGrid1f( int un, float u1, float u2 );

	public void
	mapGrid2( int un, double u1, double u2, int vn, double v1, double v2 ) {
		mapGrid2d( un, u1, u2, vn, v1, v2 );
	}
		private native void
		mapGrid2d( int un, double u1, double u2, int vn, double v1, double v2 );

	public void
	mapGrid2( int un, float u1, float u2, int vn, float v1, float v2 ) {
		mapGrid2f( un, u1, u2, vn, v1, v2 );
	}
		private native void
		mapGrid2f( int un, float u1, float u2, int vn, float v1, float v2 );

	/**
	 * FRONT_AND_BACK, FRONT, BACK are accepted values for face
	 * SHININESS is accepted value for pname
	 */
	public void
	material( int face, int pname, float param ) {
		materialf( face, pname, param );
	}
		private native void
		materialf( int face, int pname, float param );


	/**
	 * FRONT_AND_BACK, FRONT, BACK are accepted values for face
	 * SHININESS is accepted value for pname
	 */
	public void
	material( int face, int pname, int param ) {
		materiali( face, pname, param );
	}
		private native void
		materiali( int face, int pname, int param );


	/**
	 * AMBIENT, DIFFUSE, SPECULAR, EMISSION, SHININESS,
	 * AMBIENT_AND_DIFFUSE, COLOR_INDEXES are valid values for
	 * pname
	 */
	public void
	material( int face, int pname, int params[] ) {
		switch( pname ) {
		case AMBIENT:		// four elems required
		case DIFFUSE:
		case SPECULAR:
		case EMISSION:
		case AMBIENT_AND_DIFFUSE:
			if( params.length >= 4 )
				materialiv( face, pname, params[0], params[1],
							params[2], params[3] );
			else
				return;		// TO DO: throw and exception here
			break;	
		case COLOR_INDEXES:	// three elems required
			if( params.length >= 3 )
				materialiv( face, pname, params[0], params[1],
							params[2], 0 );
			else
				return;		// TO DO: throw an exception here
			break;
		case SHININESS:		// one elem required
			if( params.length >= 1 )
				materialiv( face, pname, params[0], 0,0,0 );
			else
				return;		// TO DO: throw an exception here
			break;
		}
	}

		private native void
		materialiv( int face, int pname, int p1, int p2, int p3, int p4 );

	/**
	 * AMBIENT, DIFFUSE, SPECULAR, EMISSION, SHININESS,
	 * AMBIENT_AND_DIFFUSE, COLOR_INDEXES are valid values for
	 * pname
	 */
	public void
	material( int face, int pname, float params[] ) {
		switch( pname ) {
		case AMBIENT:		// four elems required
		case DIFFUSE:
		case SPECULAR:
		case EMISSION:
		case AMBIENT_AND_DIFFUSE:
			if( params.length >= 4 )
				materialfv( face, pname, params[0], params[1],
							params[2], params[3] );
			else
				return;		// TO DO: throw and exception here
			break;	
		case COLOR_INDEXES:	// three elems required
			if( params.length >= 3 )
				materialfv( face, pname, params[0], params[1],
							params[2], 0.0f );
			else
				return;		// TO DO: throw an exception here
			break;
		case SHININESS:		// one elem required
			if( params.length >= 1 )
				materialfv( face, pname, params[0], 0.0f,0.0f,0.0f );
			else
				return;		// TO DO: throw an exception here
			break;
		}
	}
		private native void
		materialfv( int face, int pname, float p1, float p2, float p3,
					float p4 );

	/**
	 * MODELVIEW, PROJECTION, TEXTURE are accepted values for mode
	 */
	public native void
	matrixMode( int mode );

	public void
	multMatrix( double M[] ) {
		if( M.length >= 16 )
			multMatrixd( M );
	}
		private native void
		multMatrixd( double M[] );

	public void
	multMatrix( float M[] ) {
		if( M.length >= 16 )
			multMatrixf( M );
	}
		private native void
		multMatrixf( float M[] );

	/**
	 * set the current normal vector
	 */
	public void normal ( byte nx, byte ny, byte nz ) {
		normal3b( nx, ny, nz );
	}
		private native void normal3b ( byte nx, byte ny, byte nz );

	public void normal ( double nx, double ny, double nz ) {
		normal3d( nx, ny, nz );
	}
		private native void normal3d ( double nx, double ny, double nz );

	public void normal ( float nx, float ny, float nz ) {
		normal3f( nx, ny, nz );
	}
		private native void normal3f ( float nx, float ny, float nz );

	public void normal ( short nx, short ny, short nz ) {
		normal3s( nx, ny, nz );
	}
		private native void normal3s ( short nx, short ny, short nz );

	public void normal ( int nx, int ny, int nz ) {
		normal3i( nx, ny, nz );
	}
		private native void normal3i ( int nx, int ny, int nz );

	public native void
		ortho( double left, double right, double bottom, double top,
			   double near, double far );
	
	public native void
		passThrough( float token );

	public native void
		perspective( double fov, double aspect, double near, double far );

	public native void
		pointSize( float size );
	
	/**
	 * FRONT, BACK, FRONT_AND_BACK are accepted values for face
	 * POINT, LINE, FILL are accepted values for mode
	 */
	public native void
		polygonMode( int face, int mode );

	/**
	 * ACCUM_BUFFER_BIT, COLOR_BUFFER_BIT, CURRENT_BIT, DEPTH_BUFFER_BIT,
	 * ENABLE_BIT, EVAL_BIT, FOG_BIT, HINT_BIT, LIGHTING_BIT, LINE_BIT,
	 * LIST_BIT, PIXEL_MODE_BIT, POINT_BIT, POLYGON_BIT, POLYGON_STIPPLE_BIT,
	 * SCISSOR_BIT, STENCIL_BUFFER_BIT, TEXTURE_BIT, TRANSFORM_BIT,
	 * VIEWPORT_BIT are accepted values for mask 
	 */
	public native void
	pushAttrib( int mask );

	public native void
	popAttrib();

	public native void
	pushMatrix();

	public native void
	popMatrix();

	public native void
	pushName( int name );

	public native void
	popName();

	
	public void rasterPos( double x, double y ) {
		rasterPos2d( x, y );
	}
		private native void
			rasterPos2d( double x, double y );

	public void rasterPos( float x, float y ) {
		rasterPos2f( x, y );
	}
		private native void
			rasterPos2f( float x, float y );

	public void rasterPos( int x, int y ) {
		rasterPos2i( x, y );
	}
		private native void
			rasterPos2i( int x, int y );

	public void rasterPos( short x, short y ) {
		rasterPos2s( x, y );
	}
		private native void
			rasterPos2s( short x, short y );

	public void rasterPos( double x, double y, double z ) {
		rasterPos3d( x, y, z );
	}
		private native void
			rasterPos3d( double x, double y, double z );

	public void rasterPos( float x, float y, float z ) {
		rasterPos3f( x, y, z );
	}
		private native void
			rasterPos3f( float x, float y, float z );

	public void rasterPos( int x, int y, int z ) {
		rasterPos3i( x, y, z );
	}
		private native void
			rasterPos3i( int x, int y, int z );
	
	public void rasterPos( short x, short y, short z ) {
		rasterPos3s( x, y, z );
	}
		private native void
			rasterPos3s( short x, short y, short z );
	
	/**
	 * FRONT_LEFT, BACK_RIGHT, BACK_LEFT, BACK_RIGHT, FRONT, BACK, LEFT,
	 * RIGHT, AUXi where i is between 0 and AUX_BUFFERS are accepted 
	 * values for mode
	 */
	public native void 
		readBuffer( int mode );
	
	public void rect( double x1, double y1, double x2, double y2 ) {
		rectd( x1, y1, x2, y2 );
	}
		private native void
			rectd( double x1, double y1, double x2, double y2 );
	
	public void rect( float x1, float y1, float x2, float y2 ) {
		rectf( x1, y1, x2, y2 );
	}
		private native void
			rectf( float x1, float y1, float x2, float y2 );
	
	public void rect( int x1, int y1, int x2, int y2 ) {
		rectf( x1, y1, x2, y2 );
	}
		private native void
			recti( int x1, int y1, int x2, int y2 );
	
	/**
	 * RENDER, SELECT, FEEDBACK are accepted values for mode.  The default
	 * is RENDER
	 */
	public native void renderMode( int mode );

	public void rotate( double angle, double x, double y, double z ) {
		rotated( angle, x, y, z );
	}
		private native void 
			rotated( double angle, double x, double y, double z );
			
	public void rotate( float angle, float x, float y, float z ) {
		rotatef( angle, x, y, z );
	}
		private native void 
			rotatef( float angle, float x, float y, float z );
			
	public void scale( double x, double y, double z ) {
		scaled( x, y, z );
	}
		private native void 
			scaled( double x, double y, double z );

	public void scale( float x, float y, float z ) {
		scalef( x, y, z );
	}
		private native void 
			scalef( float x, float y, float z );

	public native void
		scissor( int x, int y, int width, int height );
	
	/**
	 * FLAT, SMOOTH are accepted values for mode
	 */
	public native void
		shadeModel( int mode );
	
	/**
	 * NEVER, LESS, LEQUAL, GREATER, GEQUAL, EQUAL, NOTEQAUL, ALWAYS
	 * are accepted values for func
	 */
	public native void
		stencilFunc( int func, int ref, int mask );

	public native void
		stencilMask( int mask );
	
	/**
	 * KEEP, ZERO, REPLACE, INCR, DECR, INVERT are accepted values for
	 * fail, zfail and zpass
	 */
	public native void
		stencilOp( int fail, int zfail, int zpass );
	
	public void texCoord( double s ) {
		texCoord1d( s );
	}
		private native void
			texCoord1d( double s );
	
	public void texCoord( float s ) {
		texCoord1f( s );
	}
		private native void
			texCoord1f( float s );
	
	public void texCoord( int s ) {
		texCoord1i( s );
	}
		private native void
			texCoord1i( int s );
	
	public void texCoord( short s ) {
		texCoord1s( s );
	}
		private native void
			texCoord1s( short s );
	
	public void texCoord( double s, double t ) {
		texCoord2d( s,t );
	}
		private native void
			texCoord2d( double s, double t );
	
	public void texCoord( float s, float t ) {
		texCoord2f( s,t );
	}
		private native void
			texCoord2f( float s, float t );
	
	public void texCoord( int s, int t ) {
		texCoord2i( s,t );
	}
		private native void
			texCoord2i( int s, int t );
	
	public void texCoord( short s, short t ) {
		texCoord2s( s,t );
	}
		private native void
			texCoord2s( short s, short t );
	
	public void texCoord( double s, double t, double r ) {
		texCoord3d( s,t,r );
	}
		private native void
			texCoord3d( double s, double t, double r );
	
	public void texCoord( float s, float t, float r ) {
		texCoord3f( s,t,r );
	}
		private native void
			texCoord3f( float s, float t, float r );
	
	public void texCoord( int s, int t, int r ) {
		texCoord3i( s,t,r );
	}
		private native void
			texCoord3i( int s, int t, int r );
	
	public void texCoord( short s, short t, short r ) {
		texCoord3s( s,t,r );
	}
		private native void
			texCoord3s( short s, short t, short r );
	
	public void texCoord( double s, double t, double r, double q ) {
		texCoord4d( s,t,r,q );
	}
		private native void
			texCoord4d( double s, double t, double r, double q );
	
	public void texCoord( float s, float t, float r, float q ) {
		texCoord4f( s,t,r,q );
	}
		private native void
			texCoord4f( float s, float t, float r, float q );
	
	public void texCoord( int s, int t, int r, int q ) {
		texCoord4i( s,t,r,q );
	}
		private native void
			texCoord4i( int s, int t, int r, int q );
	
	public void texCoord( short s, short t, short r, short q ) {
		texCoord4s( s,t,r,q );
	}
		private native void
			texCoord4s( short s, short t, short r, short q );

	public void texEnv( int target, int name, float param ) {
		texEnvf( target, name, param );
	}
		private native void
			texEnvf( int target, int name, float param );

	public void texEnv( int target, int name, int param ) {
		texEnvi( target, name, param );
	}
		private native void
			texEnvi( int target, int name, int param );

	public void texGen( int coord, int pname, double param ) {
		texGend( coord, pname, param );
	}
		private native void
			texGend( int coord, int pname, double param );

	public void texGen( int coord, int pname, float param ) {
		texGenf( coord, pname, param );
	}
		private native void
			texGenf( int coord, int pname, float param );

	public void texGen( int coord, int pname, int param ) {
		texGeni( coord, pname, param );
	}
		private native void
			texGeni( int coord, int pname, int param );

	public void translate( double x, double y, double z ) {
		translated( x, y ,z );
	}
		private native void
			translated( double x, double y, double z );

	public void translate( float x, float y, float z ) {
		translatef( x, y ,z );
	}
		private native void
			translatef( float x, float y, float z );

	public void vertex( double x, double y ) {
		vertex2d( x, y );
	}
		private native void
			vertex2d( double x, double y );

	public void vertex( float x, float y ) {
		vertex2f( x, y );
	}
		private native void
			vertex2f( float x, float y );

	public void vertex( int x, int y ) {
		vertex2i( x, y );
	}
		private native void
			vertex2i( int x, int y );

	public void vertex( short x, short y ) {
		vertex2s( x, y );
	}
		private native void
			vertex2s( short x, short y );

	public void vertex( double x, double y, double z ) {
		vertex3d( x, y, z );
	}
		private native void
			vertex3d( double x, double y, double z );

	public void vertex( float x, float y, float z ) {
		vertex3f( x, y, z );
	}
		private native void
			vertex3f( float x, float y, float z );

	public void vertex( int x, int y, int z ) {
		vertex3i( x, y, z );
	}
		private native void
			vertex3i( int x, int y, int z );

	public void vertex( short x, short y, short z ) {
		vertex3s( x, y, z );
	}
		private native void
			vertex3s( short x, short y, short z );

	public void vertex( double x, double y, double z, double w ) {
		vertex4d( x, y, z, w );
	}
		private native void
			vertex4d( double x, double y, double z, double w );

	public void vertex( float x, float y, float z, float w ) {
		vertex4f( x, y, z, w );
	}
		private native void
			vertex4f( float x, float y, float z, float w );

	public void vertex( int x, int y, int z, int w ) {
		vertex4i( x, y, z, w );
	}
		private native void
			vertex4i( int x, int y, int z, int w );

	public void vertex( short x, short y, short z, short w ) {
		vertex4s( x, y, z, w );
	}
		private native void
			vertex4s( short x, short y, short z, short w );
	
	public native void
		viewport( int x, int y, int width, int height );
}
