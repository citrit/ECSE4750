/*
 * want this file to be part of the OpenGL package
 */

package OpenGL;

public class OpenGLwidgetOpenFailedException extends Exception{
}
