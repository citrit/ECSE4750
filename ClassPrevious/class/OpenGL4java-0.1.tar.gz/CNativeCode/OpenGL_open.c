/*
 * Leo Chan -- 1995
 *
 * This file takes care of the C implementation of opening up an
 * X window, assigning an OpenGL graphics context to it, storing that
 * graphics context in the java class data structure.
 *
 * also contains the use() and swap() functions for double buffering
 */

/* 
 * need to include the JAVA internal header files for macros and function
 * prototypes required to maipulated JAVA data structures and functions
 *
 * StubPreamble.h includes the structure and macro definitions neede to
 * convert JAVA data structures into C data structures.
 *
 */

#include "StubPreamble.h"
#include "javaString.h"			/* for converting JAVA strings to C strings */

/*
 * the next thing to include are special headers that were created by
 * JAVAH.  They include the C structure definitions for the JAVA classes
 */
#include "OpenGL_OpenGLwidget.h"

/*--------------------------------------------------------------------------
 * here on in is just regular apple pie C
 */

/*
 * next put any C UNIX specific header files that are necessary to implement
 * this native code
 */			

/* using X for starters -- to be replaced by #include <GL/glx.h> when 
 * we get OGL for the suns
 */
#include <GL/glx.h>

#include "OpenGL_open.h"

/* 
 * global pointer to the widget table -- just an array of widgetTableEntry's
 * since we expect this table to be small in number of entries
 */
static widgetTable gWidgetTable = { 0, NULL };

/*
 * prototypes for functions local to this file scope
 */
static Boolean add_widget_to_table( widgetTableEntry new_widget );
static Display* get_Display_from_widget_table( Window widgetHandle );
static GLXContext get_gc_from_widget_table( Window widgetHandle );
static int get_GC( Display *display, Window win, XVisualInfo *visual,
                   GLXContext *gc );
static XVisualInfo *findVisual( Display *display, int componentsize );
static Colormap allocateColourmap( Display *display, XVisualInfo *visual );

/**
 * add_widget_to_table
 *
 * called to register a new widget in the widget table
 *
 * args: < window -- unique integer identifier (returned by XCreateWindow
 *					 of XCreateSimpleWindow
 */
static Boolean add_widget_to_table( widgetTableEntry new_widget ) {
	if ( gWidgetTable.list_head == NULL ) {
		gWidgetTable.size = 1;
		gWidgetTable.list_head = (widgetTableEntry *)
								 malloc(sizeof(widgetTableEntry));
	} else {
		gWidgetTable.size++;
		gWidgetTable.list_head = (widgetTableEntry *)
								 realloc( gWidgetTable.list_head,
										  gWidgetTable.size * 
										  sizeof(widgetTableEntry) ) ;
	}
	if( gWidgetTable.list_head == NULL )
		return FALSE;

	gWidgetTable.list_head[ gWidgetTable.size - 1 ] = new_widget;

	return TRUE;
}

/**
 * get_Display_from_widget_table
 *
 * returns a pointer to the X Window Display structure of 
 * a widget in the table
 *
 * returns NULL if not widget not found in the table
 */
static Display* get_Display_from_widget_table( Window widgetHandle )
{
	int i;

	/* search for the widget */
	for( i = 0; i < gWidgetTable.size; i++ ) {
		if( gWidgetTable.list_head[i].widgetHandle == widgetHandle ) {
			/* found */
			return (gWidgetTable.list_head[i].display);
		}
	}

	return NULL;
}

/**
 * get_gc_from_widget_table
 *
 * returns a pointer to the X Window GLXContext of a widget in the table
 *
 * returns NULL if not widget not found in the table
 */
static GLXContext get_gc_from_widget_table( Window widgetHandle )
{
	int i;

	/* search for the widget */
	for( i = 0; i < gWidgetTable.size; i++ ) {
		if( gWidgetTable.list_head[i].widgetHandle == widgetHandle ) {
			/* found */
			return (gWidgetTable.list_head[i].gc);
		}
	}
	return NULL;
}

/*
 * OpenGL_OpenGLwidget_openOpenGLwidget
 *
 * the function name is created by JAVAH to reflect the package and class
 * names of the JAVA object that called this native code.
 *
 * the parameter is a handle to the OpenGL_OpenGLwidget object -- 
 * the data portion
 * followed by the method table for the class.
 */
long OpenGL_OpenGLwidget_openOpenGLwidget( struct HOpenGL_OpenGLwidget *this)
{
	widgetTableEntry widget_entry;	/* new widget entry for our local table */
	XSetWindowAttributes attribs;
	XVisualInfo     *visual;    	/* pointer to x visual information */
	char *buf;

	widget_entry.display = XOpenDisplay( NULL );
	if( widget_entry.display == NULL ) {
		/* return FALSE to tell JAVA that we couldn't open.  could also use
		 * SignalError() here if we would prefer to throw an exception
		 */
		 return FALSE;
	}

	/* Check to see if the Xserver supports OpenGL */
	if( !glXQueryExtension(widget_entry.display, (int *) 0, (int *) 0) ) {
		return FALSE;
	}

	/* try to find an appropriate OpenGL visual */
	visual = findVisual( widget_entry.display, unhand(this)->RGBAcomponentSize);
	if ( visual == NULL ) {
		return FALSE;
	}

	/* initialize the x stuff */
	widget_entry.screen = DefaultScreen( widget_entry.display );
	unhand(this)->rootHandle = RootWindow( widget_entry.display, 
									widget_entry.screen );

	attribs.event_mask = KeyPressMask | ExposureMask;
	attribs.border_pixel = BlackPixel(widget_entry.display,widget_entry.screen);
	attribs.colormap = allocateColourmap( widget_entry.display, visual );

	/* banzai!!  let's try to create an X window now and pass back the
	 * Window identifier to JAVA so it can access it in the future
	 */
	
	unhand(this)->widgetHandle = XCreateWindow (
							  widget_entry.display, 
							  unhand(this)->rootHandle,
							  0, 0,					/* window position */
							  (unsigned int)(unhand(this)->width),
							  (unsigned int)(unhand(this)->height),
							  (unsigned int)(unhand(this)->borderWidth),
							  visual->depth,
							  InputOutput,
							  visual->visual,
							  CWColormap | CWEventMask | CWBorderPixel,
							  &attribs );
	
	/* must also register this window identifier in the widget table for */
	/* future reference */
	widget_entry.widgetHandle = unhand(this)->widgetHandle;

	/* check to see if the JAVA user has specified a name to name the window */
	/* need to convert the JAVA string to a C string first */
	/* makeCString() temporarily allocates space for the returned string */
	/* it is automatically freed when all references to the returned string */
	/* are gone.  see doc:///doc/rpi/rpi_14.html */

	buf = makeCString( unhand(this)->title );
	
	if( buf )
		XStoreName( widget_entry.display, unhand(this)->widgetHandle, buf );

	/* mask the input so we only get certain XEvents to map back to JAVA */
	XSelectInput( widget_entry.display, unhand(this)->widgetHandle,
				  ExposureMask | KeyPressMask | ButtonPressMask | 
				  ButtonReleaseMask );

	/* get the graphics context for this widget */
	if( get_GC( widget_entry.display, widget_entry.widgetHandle,
			    visual, &(widget_entry.gc) ) != 0 )	{
		 XDestroyWindow( widget_entry.display, widget_entry.widgetHandle );
		 XCloseDisplay( widget_entry.display );
		 return FALSE;
	}

	/* we are now done with the visual so we should free the storage */
	XFree( visual );

	/* now that we have all the X window information, put store it in
	 * the widget table for subsequent use
	 */
	if ( !(add_widget_to_table( widget_entry ) ) ) {
		XDestroyWindow( widget_entry.display, widget_entry.widgetHandle );
        XCloseDisplay( widget_entry.display );
		return FALSE;
	}

	/* XClearWindow( widget_entry.display, widget_entry.widgetHandle ); */
	/* XFlush( widget_entry.display ); */
	XMapWindow( widget_entry.display, widget_entry.widgetHandle );

	return TRUE;
}

/*boolean*/ long OpenGL_OpenGLwidget_use( struct HOpenGL_OpenGLwidget *this )
{
	Window win = unhand(this)->widgetHandle;
	Display *disp;
	GLXContext gc;

	disp = get_Display_from_widget_table( win );
	if( !disp )
		return 0;

	gc = get_gc_from_widget_table( win );
	if( !gc )
		return 0;
	
	if( !glXMakeCurrent( disp, win, gc ) ) {
		return 0;
	}
	
	return 1;
}

void OpenGL_OpenGLwidget_swap( struct HOpenGL_OpenGLwidget *this )
{
	Display *disp;
	Window win = unhand(this)->widgetHandle;
	
	disp = get_Display_from_widget_table( win );
	if( !disp )
		return; 

	if( unhand(this)->doubleBuffer == 0L ) {
		/* don't double buffer */
		glXWaitGL();
	} else {
		glXSwapBuffers( disp, win );
	}
}

/*
 * Name      : XVisualInfo *findVisual( Display *display, int componentsize )
 *
 * Parameters: display       - the X display to search for a visual on
 *             componentsize - the number of bits for red, green, blue and
 *                             depth that the visual must support
 *
 * Returns   : XVisualInfo * - a pointer to an X visual info structure
 *                             containing the visual found.
 *
 * Purpose   :  Find an OpenGL visual that is at least componentsize bits
 *              of colour per red, green and blue. The visual will also be
 *              double buffered. The visual is
 *              returned as a pointer. If the pointer is NULL then there was
 *              an error and the correct visual could not be found.
 */
static XVisualInfo *findVisual( Display *display, int componentsize )
{
    int visualAttribList[9];
    XVisualInfo *visual;

    /* Ask GLX for a visual that matches the attributes we want: Single
       buffered and RGB with at least 4 bits for each component */
    visualAttribList[0] = GLX_RGBA;
    visualAttribList[1] = GLX_RED_SIZE;
    visualAttribList[2] = componentsize;
    visualAttribList[3] = GLX_GREEN_SIZE;
    visualAttribList[4] = componentsize;
    visualAttribList[5] = GLX_BLUE_SIZE;
    visualAttribList[6] = componentsize;
    visualAttribList[7] = GLX_DOUBLEBUFFER;
    visualAttribList[8] = None;

    visual = glXChooseVisual( display,
                              DefaultScreen( display ),
                              visualAttribList );
    return( visual );
}

/*
 * Name      : int get_GC( Window win, XVisualInfo *visual, GLXContext *gc )
 *
 * Parameters: win    - the X window use to the OpenGL context with
 *             visual - The visual to create the context for
 *             gc     - a pointer to a GLXContext structure. This is how
 *                      the created context will be returned to the caller
 *
 * Returns   : a pointer to a created GLXContext is returned through the
 *             gc argument.
 *             int - an error code: 0 means everything was fine
 *                                 -1 context creation failed
 *                                 -2 context/window association failed
 *
 * Purpose   : create an X window Graphics context and assocaite it with
 *             the window. It returns 0 if everything was fine, -1 if the
 *             context could not be created, -2 if the context could not
 *             be associated with the window
 */
static int get_GC( Display *display, Window win, XVisualInfo *visual,
                   GLXContext *gc )
{
    *gc = glXCreateContext( display, visual, None, True );

    /* check if the context could be created */
    if( *gc == NULL ) {
        return( -1 );
    }
    /* associated the context with the X window */
    if( glXMakeCurrent( display, win, *gc ) == False) {
        glXDestroyContext( display, *gc );
        return( -2 );
    }

    return 0;
}

/*
 * Name      : Colormap allocateColourmap( Display *display,
 *                                         XVisualInfo *visual )
 *
 * Parameters: display - the X display to create the colormap on
 *             visual  - The visual to create the colormap for
 *
 * Returns   : colormap - an xwindow colormap allocated for use with the
 *                        supplied visual and display
 *
 * Purpose   : create a colour map to use with the X window. Even though
 *             the visual may be a 24 bit TrueColor visual, you still need
 *             a colour map if the visual is not the default visual used by
 *             the window manager. Most OpenGL visuals are not the default
 *             visual used by the window manager so just to be safe we
 *              always allocate a colour map.
 */
static Colormap allocateColourmap( Display *display, XVisualInfo *visual )
{
    /* now we have the visual with the best depth so lets make a colour map
       for it.  we use allocnone because this is a true colour visual and
       the colour map is read only anyway. This must be done because we
       cannot call XCreateSimpleWindow. This is really the gross part of
       working with X windows. */
    return( XCreateColormap( display,
                             RootWindow( display, visual->screen ),
                             visual->visual,
                             AllocNone ) );
}


