/*
 * Leo Chan -- 1995
 * lchan@cgl.uwaterloo.ca
 *
 * This mammoth C file takes care of all the native implementation for the
 * bulk of OpenGL commands
 */

/* 
 * need to include the JAVA internal header files for macros and function
 * prototypes required to maipulated JAVA data structures and functions
 *
 * StubPreamble.h includes the structure and macro definitions neede to
 * convert JAVA data structures into C data structures.
 *
 */

#include "StubPreamble.h"

/*
 * the next thing to include are special headers that were created by
 * JAVAH.  They include the C structure definitions for the JAVA classes
 */
#include "OpenGL_OpenGLwidget.h"

/*--------------------------------------------------------------------------
 * here on in is just regular apple pie C
 */

/*
 * next put any C UNIX specific header files that are necessary to implement
 * this native code
 */			

#include <GL/glx.h>

/**
 * herein lies the native JAVA methods for the OpenGL functions.  
 */
 void OpenGL_OpenGLwidget_accum(struct HOpenGL_OpenGLwidget *this,
								long op,
								float value )
{
	switch( op ) {
		case OpenGL_OpenGLwidget_ACCUM:
			glAccum( GL_ACCUM, value );
			break;
		case OpenGL_OpenGLwidget_LOAD:
			glAccum( GL_LOAD, value );
			break;
		case OpenGL_OpenGLwidget_ADD:
			glAccum( GL_ADD, value );
			break;
		case OpenGL_OpenGLwidget_MULT:
			glAccum( GL_MULT, value );
			break;
		case OpenGL_OpenGLwidget_RETURN:
			glAccum( GL_RETURN, value );
			break;
	}
}

void OpenGL_OpenGLwidget_alphaFunc(struct HOpenGL_OpenGLwidget *this,
								   long func, 
								   float value)
{
	switch( func ) {
		case OpenGL_OpenGLwidget_NEVER:
			glAlphaFunc( GL_NEVER, value );
			break;
		case OpenGL_OpenGLwidget_LESS:
			glAlphaFunc( GL_LESS, value );
			break;
		case OpenGL_OpenGLwidget_EQUAL:
			glAlphaFunc( GL_EQUAL, value );
			break;
		case OpenGL_OpenGLwidget_LEQUAL:
			glAlphaFunc( GL_LEQUAL, value );
			break;
		case OpenGL_OpenGLwidget_GREATER:
			glAlphaFunc( GL_GREATER, value );
			break;
		case OpenGL_OpenGLwidget_NOTEQUAL:
			glAlphaFunc( GL_NOTEQUAL, value );
			break;
		case OpenGL_OpenGLwidget_GEQUAL:
			glAlphaFunc( GL_GEQUAL, value );
			break;
		case OpenGL_OpenGLwidget_ALWAYS:
			glAlphaFunc( GL_ALWAYS, value );
			break;
	}
}

void OpenGL_OpenGLwidget_begin(struct HOpenGL_OpenGLwidget *this,
							   long mode )
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_POINTS:
		glBegin( GL_POINTS );
		break;	
	case OpenGL_OpenGLwidget_LINES:
		glBegin( GL_LINES );
		break;
	case OpenGL_OpenGLwidget_LINE_STRIP:
		glBegin( GL_LINE_STRIP );
		break;
	case OpenGL_OpenGLwidget_LINE_LOOP:
		glBegin( GL_LINE_LOOP );
		break;
	case OpenGL_OpenGLwidget_TRIANGLES:
		glBegin( GL_TRIANGLES );
		break;
	case OpenGL_OpenGLwidget_TRIANGLE_STRIP:
		glBegin( GL_TRIANGLE_STRIP );
		break;
	case OpenGL_OpenGLwidget_TRIANGLE_FAN:
		glBegin( GL_TRIANGLE_FAN );
		break;
	case OpenGL_OpenGLwidget_QUADS:
		glBegin( GL_QUADS );
		break;
	case OpenGL_OpenGLwidget_QUAD_STRIP:
		glBegin( GL_QUAD_STRIP );
		break;
	case OpenGL_OpenGLwidget_POLYGON:
		glBegin( GL_POLYGON );
		break;
	}
}

void OpenGL_OpenGLwidget_blendFunc(struct HOpenGL_OpenGLwidget *this,
								   long sfactor,
								   long dfactor )
{
	GLenum gl_sfactor, gl_dfactor;
	switch( sfactor ) {
	case OpenGL_OpenGLwidget_ZERO:
		gl_sfactor = GL_ZERO;
		break;
	case OpenGL_OpenGLwidget_ONE:
		gl_sfactor = GL_ONE;
		break;
	case OpenGL_OpenGLwidget_DST_COLOR:
		gl_sfactor = GL_DST_COLOR;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_DST_COLOR:
		gl_sfactor = GL_ONE_MINUS_DST_COLOR;
		break;
	case OpenGL_OpenGLwidget_SRC_ALPHA:
		gl_sfactor = GL_SRC_ALPHA;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_SRC_ALPHA:
		gl_sfactor = GL_ONE_MINUS_SRC_ALPHA;
		break;
	case OpenGL_OpenGLwidget_DST_ALPHA:
		gl_sfactor = GL_DST_ALPHA;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_DST_ALPHA:
		gl_sfactor = GL_ONE_MINUS_DST_ALPHA;
		break;
	case OpenGL_OpenGLwidget_SRC_ALPHA_SATURATE:
		gl_sfactor = GL_SRC_ALPHA_SATURATE;
		break;
	default:
		return;			/* do nothing on unrecognized option */
	}
	switch( dfactor ) {
	case OpenGL_OpenGLwidget_ZERO:
		gl_dfactor = GL_ZERO;
		break;
	case OpenGL_OpenGLwidget_ONE:
		gl_dfactor = GL_ONE;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_SRC_COLOR:
		gl_dfactor = GL_ONE_MINUS_SRC_COLOR;
		break;
	case OpenGL_OpenGLwidget_SRC_ALPHA:
		gl_dfactor = GL_SRC_ALPHA;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_SRC_ALPHA:
		gl_dfactor = GL_ONE_MINUS_SRC_ALPHA;
		break;
	case OpenGL_OpenGLwidget_DST_ALPHA:
		gl_dfactor = GL_DST_ALPHA;
		break;
	case OpenGL_OpenGLwidget_ONE_MINUS_DST_ALPHA:
		gl_dfactor = GL_ONE_MINUS_DST_ALPHA;
		break;
	default:
		return;			/* do nothing on unrecognized option */
	}

	glBlendFunc( gl_sfactor, gl_dfactor );
}

void OpenGL_OpenGLwidget_clear(struct HOpenGL_OpenGLwidget *this,
						       long mask )
{
	switch (mask) {
	case OpenGL_OpenGLwidget_CURRENT_BIT:
		glClear( GL_COLOR_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_DEPTH_BUFFER_BIT:
		glClear( GL_DEPTH_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_ACCUM_BUFFER_BIT:
		glClear( GL_ACCUM_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_STENCIL_BUFFER_BIT:
		glClear( GL_STENCIL_BUFFER_BIT );
		break;
	default:
		/* do nuthin */
		return;
	}
}

void OpenGL_OpenGLwidget_clearAccum(struct HOpenGL_OpenGLwidget *this,
									float red,
									float green,
									float blue,
									float alpha)
{
	glClearAccum( red, green, blue, alpha );
}

void OpenGL_OpenGLwidget_clearColor(struct HOpenGL_OpenGLwidget *this,
									float red,	
									float green,
									float blue,
									float alpha)
{
	glClearColor( red, green, blue, alpha );
}

void OpenGL_OpenGLwidget_clearDepth(struct HOpenGL_OpenGLwidget *this,
									double depth)
{
	glClearDepth( depth );
}

void OpenGL_OpenGLwidget_clearIndex(struct HOpenGL_OpenGLwidget *this,
									float c)
{
	glClearIndex( c );
}

void OpenGL_OpenGLwidget_clearStencil(struct HOpenGL_OpenGLwidget *this,
									long s)
{
	glClearStencil( (GLint)s );
}

void OpenGL_OpenGLwidget_clipPlane(struct HOpenGL_OpenGLwidget *this,
									long plane,
									double A,
									double B,
									double C,
									double D)
{
	double equation[4];

	equation[0] = A;
	equation[1] = B;
	equation[2] = C;
	equation[3] = D;

	switch( plane ) {
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glClipPlane( GL_CLIP_PLANE0, equation );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glClipPlane( GL_CLIP_PLANE1, equation );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glClipPlane( GL_CLIP_PLANE2, equation );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glClipPlane( GL_CLIP_PLANE3, equation );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glClipPlane( GL_CLIP_PLANE4, equation );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glClipPlane( GL_CLIP_PLANE5, equation );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_color3b(struct HOpenGL_OpenGLwidget *this,
									char red,
									char green,
									char blue)
{
	glColor3b( (GLbyte)red, (GLbyte)green, (GLbyte)blue );
}

void OpenGL_OpenGLwidget_color3d(struct HOpenGL_OpenGLwidget *this,
									double red,
									double green,
									double blue)
{
	glColor3d( red, green, blue );
}

void OpenGL_OpenGLwidget_color3f(struct HOpenGL_OpenGLwidget *this,
									float red,
									float green,
									float blue)
{
	glColor3f( red, green, blue );
}

void OpenGL_OpenGLwidget_color3i(struct HOpenGL_OpenGLwidget *this,
									long red,
									long green,
									long blue)
{
	glColor3i( (GLint) red, (GLint)green, (GLint)blue );
}
void OpenGL_OpenGLwidget_color3s(struct HOpenGL_OpenGLwidget *this,
									short red,
									short green,
									short blue)
{
	glColor3s( red, green, blue );
}
void OpenGL_OpenGLwidget_color4b(struct HOpenGL_OpenGLwidget *this,
									char r,
									char g,
									char b,
									char a)
{
	glColor4b( (GLbyte)r, (GLbyte)g, (GLbyte)b, (GLbyte)a );
}
void OpenGL_OpenGLwidget_color4d(struct HOpenGL_OpenGLwidget *this,
									double r,
									double g,
									double b,
									double a)
{
	glColor4d( r,g,b,a );
}
void OpenGL_OpenGLwidget_color4f(struct HOpenGL_OpenGLwidget *this,
									float r,
									float g,
									float b,
									float a)
{
	glColor4f( r,g,b,a );
}
void OpenGL_OpenGLwidget_color4i(struct HOpenGL_OpenGLwidget *this,
									long r,
									long g,
									long b,
									long a)
{
	glColor4i( (GLint)r, (GLint)g, (GLint)b, (GLint)a );

}
void OpenGL_OpenGLwidget_color4s(struct HOpenGL_OpenGLwidget *this,
									short r,
									short g,
									short b,
									short a)
{
	glColor4s( r,g,b,a );
}

void OpenGL_OpenGLwidget_colorMask(struct HOpenGL_OpenGLwidget *this,
									/*boolean*/ long r,
									/*boolean*/ long g,
									/*boolean*/ long b,
									/*boolean*/ long a)
{
	GLboolean red   = GL_TRUE, 
			  green = GL_TRUE,
			  blue  = GL_TRUE,
			  alpha = GL_TRUE;

	/* let's be explicit to be safe about converting from long to */
	/* unsigned char */
	if( r == 0L )
		red = GL_FALSE;
	if( g == 0L )
		green = GL_FALSE;
	if( b == 0L )
		blue = GL_FALSE;
	if( a == 0L )
		alpha = GL_FALSE;
	glColorMask( red, green, blue, alpha );
}

void OpenGL_OpenGLwidget_colorMaterial(struct HOpenGL_OpenGLwidget *this,
									long face,
									long mode)
{
	GLenum gl_face, gl_mode;

	switch( face ) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}
	switch( mode ) {
	case OpenGL_OpenGLwidget_EMISSION:
		gl_mode = GL_EMISSION;
		break;
	case OpenGL_OpenGLwidget_AMBIENT:
		gl_mode = GL_AMBIENT;
		break;
	case OpenGL_OpenGLwidget_DIFFUSE:
		gl_mode = GL_DIFFUSE;
		break;
	case OpenGL_OpenGLwidget_SPECULAR:
		gl_mode = GL_SPECULAR;
		break;
	case OpenGL_OpenGLwidget_AMBIENT_AND_DIFFUSE:
		gl_mode = GL_AMBIENT_AND_DIFFUSE;
		break;
	default:	
		return;
	}
}

void OpenGL_OpenGLwidget_copyPixels(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long width,
									long height,
									long type)
{
	switch( type ) {
	case OpenGL_OpenGLwidget_COLOR:
		glCopyPixels( (GLint)x, (GLint)y, (GLsizei)width, (GLsizei)height,
					  GL_COLOR );
		break;
	case OpenGL_OpenGLwidget_DEPTH:
		glCopyPixels( (GLint)x, (GLint)y, (GLsizei)width, (GLsizei)height,
					  GL_DEPTH );
		break;
	case OpenGL_OpenGLwidget_STENCIL:
		glCopyPixels( (GLint)x, (GLint)y, (GLsizei)width, (GLsizei)height,
					  GL_STENCIL );
		break;
	default:
		return;
	}
}
void OpenGL_OpenGLwidget_cullFace(struct HOpenGL_OpenGLwidget *this,
									long mode)
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_FRONT:
		glCullFace( GL_FRONT );
		break;
	case OpenGL_OpenGLwidget_BACK:
		glCullFace( GL_BACK );
		break;
	default:
		return;
	}
}
void OpenGL_OpenGLwidget_depthFunc(struct HOpenGL_OpenGLwidget *this,
									long func)
{
	switch( func ) {
	case OpenGL_OpenGLwidget_NEVER:
		glDepthFunc( GL_NEVER );
		break;
	case OpenGL_OpenGLwidget_LESS:
		glDepthFunc( GL_LESS );
		break;
	case OpenGL_OpenGLwidget_EQUAL:
		glDepthFunc( GL_EQUAL );
		break;
	case OpenGL_OpenGLwidget_LEQUAL:
		glDepthFunc( GL_LEQUAL );
		break;
	case OpenGL_OpenGLwidget_GREATER:
		glDepthFunc( GL_GREATER );
		break;
	case OpenGL_OpenGLwidget_NOTEQUAL:
		glDepthFunc( GL_NOTEQUAL );
		break;
	case OpenGL_OpenGLwidget_GEQUAL:
		glDepthFunc( GL_GEQUAL );
		break;
	case OpenGL_OpenGLwidget_ALWAYS:
		glDepthFunc( GL_ALWAYS );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_depthMask(struct HOpenGL_OpenGLwidget *this,
									/*boolean*/ long flag)
{
	if( flag = 0L )
		glDepthMask( GL_FALSE );
	else
		glDepthMask( GL_TRUE );
}

void OpenGL_OpenGLwidget_depthRange(struct HOpenGL_OpenGLwidget *this,
									double near,
									double far)
{
	glDepthRange( near, far );
}

void OpenGL_OpenGLwidget_drawBuffer(struct HOpenGL_OpenGLwidget *this,
									long mode)
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_NONE:
		glDrawBuffer( GL_NONE );
		break;
	case OpenGL_OpenGLwidget_FRONT_LEFT:
		glDrawBuffer( GL_FRONT_LEFT );
		break;
	case OpenGL_OpenGLwidget_FRONT_RIGHT:
		glDrawBuffer( GL_FRONT_RIGHT );
		break;
	case OpenGL_OpenGLwidget_BACK_LEFT:
		glDrawBuffer( GL_BACK_LEFT );
		break;
	case OpenGL_OpenGLwidget_BACK_RIGHT:
		glDrawBuffer( GL_BACK_RIGHT );
		break;
	case OpenGL_OpenGLwidget_FRONT:
		glDrawBuffer( GL_FRONT );
		break;
	case OpenGL_OpenGLwidget_BACK:
		glDrawBuffer( GL_BACK );
		break;
	case OpenGL_OpenGLwidget_RIGHT:
		glDrawBuffer( GL_RIGHT );
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		glDrawBuffer( GL_FRONT_AND_BACK );
		break;
	case OpenGL_OpenGLwidget_AUX0:
		glDrawBuffer( GL_AUX0 );
		break;
	case OpenGL_OpenGLwidget_AUX1:
		glDrawBuffer( GL_AUX1 );
		break;
	case OpenGL_OpenGLwidget_AUX2:
		glDrawBuffer( GL_AUX2 );
		break;
	case OpenGL_OpenGLwidget_AUX3:
		glDrawBuffer( GL_AUX3 );
		break;
	default:
		break;
	}
}

void OpenGL_OpenGLwidget_edgeFlag(struct HOpenGL_OpenGLwidget *this,
									/* boolean */ long flag) 
{
	if( flag = 0L )
		glEdgeFlag( GL_FALSE );
	else
		glEdgeFlag( GL_TRUE );
}

void OpenGL_OpenGLwidget_enable(struct HOpenGL_OpenGLwidget *this,
									long cap)
{
	switch( cap ) {
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		glEnable( GL_ALPHA_TEST );
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		glEnable( GL_AUTO_NORMAL );
		break;
	case OpenGL_OpenGLwidget_BLEND:
		glEnable( GL_BLEND );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glEnable( GL_CLIP_PLANE0 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glEnable( GL_CLIP_PLANE1 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glEnable( GL_CLIP_PLANE2 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glEnable( GL_CLIP_PLANE3 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glEnable( GL_CLIP_PLANE4 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glEnable( GL_CLIP_PLANE5 );
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		glEnable( GL_COLOR_MATERIAL );
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		glEnable( GL_CULL_FACE );
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		glEnable( GL_DEPTH_TEST );
		break;
	case OpenGL_OpenGLwidget_DITHER:
		glEnable( GL_DITHER );
		break;
	case OpenGL_OpenGLwidget_FOG:
		glEnable( GL_FOG );
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		glEnable( GL_LIGHT0 );
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		glEnable( GL_LIGHT1 );
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		glEnable( GL_LIGHT2 );
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		glEnable( GL_LIGHT3 );
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		glEnable( GL_LIGHT4 );
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		glEnable( GL_LIGHT5 );
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		glEnable( GL_LIGHT6 );
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		glEnable( GL_LIGHT7 );
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		glEnable( GL_LIGHTING );
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		glEnable( GL_LINE_SMOOTH );
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		glEnable( GL_LINE_STIPPLE );
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		glEnable( GL_LOGIC_OP );
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		glEnable( GL_MAP1_COLOR_4 );
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		glEnable( GL_MAP1_INDEX );
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		glEnable( GL_MAP1_NORMAL);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		glEnable( GL_MAP1_TEXTURE_COORD_1);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		glEnable( GL_MAP1_TEXTURE_COORD_2);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		glEnable( GL_MAP1_TEXTURE_COORD_3);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		glEnable( GL_MAP1_TEXTURE_COORD_4);
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		glEnable( GL_MAP1_VERTEX_3);
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		glEnable( GL_MAP1_VERTEX_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		glEnable( GL_MAP2_COLOR_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		glEnable( GL_MAP2_INDEX);
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		glEnable( GL_MAP2_NORMAL);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		glEnable( GL_MAP2_TEXTURE_COORD_1);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		glEnable( GL_MAP2_TEXTURE_COORD_2);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		glEnable( GL_MAP2_TEXTURE_COORD_3);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		glEnable( GL_MAP2_TEXTURE_COORD_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		glEnable( GL_MAP2_VERTEX_3);
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		glEnable( GL_MAP2_VERTEX_4);
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		glEnable( GL_NORMALIZE);
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		glEnable( GL_POINT_SMOOTH);
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		glEnable( GL_POLYGON_SMOOTH);
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		glEnable( GL_POLYGON_STIPPLE);
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		glEnable( GL_SCISSOR_TEST);
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		glEnable( GL_STENCIL_TEST);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		glEnable( GL_TEXTURE_1D);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		glEnable( GL_TEXTURE_2D);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		glEnable( GL_TEXTURE_GEN_Q);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		glEnable( GL_TEXTURE_GEN_R);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		glEnable( GL_TEXTURE_GEN_S);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		glEnable( GL_TEXTURE_GEN_T);
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_end( struct HOpenGL_OpenGLwidget *this)
{
	glEnd();
}

void OpenGL_OpenGLwidget_evalCoord1d( struct HOpenGL_OpenGLwidget *this,
							double u )
{
	glEvalCoord1d( u );
}

void OpenGL_OpenGLwidget_evalCoord2d( struct HOpenGL_OpenGLwidget *this,
							double u,
							double v)
{
	glEvalCoord2d( u, v );
}

void OpenGL_OpenGLwidget_evalCoord1f( struct HOpenGL_OpenGLwidget *this,
							float u )
{
	glEvalCoord1f( u );
}

void OpenGL_OpenGLwidget_evalCoord2f( struct HOpenGL_OpenGLwidget *this,
							float u,
							float v)
{
	glEvalCoord2f( u, v );
}

void OpenGL_OpenGLwidget_evalMesh1( struct HOpenGL_OpenGLwidget *this,
							long mode,
							long i1,
							long i2 )
{
	switch( mode ) {
	case  OpenGL_OpenGLwidget_POINT:
		glEvalMesh1( GL_POINT, (GLint)i1, (GLint)i2 );
		break;
	case OpenGL_OpenGLwidget_LINE:
		glEvalMesh1( GL_LINE, (GLint)i1, (GLint)i2 );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_evalMesh2( struct HOpenGL_OpenGLwidget *this,
							long mode,
							long i1,
							long i2,
							long j1,
							long j2 )
{
	switch( mode ) {
	case  OpenGL_OpenGLwidget_POINT:
		glEvalMesh2( GL_POINT, (GLint)i1, (GLint)i2, (GLint)j1, (GLint)j2 );
		break;
	case OpenGL_OpenGLwidget_LINE:
		glEvalMesh2( GL_LINE, (GLint)i1, (GLint)i2, (GLint)j1, (GLint)j2 );
		break;
	case OpenGL_OpenGLwidget_FILL:
		glEvalMesh2( GL_FILL, (GLint)i1, (GLint)i2, (GLint)j1, (GLint)j2 );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_evalPoint1( struct HOpenGL_OpenGLwidget *this,
							long i )
{
	glEvalPoint1( (GLint)i );
}

void OpenGL_OpenGLwidget_evalPoint2( struct HOpenGL_OpenGLwidget *this,
							long i,
							long j)
{
	glEvalPoint2( (GLint)i, (GLint)j );
}

void OpenGL_OpenGLwidget_finish(struct HOpenGL_OpenGLwidget *this)
{
	glFinish();
}

void OpenGL_OpenGLwidget_flush(struct HOpenGL_OpenGLwidget *this)
{
	glFlush();
}

void OpenGL_OpenGLwidget_fogf(struct HOpenGL_OpenGLwidget *this,
									long pname,
									float param)
{
	switch( pname ) {
	case OpenGL_OpenGLwidget_FOG_MODE:
		glFogf( GL_FOG_MODE, param );
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glFogf( GL_FOG_DENSITY, param );
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glFogf( GL_FOG_START, param );
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glFogf( GL_FOG_END, param );
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glFogf( GL_FOG_INDEX, param );
		break;
	}
}

void OpenGL_OpenGLwidget_fogi(struct HOpenGL_OpenGLwidget *this,
									long pname,
									long param)
{
	switch( pname ) {
	case OpenGL_OpenGLwidget_FOG_MODE:
		glFogf( GL_FOG_MODE, (GLint)param );
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glFogf( GL_FOG_DENSITY, (GLint)param );
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glFogf( GL_FOG_START, (GLint)param );
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glFogf( GL_FOG_END, (GLint)param );
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glFogf( GL_FOG_INDEX, (GLint)param );
		break;
	}
}

void OpenGL_OpenGLwidget_fogColourf( struct HOpenGL_OpenGLwidget *this,
									float r,
									float g,
									float b,
									float a )
{
	float rgba[4];

	rgba[0] = r; rgba[1] = g; rgba[2] = b; rgba[3] = a;
	glFogfv( GL_FOG_COLOR, rgba );
}

void OpenGL_OpenGLwidget_fogColouri( struct HOpenGL_OpenGLwidget *this,
									long r,
									long g,
									long b,
									long a )
{
	GLint rgba[4];

	rgba[0] = (GLint)r; rgba[1] = (GLint)g; rgba[2] = (GLint)b;
	rgba[3] = (GLint)a;
	glFogiv( GL_FOG_COLOR, rgba );
}

void OpenGL_OpenGLwidget_frontFace(struct HOpenGL_OpenGLwidget *this,
									long mode)
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_CW:
		glFrontFace( GL_CW );
		break;
	case OpenGL_OpenGLwidget_CCW:
		glFrontFace( GL_CCW );
		break;
	}
}

void OpenGL_OpenGLwidget_frustum(struct HOpenGL_OpenGLwidget *this,
									double left,
									double right,
									double bottom,
									double top,
									double near,
									double far)
{
	glFrustum( left, right, bottom, top, near, far );
}

void OpenGL_OpenGLwidget_getb(struct HOpenGL_OpenGLwidget *this,
							  long pname,
							  HArrayOfInt *thisParams)
{

	GLboolean params[16] = { 0, 0, 0, 0,
							 0, 0, 0, 0,
							 0, 0, 0, 0,
							 0, 0, 0, 0 };
	long *ptr = unhand(thisParams)->body;
	int i;

	switch( pname ) {
	case OpenGL_OpenGLwidget_ACCUM_ALPHA_BITS:
		glGetBooleanv( GL_ACCUM_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_BLUE_BITS:
		glGetBooleanv( GL_ACCUM_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_CLEAR_VALUE:
		glGetBooleanv( GL_ACCUM_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ACCUM_GREEN_BITS:
		glGetBooleanv( GL_ACCUM_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_RED_BITS:
		glGetBooleanv( GL_ACCUM_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BIAS:
		glGetBooleanv( GL_ALPHA_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BITS:
		glGetBooleanv( GL_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_SCALE:
		glGetBooleanv( GL_ALPHA_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		glGetBooleanv( GL_ALPHA_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_FUNC:
		glGetBooleanv( GL_ALPHA_TEST_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_REF:
		glGetBooleanv( GL_ALPHA_TEST_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ATTRIB_STACK_DEPTH:
		glGetBooleanv( GL_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		glGetBooleanv( GL_AUTO_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUX_BUFFERS:
		glGetBooleanv( GL_AUX_BUFFERS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND:
		glGetBooleanv( GL_BLEND, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_DST:
		glGetBooleanv( GL_BLEND_DST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_SRC:
		glGetBooleanv( GL_BLEND_SRC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BIAS:
		glGetBooleanv( GL_BLUE_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BITS:
		glGetBooleanv( GL_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_SCALE:
		glGetBooleanv( GL_BLUE_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glGetBooleanv( GL_CLIP_PLANE0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glGetBooleanv( GL_CLIP_PLANE1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glGetBooleanv( GL_CLIP_PLANE2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glGetBooleanv( GL_CLIP_PLANE3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glGetBooleanv( GL_CLIP_PLANE4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glGetBooleanv( GL_CLIP_PLANE5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_CLEAR_VALUE:
		glGetBooleanv( GL_COLOR_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		glGetBooleanv( GL_COLOR_MATERIAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL_PARAMETER:
		glGetBooleanv( GL_COLOR_MATERIAL_PARAMETER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_WRITEMASK:
		glGetBooleanv( GL_COLOR_WRITEMASK, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		glGetBooleanv( GL_CULL_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE_MODE:
		glGetBooleanv( GL_CULL_FACE_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_COLOR:
		glGetBooleanv( GL_CURRENT_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_INDEX:
		glGetBooleanv( GL_CURRENT_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_NORMAL:
		glGetBooleanv( GL_CURRENT_NORMAL, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_COLOR:
		glGetBooleanv( GL_CURRENT_RASTER_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_DISTANCE:
		glGetBooleanv( GL_CURRENT_RASTER_DISTANCE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_INDEX:
		glGetBooleanv( GL_CURRENT_RASTER_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION:
		glGetBooleanv( GL_CURRENT_RASTER_POSITION, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_TEXTURE_COORDS:
		glGetBooleanv( GL_CURRENT_RASTER_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION_VALID:
		glGetBooleanv( GL_CURRENT_RASTER_POSITION_VALID, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_TEXTURE_COORDS:
		glGetBooleanv( GL_CURRENT_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_DEPTH_BIAS:
		glGetBooleanv( GL_DEPTH_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_CLEAR_VALUE:
		glGetBooleanv( GL_DEPTH_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_FUNC:
		glGetBooleanv( GL_DEPTH_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_RANGE:
		glGetBooleanv( GL_DEPTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_DEPTH_SCALE:
		glGetBooleanv( GL_DEPTH_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		glGetBooleanv( GL_DEPTH_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_WRITEMASK:
		glGetBooleanv( GL_DEPTH_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DITHER:
		glGetBooleanv( GL_DITHER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DOUBLEBUFFER:
		glGetBooleanv( GL_DOUBLEBUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DRAW_BUFFER:
		glGetBooleanv( GL_DRAW_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_EDGE_FLAG:
		glGetBooleanv( GL_EDGE_FLAG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG:
		glGetBooleanv( GL_FOG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_COLOR:
		glGetBooleanv( GL_FOG_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glGetBooleanv( GL_FOG_DENSITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glGetBooleanv( GL_FOG_END, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_HINT:
		glGetBooleanv( GL_FOG_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glGetBooleanv( GL_FOG_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_MODE:
		glGetBooleanv( GL_FOG_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glGetBooleanv( GL_FOG_START, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FRONT_FACE:
		glGetBooleanv( GL_FRONT_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BIAS:
		glGetBooleanv( GL_GREEN_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BITS:
		glGetBooleanv( GL_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_SCALE:
		glGetBooleanv( GL_GREEN_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_BITS:
		glGetBooleanv( GL_INDEX_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_CLEAR_VALUE:
		glGetBooleanv( GL_INDEX_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_MODE:
		glGetBooleanv( GL_INDEX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_OFFSET:
		glGetBooleanv( GL_INDEX_OFFSET, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_SHIFT:
		glGetBooleanv( GL_INDEX_SHIFT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_WRITEMASK:
		glGetBooleanv( GL_INDEX_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		glGetBooleanv( GL_LIGHT0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		glGetBooleanv( GL_LIGHT1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		glGetBooleanv( GL_LIGHT2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		glGetBooleanv( GL_LIGHT3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		glGetBooleanv( GL_LIGHT4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		glGetBooleanv( GL_LIGHT5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		glGetBooleanv( GL_LIGHT6, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		glGetBooleanv( GL_LIGHT7, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		glGetBooleanv( GL_LIGHTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		glGetBooleanv( GL_LIGHT_MODEL_AMBIENT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glGetBooleanv( GL_LIGHT_MODEL_LOCAL_VIEWER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glGetBooleanv( GL_LIGHT_MODEL_TWO_SIDE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		glGetBooleanv( GL_LINE_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH_HINT:
		glGetBooleanv( GL_LINE_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		glGetBooleanv( GL_LINE_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_PATTERN:
		glGetBooleanv( GL_LINE_STIPPLE_PATTERN, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_REPEAT:
		glGetBooleanv( GL_LINE_STIPPLE_REPEAT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH:
		glGetBooleanv( GL_LINE_WIDTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_GRANULARITY:
		glGetBooleanv( GL_LINE_WIDTH_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_RANGE:
		glGetBooleanv( GL_LINE_WIDTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_LIST_BASE:
		glGetBooleanv( GL_LIST_BASE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_INDEX:
		glGetBooleanv( GL_LIST_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_MODE:
		glGetBooleanv( GL_LIST_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		glGetBooleanv( GL_LOGIC_OP, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP_MODE:
		glGetBooleanv( GL_LOGIC_OP_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		glGetBooleanv( GL_MAP1_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_DOMAIN:
		glGetBooleanv( GL_MAP1_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_SEGMENTS:
		glGetBooleanv( GL_MAP1_GRID_SEGMENTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		glGetBooleanv( GL_MAP1_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		glGetBooleanv( GL_MAP1_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		glGetBooleanv( GL_MAP1_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		glGetBooleanv( GL_MAP1_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		glGetBooleanv( GL_MAP1_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		glGetBooleanv( GL_MAP1_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		glGetBooleanv( GL_MAP1_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		glGetBooleanv( GL_MAP1_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		glGetBooleanv( GL_MAP2_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_DOMAIN:
		glGetBooleanv( GL_MAP2_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_SEGMENTS:
		glGetBooleanv( GL_MAP2_GRID_SEGMENTS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		glGetBooleanv( GL_MAP2_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		glGetBooleanv( GL_MAP2_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		glGetBooleanv( GL_MAP2_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		glGetBooleanv( GL_MAP2_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		glGetBooleanv( GL_MAP2_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		glGetBooleanv( GL_MAP2_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		glGetBooleanv( GL_MAP2_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		glGetBooleanv( GL_MAP2_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_COLOR:
		glGetBooleanv( GL_MAP_COLOR, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_STENCIL:
		glGetBooleanv( GL_MAP_STENCIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MATRIX_MODE:
		glGetBooleanv( GL_MATRIX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_ATTRIB_STACK_DEPTH:
		glGetBooleanv( GL_MAX_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_CLIP_PLANES:
		glGetBooleanv( GL_MAX_CLIP_PLANES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_EVAL_ORDER:
		glGetBooleanv( GL_MAX_EVAL_ORDER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIGHTS:
		glGetBooleanv( GL_MAX_LIGHTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIST_NESTING:
		glGetBooleanv( GL_MAX_LIST_NESTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_MODELVIEW_STACK_DEPTH:
		glGetBooleanv( GL_MAX_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_NAME_STACK_DEPTH:
		glGetBooleanv( GL_MAX_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PIXEL_MAP_TABLE:
		glGetBooleanv( GL_MAX_PIXEL_MAP_TABLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PROJECTION_STACK_DEPTH:
		glGetBooleanv( GL_MAX_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_SIZE:
		glGetBooleanv( GL_MAX_TEXTURE_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_STACK_DEPTH:
		glGetBooleanv( GL_MAX_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_VIEWPORT_DIMS:
		glGetBooleanv( GL_MAX_VIEWPORT_DIMS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_MATRIX:
		glGetBooleanv( GL_LINE_WIDTH, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_STACK_DEPTH:
		glGetBooleanv( GL_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NAME_STACK_DEPTH:
		glGetBooleanv( GL_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		glGetBooleanv( GL_NORMALIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ALIGNMENT:
		glGetBooleanv( GL_PACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_LSB_FIRST:
		glGetBooleanv( GL_PACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ROW_LENGTH:
		glGetBooleanv( GL_PACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_PIXELS:
		glGetBooleanv( GL_PACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_ROWS:
		glGetBooleanv( GL_PACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SWAP_BYTES:
		glGetBooleanv( GL_PACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PERSPECTIVE_CORRECTION_HINT:
		glGetBooleanv( GL_PERSPECTIVE_CORRECTION_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_A_TO_A_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_A_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_B_TO_B_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_B_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_G_TO_G_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_G_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_A_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_I_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_B_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_I_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_G_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_I_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_I_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_I_TO_I_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_R_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_I_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_R_TO_R_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_R_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_S_TO_S_SIZE:
		glGetBooleanv( GL_PIXEL_MAP_S_TO_S_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE:
		glGetBooleanv( GL_POINT_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_GRANULARITY:
		glGetBooleanv( GL_POINT_SIZE_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_RANGE:
		glGetBooleanv( GL_POINT_SIZE_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		glGetBooleanv( GL_POINT_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH_HINT:
		glGetBooleanv( GL_POINT_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_MODE:
		glGetBooleanv( GL_POLYGON_MODE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		glGetBooleanv( GL_POLYGON_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH_HINT:
		glGetBooleanv( GL_POLYGON_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		glGetBooleanv( GL_POLYGON_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PROJECTION_MATRIX:
		glGetBooleanv( GL_PROJECTION_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_PROJECTION_STACK_DEPTH:
		glGetBooleanv( GL_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_READ_BUFFER:
		glGetBooleanv( GL_READ_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BIAS:
		glGetBooleanv( GL_RED_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BITS:
		glGetBooleanv( GL_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_SCALE:
		glGetBooleanv( GL_RED_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RENDER_MODE:
		glGetBooleanv( GL_RENDER_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RGBA_MODE:
		glGetBooleanv( GL_RGBA_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_BOX:
		glGetBooleanv( GL_SCISSOR_BOX, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		glGetBooleanv( GL_SCISSOR_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SHADE_MODEL:
		glGetBooleanv( GL_SHADE_MODEL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_BITS:
		glGetBooleanv( GL_STENCIL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_CLEAR_VALUE:
		glGetBooleanv( GL_STENCIL_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FAIL:
		glGetBooleanv( GL_STENCIL_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FUNC:
		glGetBooleanv( GL_STENCIL_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_FAIL:
		glGetBooleanv( GL_STENCIL_PASS_DEPTH_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_PASS:
		glGetBooleanv( GL_STENCIL_PASS_DEPTH_PASS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_REF:
		glGetBooleanv( GL_STENCIL_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		glGetBooleanv( GL_STENCIL_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_VALUE_MASK:
		glGetBooleanv( GL_STENCIL_VALUE_MASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_WRITEMASK:
		glGetBooleanv( GL_STENCIL_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STEREO:
		glGetBooleanv( GL_STEREO, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SUBPIXEL_BITS:
		glGetBooleanv( GL_SUBPIXEL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		glGetBooleanv( GL_TEXTURE_1D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		glGetBooleanv( GL_TEXTURE_2D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_COLOR:
		glGetBooleanv( GL_TEXTURE_ENV_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		glGetBooleanv( GL_TEXTURE_ENV_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		glGetBooleanv( GL_TEXTURE_GEN_S, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		glGetBooleanv( GL_TEXTURE_GEN_T, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		glGetBooleanv( GL_TEXTURE_GEN_R, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		glGetBooleanv( GL_TEXTURE_GEN_Q, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_MATRIX:
		glGetBooleanv( GL_TEXTURE_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_TEXTURE_STACK_DEPTH:
		glGetBooleanv( GL_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ALIGNMENT:
		glGetBooleanv( GL_UNPACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_LSB_FIRST:
		glGetBooleanv( GL_UNPACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ROW_LENGTH:
		glGetBooleanv( GL_UNPACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_PIXELS:
		glGetBooleanv( GL_UNPACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_ROWS:
		glGetBooleanv( GL_UNPACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SWAP_BYTES:
		glGetBooleanv( GL_UNPACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_VIEWPORT:
		glGetBooleanv( GL_VIEWPORT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ZOOM_X:
		glGetBooleanv( GL_ZOOM_X, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ZOOM_Y:
		glGetBooleanv( GL_ZOOM_Y, params );
		*ptr = params[0];
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_getd(struct HOpenGL_OpenGLwidget *this,
							  long pname,
							  HArrayOfDouble *thisParams)
{

	GLdouble params[16] = { 0.0, 0.0, 0.0, 0.0,
							0.0, 0.0, 0.0, 0.0,
							0.0, 0.0, 0.0, 0.0,
							0.0, 0.0, 0.0, 0.0 };
	double *ptr = unhand(thisParams)->body;
	int i;

	switch( pname ) {
	case OpenGL_OpenGLwidget_ACCUM_ALPHA_BITS:
		glGetDoublev( GL_ACCUM_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_BLUE_BITS:
		glGetDoublev( GL_ACCUM_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_CLEAR_VALUE:
		glGetDoublev( GL_ACCUM_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ACCUM_GREEN_BITS:
		glGetDoublev( GL_ACCUM_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_RED_BITS:
		glGetDoublev( GL_ACCUM_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BIAS:
		glGetDoublev( GL_ALPHA_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BITS:
		glGetDoublev( GL_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_SCALE:
		glGetDoublev( GL_ALPHA_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		glGetDoublev( GL_ALPHA_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_FUNC:
		glGetDoublev( GL_ALPHA_TEST_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_REF:
		glGetDoublev( GL_ALPHA_TEST_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ATTRIB_STACK_DEPTH:
		glGetDoublev( GL_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		glGetDoublev( GL_AUTO_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUX_BUFFERS:
		glGetDoublev( GL_AUX_BUFFERS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND:
		glGetDoublev( GL_BLEND, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_DST:
		glGetDoublev( GL_BLEND_DST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_SRC:
		glGetDoublev( GL_BLEND_SRC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BIAS:
		glGetDoublev( GL_BLUE_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BITS:
		glGetDoublev( GL_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_SCALE:
		glGetDoublev( GL_BLUE_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glGetDoublev( GL_CLIP_PLANE0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glGetDoublev( GL_CLIP_PLANE1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glGetDoublev( GL_CLIP_PLANE2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glGetDoublev( GL_CLIP_PLANE3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glGetDoublev( GL_CLIP_PLANE4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glGetDoublev( GL_CLIP_PLANE5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_CLEAR_VALUE:
		glGetDoublev( GL_COLOR_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		glGetDoublev( GL_COLOR_MATERIAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL_PARAMETER:
		glGetDoublev( GL_COLOR_MATERIAL_PARAMETER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_WRITEMASK:
		glGetDoublev( GL_COLOR_WRITEMASK, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		glGetDoublev( GL_CULL_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE_MODE:
		glGetDoublev( GL_CULL_FACE_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_COLOR:
		glGetDoublev( GL_CURRENT_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_INDEX:
		glGetDoublev( GL_CURRENT_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_NORMAL:
		glGetDoublev( GL_CURRENT_NORMAL, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_COLOR:
		glGetDoublev( GL_CURRENT_RASTER_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_DISTANCE:
		glGetDoublev( GL_CURRENT_RASTER_DISTANCE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_INDEX:
		glGetDoublev( GL_CURRENT_RASTER_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION:
		glGetDoublev( GL_CURRENT_RASTER_POSITION, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_TEXTURE_COORDS:
		glGetDoublev( GL_CURRENT_RASTER_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION_VALID:
		glGetDoublev( GL_CURRENT_RASTER_POSITION_VALID, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_TEXTURE_COORDS:
		glGetDoublev( GL_CURRENT_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_DEPTH_BIAS:
		glGetDoublev( GL_DEPTH_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_CLEAR_VALUE:
		glGetDoublev( GL_DEPTH_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_FUNC:
		glGetDoublev( GL_DEPTH_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_RANGE:
		glGetDoublev( GL_DEPTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_DEPTH_SCALE:
		glGetDoublev( GL_DEPTH_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		glGetDoublev( GL_DEPTH_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_WRITEMASK:
		glGetDoublev( GL_DEPTH_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DITHER:
		glGetDoublev( GL_DITHER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DOUBLEBUFFER:
		glGetDoublev( GL_DOUBLEBUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DRAW_BUFFER:
		glGetDoublev( GL_DRAW_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_EDGE_FLAG:
		glGetDoublev( GL_EDGE_FLAG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG:
		glGetDoublev( GL_FOG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_COLOR:
		glGetDoublev( GL_FOG_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glGetDoublev( GL_FOG_DENSITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glGetDoublev( GL_FOG_END, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_HINT:
		glGetDoublev( GL_FOG_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glGetDoublev( GL_FOG_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_MODE:
		glGetDoublev( GL_FOG_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glGetDoublev( GL_FOG_START, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FRONT_FACE:
		glGetDoublev( GL_FRONT_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BIAS:
		glGetDoublev( GL_GREEN_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BITS:
		glGetDoublev( GL_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_SCALE:
		glGetDoublev( GL_GREEN_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_BITS:
		glGetDoublev( GL_INDEX_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_CLEAR_VALUE:
		glGetDoublev( GL_INDEX_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_MODE:
		glGetDoublev( GL_INDEX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_OFFSET:
		glGetDoublev( GL_INDEX_OFFSET, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_SHIFT:
		glGetDoublev( GL_INDEX_SHIFT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_WRITEMASK:
		glGetDoublev( GL_INDEX_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		glGetDoublev( GL_LIGHT0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		glGetDoublev( GL_LIGHT1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		glGetDoublev( GL_LIGHT2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		glGetDoublev( GL_LIGHT3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		glGetDoublev( GL_LIGHT4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		glGetDoublev( GL_LIGHT5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		glGetDoublev( GL_LIGHT6, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		glGetDoublev( GL_LIGHT7, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		glGetDoublev( GL_LIGHTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		glGetDoublev( GL_LIGHT_MODEL_AMBIENT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glGetDoublev( GL_LIGHT_MODEL_LOCAL_VIEWER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glGetDoublev( GL_LIGHT_MODEL_TWO_SIDE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		glGetDoublev( GL_LINE_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH_HINT:
		glGetDoublev( GL_LINE_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		glGetDoublev( GL_LINE_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_PATTERN:
		glGetDoublev( GL_LINE_STIPPLE_PATTERN, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_REPEAT:
		glGetDoublev( GL_LINE_STIPPLE_REPEAT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH:
		glGetDoublev( GL_LINE_WIDTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_GRANULARITY:
		glGetDoublev( GL_LINE_WIDTH_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_RANGE:
		glGetDoublev( GL_LINE_WIDTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_LIST_BASE:
		glGetDoublev( GL_LIST_BASE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_INDEX:
		glGetDoublev( GL_LIST_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_MODE:
		glGetDoublev( GL_LIST_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		glGetDoublev( GL_LOGIC_OP, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP_MODE:
		glGetDoublev( GL_LOGIC_OP_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		glGetDoublev( GL_MAP1_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_DOMAIN:
		glGetDoublev( GL_MAP1_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_SEGMENTS:
		glGetDoublev( GL_MAP1_GRID_SEGMENTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		glGetDoublev( GL_MAP1_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		glGetDoublev( GL_MAP1_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		glGetDoublev( GL_MAP1_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		glGetDoublev( GL_MAP1_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		glGetDoublev( GL_MAP1_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		glGetDoublev( GL_MAP1_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		glGetDoublev( GL_MAP1_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		glGetDoublev( GL_MAP1_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		glGetDoublev( GL_MAP2_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_DOMAIN:
		glGetDoublev( GL_MAP2_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_SEGMENTS:
		glGetDoublev( GL_MAP2_GRID_SEGMENTS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		glGetDoublev( GL_MAP2_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		glGetDoublev( GL_MAP2_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		glGetDoublev( GL_MAP2_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		glGetDoublev( GL_MAP2_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		glGetDoublev( GL_MAP2_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		glGetDoublev( GL_MAP2_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		glGetDoublev( GL_MAP2_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		glGetDoublev( GL_MAP2_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_COLOR:
		glGetDoublev( GL_MAP_COLOR, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_STENCIL:
		glGetDoublev( GL_MAP_STENCIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MATRIX_MODE:
		glGetDoublev( GL_MATRIX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_ATTRIB_STACK_DEPTH:
		glGetDoublev( GL_MAX_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_CLIP_PLANES:
		glGetDoublev( GL_MAX_CLIP_PLANES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_EVAL_ORDER:
		glGetDoublev( GL_MAX_EVAL_ORDER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIGHTS:
		glGetDoublev( GL_MAX_LIGHTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIST_NESTING:
		glGetDoublev( GL_MAX_LIST_NESTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_MODELVIEW_STACK_DEPTH:
		glGetDoublev( GL_MAX_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_NAME_STACK_DEPTH:
		glGetDoublev( GL_MAX_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PIXEL_MAP_TABLE:
		glGetDoublev( GL_MAX_PIXEL_MAP_TABLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PROJECTION_STACK_DEPTH:
		glGetDoublev( GL_MAX_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_SIZE:
		glGetDoublev( GL_MAX_TEXTURE_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_STACK_DEPTH:
		glGetDoublev( GL_MAX_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_VIEWPORT_DIMS:
		glGetDoublev( GL_MAX_VIEWPORT_DIMS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_MATRIX:
		glGetDoublev( GL_LINE_WIDTH, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_STACK_DEPTH:
		glGetDoublev( GL_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NAME_STACK_DEPTH:
		glGetDoublev( GL_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		glGetDoublev( GL_NORMALIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ALIGNMENT:
		glGetDoublev( GL_PACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_LSB_FIRST:
		glGetDoublev( GL_PACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ROW_LENGTH:
		glGetDoublev( GL_PACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_PIXELS:
		glGetDoublev( GL_PACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_ROWS:
		glGetDoublev( GL_PACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SWAP_BYTES:
		glGetDoublev( GL_PACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PERSPECTIVE_CORRECTION_HINT:
		glGetDoublev( GL_PERSPECTIVE_CORRECTION_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_A_TO_A_SIZE:
		glGetDoublev( GL_PIXEL_MAP_A_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_B_TO_B_SIZE:
		glGetDoublev( GL_PIXEL_MAP_B_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_G_TO_G_SIZE:
		glGetDoublev( GL_PIXEL_MAP_G_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_A_SIZE:
		glGetDoublev( GL_PIXEL_MAP_I_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_B_SIZE:
		glGetDoublev( GL_PIXEL_MAP_I_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_G_SIZE:
		glGetDoublev( GL_PIXEL_MAP_I_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_I_SIZE:
		glGetDoublev( GL_PIXEL_MAP_I_TO_I_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_R_SIZE:
		glGetDoublev( GL_PIXEL_MAP_I_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_R_TO_R_SIZE:
		glGetDoublev( GL_PIXEL_MAP_R_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_S_TO_S_SIZE:
		glGetDoublev( GL_PIXEL_MAP_S_TO_S_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE:
		glGetDoublev( GL_POINT_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_GRANULARITY:
		glGetDoublev( GL_POINT_SIZE_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_RANGE:
		glGetDoublev( GL_POINT_SIZE_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		glGetDoublev( GL_POINT_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH_HINT:
		glGetDoublev( GL_POINT_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_MODE:
		glGetDoublev( GL_POLYGON_MODE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		glGetDoublev( GL_POLYGON_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH_HINT:
		glGetDoublev( GL_POLYGON_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		glGetDoublev( GL_POLYGON_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PROJECTION_MATRIX:
		glGetDoublev( GL_PROJECTION_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_PROJECTION_STACK_DEPTH:
		glGetDoublev( GL_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_READ_BUFFER:
		glGetDoublev( GL_READ_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BIAS:
		glGetDoublev( GL_RED_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BITS:
		glGetDoublev( GL_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_SCALE:
		glGetDoublev( GL_RED_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RENDER_MODE:
		glGetDoublev( GL_RENDER_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RGBA_MODE:
		glGetDoublev( GL_RGBA_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_BOX:
		glGetDoublev( GL_SCISSOR_BOX, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		glGetDoublev( GL_SCISSOR_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SHADE_MODEL:
		glGetDoublev( GL_SHADE_MODEL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_BITS:
		glGetDoublev( GL_STENCIL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_CLEAR_VALUE:
		glGetDoublev( GL_STENCIL_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FAIL:
		glGetDoublev( GL_STENCIL_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FUNC:
		glGetDoublev( GL_STENCIL_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_FAIL:
		glGetDoublev( GL_STENCIL_PASS_DEPTH_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_PASS:
		glGetDoublev( GL_STENCIL_PASS_DEPTH_PASS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_REF:
		glGetDoublev( GL_STENCIL_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		glGetDoublev( GL_STENCIL_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_VALUE_MASK:
		glGetDoublev( GL_STENCIL_VALUE_MASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_WRITEMASK:
		glGetDoublev( GL_STENCIL_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STEREO:
		glGetDoublev( GL_STEREO, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SUBPIXEL_BITS:
		glGetDoublev( GL_SUBPIXEL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		glGetDoublev( GL_TEXTURE_1D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		glGetDoublev( GL_TEXTURE_2D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_COLOR:
		glGetDoublev( GL_TEXTURE_ENV_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		glGetDoublev( GL_TEXTURE_ENV_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		glGetDoublev( GL_TEXTURE_GEN_S, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		glGetDoublev( GL_TEXTURE_GEN_T, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		glGetDoublev( GL_TEXTURE_GEN_R, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		glGetDoublev( GL_TEXTURE_GEN_Q, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_MATRIX:
		glGetDoublev( GL_TEXTURE_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_TEXTURE_STACK_DEPTH:
		glGetDoublev( GL_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ALIGNMENT:
		glGetDoublev( GL_UNPACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_LSB_FIRST:
		glGetDoublev( GL_UNPACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ROW_LENGTH:
		glGetDoublev( GL_UNPACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_PIXELS:
		glGetDoublev( GL_UNPACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_ROWS:
		glGetDoublev( GL_UNPACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SWAP_BYTES:
		glGetDoublev( GL_UNPACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_VIEWPORT:
		glGetDoublev( GL_VIEWPORT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ZOOM_X:
		glGetDoublev( GL_ZOOM_X, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ZOOM_Y:
		glGetDoublev( GL_ZOOM_Y, params );
		*ptr = params[0];
		break;
	default:
		return;
	}

}

void OpenGL_OpenGLwidget_geti(struct HOpenGL_OpenGLwidget *this,
							  long pname,
							  HArrayOfInt *thisParams)
{

	GLint params[16] = { 0, 0, 0, 0,
						 0, 0, 0, 0,
						 0, 0, 0, 0,
						 0, 0, 0, 0 };
	long *ptr = unhand(thisParams)->body;
	int i;

	switch( pname ) {
	case OpenGL_OpenGLwidget_ACCUM_ALPHA_BITS:
		glGetIntegerv( GL_ACCUM_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_BLUE_BITS:
		glGetIntegerv( GL_ACCUM_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_CLEAR_VALUE:
		glGetIntegerv( GL_ACCUM_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ACCUM_GREEN_BITS:
		glGetIntegerv( GL_ACCUM_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_RED_BITS:
		glGetIntegerv( GL_ACCUM_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BIAS:
		glGetIntegerv( GL_ALPHA_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BITS:
		glGetIntegerv( GL_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_SCALE:
		glGetIntegerv( GL_ALPHA_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		glGetIntegerv( GL_ALPHA_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_FUNC:
		glGetIntegerv( GL_ALPHA_TEST_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_REF:
		glGetIntegerv( GL_ALPHA_TEST_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ATTRIB_STACK_DEPTH:
		glGetIntegerv( GL_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		glGetIntegerv( GL_AUTO_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUX_BUFFERS:
		glGetIntegerv( GL_AUX_BUFFERS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND:
		glGetIntegerv( GL_BLEND, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_DST:
		glGetIntegerv( GL_BLEND_DST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_SRC:
		glGetIntegerv( GL_BLEND_SRC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BIAS:
		glGetIntegerv( GL_BLUE_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BITS:
		glGetIntegerv( GL_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_SCALE:
		glGetIntegerv( GL_BLUE_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glGetIntegerv( GL_CLIP_PLANE0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glGetIntegerv( GL_CLIP_PLANE1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glGetIntegerv( GL_CLIP_PLANE2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glGetIntegerv( GL_CLIP_PLANE3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glGetIntegerv( GL_CLIP_PLANE4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glGetIntegerv( GL_CLIP_PLANE5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_CLEAR_VALUE:
		glGetIntegerv( GL_COLOR_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		glGetIntegerv( GL_COLOR_MATERIAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL_PARAMETER:
		glGetIntegerv( GL_COLOR_MATERIAL_PARAMETER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_WRITEMASK:
		glGetIntegerv( GL_COLOR_WRITEMASK, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		glGetIntegerv( GL_CULL_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE_MODE:
		glGetIntegerv( GL_CULL_FACE_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_COLOR:
		glGetIntegerv( GL_CURRENT_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_INDEX:
		glGetIntegerv( GL_CURRENT_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_NORMAL:
		glGetIntegerv( GL_CURRENT_NORMAL, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_COLOR:
		glGetIntegerv( GL_CURRENT_RASTER_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_DISTANCE:
		glGetIntegerv( GL_CURRENT_RASTER_DISTANCE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_INDEX:
		glGetIntegerv( GL_CURRENT_RASTER_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION:
		glGetIntegerv( GL_CURRENT_RASTER_POSITION, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_TEXTURE_COORDS:
		glGetIntegerv( GL_CURRENT_RASTER_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION_VALID:
		glGetIntegerv( GL_CURRENT_RASTER_POSITION_VALID, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_TEXTURE_COORDS:
		glGetIntegerv( GL_CURRENT_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_DEPTH_BIAS:
		glGetIntegerv( GL_DEPTH_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_CLEAR_VALUE:
		glGetIntegerv( GL_DEPTH_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_FUNC:
		glGetIntegerv( GL_DEPTH_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_RANGE:
		glGetIntegerv( GL_DEPTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_DEPTH_SCALE:
		glGetIntegerv( GL_DEPTH_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		glGetIntegerv( GL_DEPTH_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_WRITEMASK:
		glGetIntegerv( GL_DEPTH_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DITHER:
		glGetIntegerv( GL_DITHER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DOUBLEBUFFER:
		glGetIntegerv( GL_DOUBLEBUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DRAW_BUFFER:
		glGetIntegerv( GL_DRAW_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_EDGE_FLAG:
		glGetIntegerv( GL_EDGE_FLAG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG:
		glGetIntegerv( GL_FOG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_COLOR:
		glGetIntegerv( GL_FOG_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glGetIntegerv( GL_FOG_DENSITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glGetIntegerv( GL_FOG_END, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_HINT:
		glGetIntegerv( GL_FOG_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glGetIntegerv( GL_FOG_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_MODE:
		glGetIntegerv( GL_FOG_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glGetIntegerv( GL_FOG_START, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FRONT_FACE:
		glGetIntegerv( GL_FRONT_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BIAS:
		glGetIntegerv( GL_GREEN_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BITS:
		glGetIntegerv( GL_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_SCALE:
		glGetIntegerv( GL_GREEN_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_BITS:
		glGetIntegerv( GL_INDEX_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_CLEAR_VALUE:
		glGetIntegerv( GL_INDEX_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_MODE:
		glGetIntegerv( GL_INDEX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_OFFSET:
		glGetIntegerv( GL_INDEX_OFFSET, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_SHIFT:
		glGetIntegerv( GL_INDEX_SHIFT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_WRITEMASK:
		glGetIntegerv( GL_INDEX_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		glGetIntegerv( GL_LIGHT0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		glGetIntegerv( GL_LIGHT1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		glGetIntegerv( GL_LIGHT2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		glGetIntegerv( GL_LIGHT3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		glGetIntegerv( GL_LIGHT4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		glGetIntegerv( GL_LIGHT5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		glGetIntegerv( GL_LIGHT6, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		glGetIntegerv( GL_LIGHT7, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		glGetIntegerv( GL_LIGHTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		glGetIntegerv( GL_LIGHT_MODEL_AMBIENT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glGetIntegerv( GL_LIGHT_MODEL_LOCAL_VIEWER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glGetIntegerv( GL_LIGHT_MODEL_TWO_SIDE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		glGetIntegerv( GL_LINE_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH_HINT:
		glGetIntegerv( GL_LINE_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		glGetIntegerv( GL_LINE_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_PATTERN:
		glGetIntegerv( GL_LINE_STIPPLE_PATTERN, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_REPEAT:
		glGetIntegerv( GL_LINE_STIPPLE_REPEAT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH:
		glGetIntegerv( GL_LINE_WIDTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_GRANULARITY:
		glGetIntegerv( GL_LINE_WIDTH_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_RANGE:
		glGetIntegerv( GL_LINE_WIDTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_LIST_BASE:
		glGetIntegerv( GL_LIST_BASE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_INDEX:
		glGetIntegerv( GL_LIST_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_MODE:
		glGetIntegerv( GL_LIST_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		glGetIntegerv( GL_LOGIC_OP, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP_MODE:
		glGetIntegerv( GL_LOGIC_OP_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		glGetIntegerv( GL_MAP1_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_DOMAIN:
		glGetIntegerv( GL_MAP1_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_SEGMENTS:
		glGetIntegerv( GL_MAP1_GRID_SEGMENTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		glGetIntegerv( GL_MAP1_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		glGetIntegerv( GL_MAP1_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		glGetIntegerv( GL_MAP1_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		glGetIntegerv( GL_MAP1_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		glGetIntegerv( GL_MAP1_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		glGetIntegerv( GL_MAP1_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		glGetIntegerv( GL_MAP1_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		glGetIntegerv( GL_MAP1_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		glGetIntegerv( GL_MAP2_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_DOMAIN:
		glGetIntegerv( GL_MAP2_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_SEGMENTS:
		glGetIntegerv( GL_MAP2_GRID_SEGMENTS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		glGetIntegerv( GL_MAP2_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		glGetIntegerv( GL_MAP2_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		glGetIntegerv( GL_MAP2_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		glGetIntegerv( GL_MAP2_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		glGetIntegerv( GL_MAP2_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		glGetIntegerv( GL_MAP2_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		glGetIntegerv( GL_MAP2_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		glGetIntegerv( GL_MAP2_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_COLOR:
		glGetIntegerv( GL_MAP_COLOR, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_STENCIL:
		glGetIntegerv( GL_MAP_STENCIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MATRIX_MODE:
		glGetIntegerv( GL_MATRIX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_ATTRIB_STACK_DEPTH:
		glGetIntegerv( GL_MAX_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_CLIP_PLANES:
		glGetIntegerv( GL_MAX_CLIP_PLANES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_EVAL_ORDER:
		glGetIntegerv( GL_MAX_EVAL_ORDER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIGHTS:
		glGetIntegerv( GL_MAX_LIGHTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIST_NESTING:
		glGetIntegerv( GL_MAX_LIST_NESTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_MODELVIEW_STACK_DEPTH:
		glGetIntegerv( GL_MAX_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_NAME_STACK_DEPTH:
		glGetIntegerv( GL_MAX_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PIXEL_MAP_TABLE:
		glGetIntegerv( GL_MAX_PIXEL_MAP_TABLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PROJECTION_STACK_DEPTH:
		glGetIntegerv( GL_MAX_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_SIZE:
		glGetIntegerv( GL_MAX_TEXTURE_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_STACK_DEPTH:
		glGetIntegerv( GL_MAX_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_VIEWPORT_DIMS:
		glGetIntegerv( GL_MAX_VIEWPORT_DIMS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_MATRIX:
		glGetIntegerv( GL_LINE_WIDTH, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_STACK_DEPTH:
		glGetIntegerv( GL_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NAME_STACK_DEPTH:
		glGetIntegerv( GL_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		glGetIntegerv( GL_NORMALIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ALIGNMENT:
		glGetIntegerv( GL_PACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_LSB_FIRST:
		glGetIntegerv( GL_PACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ROW_LENGTH:
		glGetIntegerv( GL_PACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_PIXELS:
		glGetIntegerv( GL_PACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_ROWS:
		glGetIntegerv( GL_PACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SWAP_BYTES:
		glGetIntegerv( GL_PACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PERSPECTIVE_CORRECTION_HINT:
		glGetIntegerv( GL_PERSPECTIVE_CORRECTION_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_A_TO_A_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_A_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_B_TO_B_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_B_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_G_TO_G_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_G_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_A_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_I_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_B_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_I_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_G_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_I_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_I_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_I_TO_I_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_R_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_I_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_R_TO_R_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_R_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_S_TO_S_SIZE:
		glGetIntegerv( GL_PIXEL_MAP_S_TO_S_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE:
		glGetIntegerv( GL_POINT_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_GRANULARITY:
		glGetIntegerv( GL_POINT_SIZE_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_RANGE:
		glGetIntegerv( GL_POINT_SIZE_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		glGetIntegerv( GL_POINT_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH_HINT:
		glGetIntegerv( GL_POINT_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_MODE:
		glGetIntegerv( GL_POLYGON_MODE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		glGetIntegerv( GL_POLYGON_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH_HINT:
		glGetIntegerv( GL_POLYGON_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		glGetIntegerv( GL_POLYGON_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PROJECTION_MATRIX:
		glGetIntegerv( GL_PROJECTION_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_PROJECTION_STACK_DEPTH:
		glGetIntegerv( GL_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_READ_BUFFER:
		glGetIntegerv( GL_READ_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BIAS:
		glGetIntegerv( GL_RED_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BITS:
		glGetIntegerv( GL_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_SCALE:
		glGetIntegerv( GL_RED_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RENDER_MODE:
		glGetIntegerv( GL_RENDER_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RGBA_MODE:
		glGetIntegerv( GL_RGBA_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_BOX:
		glGetIntegerv( GL_SCISSOR_BOX, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		glGetIntegerv( GL_SCISSOR_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SHADE_MODEL:
		glGetIntegerv( GL_SHADE_MODEL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_BITS:
		glGetIntegerv( GL_STENCIL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_CLEAR_VALUE:
		glGetIntegerv( GL_STENCIL_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FAIL:
		glGetIntegerv( GL_STENCIL_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FUNC:
		glGetIntegerv( GL_STENCIL_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_FAIL:
		glGetIntegerv( GL_STENCIL_PASS_DEPTH_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_PASS:
		glGetIntegerv( GL_STENCIL_PASS_DEPTH_PASS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_REF:
		glGetIntegerv( GL_STENCIL_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		glGetIntegerv( GL_STENCIL_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_VALUE_MASK:
		glGetIntegerv( GL_STENCIL_VALUE_MASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_WRITEMASK:
		glGetIntegerv( GL_STENCIL_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STEREO:
		glGetIntegerv( GL_STEREO, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SUBPIXEL_BITS:
		glGetIntegerv( GL_SUBPIXEL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		glGetIntegerv( GL_TEXTURE_1D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		glGetIntegerv( GL_TEXTURE_2D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_COLOR:
		glGetIntegerv( GL_TEXTURE_ENV_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		glGetIntegerv( GL_TEXTURE_ENV_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		glGetIntegerv( GL_TEXTURE_GEN_S, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		glGetIntegerv( GL_TEXTURE_GEN_T, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		glGetIntegerv( GL_TEXTURE_GEN_R, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		glGetIntegerv( GL_TEXTURE_GEN_Q, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_MATRIX:
		glGetIntegerv( GL_TEXTURE_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_TEXTURE_STACK_DEPTH:
		glGetIntegerv( GL_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ALIGNMENT:
		glGetIntegerv( GL_UNPACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_LSB_FIRST:
		glGetIntegerv( GL_UNPACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ROW_LENGTH:
		glGetIntegerv( GL_UNPACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_PIXELS:
		glGetIntegerv( GL_UNPACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_ROWS:
		glGetIntegerv( GL_UNPACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SWAP_BYTES:
		glGetIntegerv( GL_UNPACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_VIEWPORT:
		glGetIntegerv( GL_VIEWPORT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ZOOM_X:
		glGetIntegerv( GL_ZOOM_X, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ZOOM_Y:
		glGetIntegerv( GL_ZOOM_Y, params );
		*ptr = params[0];
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_getf(struct HOpenGL_OpenGLwidget *this,
							  long pname,
							  HArrayOfFloat *thisParams)
{

	GLfloat params[16] = { 0.0, 0.0, 0.0, 0.0,
						   0.0, 0.0, 0.0, 0.0,
						   0.0, 0.0, 0.0, 0.0,
						   0.0, 0.0, 0.0, 0.0 };
	float *ptr = unhand(thisParams)->body;
	int i;

	switch( pname ) {
	case OpenGL_OpenGLwidget_ACCUM_ALPHA_BITS:
		glGetFloatv( GL_ACCUM_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_BLUE_BITS:
		glGetFloatv( GL_ACCUM_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_CLEAR_VALUE:
		glGetFloatv( GL_ACCUM_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ACCUM_GREEN_BITS:
		glGetFloatv( GL_ACCUM_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ACCUM_RED_BITS:
		glGetFloatv( GL_ACCUM_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BIAS:
		glGetFloatv( GL_ALPHA_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_BITS:
		glGetFloatv( GL_ALPHA_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_SCALE:
		glGetFloatv( GL_ALPHA_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		glGetFloatv( GL_ALPHA_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_FUNC:
		glGetFloatv( GL_ALPHA_TEST_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ALPHA_TEST_REF:
		glGetFloatv( GL_ALPHA_TEST_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ATTRIB_STACK_DEPTH:
		glGetFloatv( GL_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		glGetFloatv( GL_AUTO_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_AUX_BUFFERS:
		glGetFloatv( GL_AUX_BUFFERS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND:
		glGetFloatv( GL_BLEND, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_DST:
		glGetFloatv( GL_BLEND_DST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLEND_SRC:
		glGetFloatv( GL_BLEND_SRC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BIAS:
		glGetFloatv( GL_BLUE_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_BITS:
		glGetFloatv( GL_BLUE_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_BLUE_SCALE:
		glGetFloatv( GL_BLUE_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		glGetFloatv( GL_CLIP_PLANE0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		glGetFloatv( GL_CLIP_PLANE1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		glGetFloatv( GL_CLIP_PLANE2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		glGetFloatv( GL_CLIP_PLANE3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		glGetFloatv( GL_CLIP_PLANE4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		glGetFloatv( GL_CLIP_PLANE5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_CLEAR_VALUE:
		glGetFloatv( GL_COLOR_CLEAR_VALUE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		glGetFloatv( GL_COLOR_MATERIAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL_PARAMETER:
		glGetFloatv( GL_COLOR_MATERIAL_PARAMETER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_COLOR_WRITEMASK:
		glGetFloatv( GL_COLOR_WRITEMASK, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		glGetFloatv( GL_CULL_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CULL_FACE_MODE:
		glGetFloatv( GL_CULL_FACE_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_COLOR:
		glGetFloatv( GL_CURRENT_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_INDEX:
		glGetFloatv( GL_CURRENT_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_NORMAL:
		glGetFloatv( GL_CURRENT_NORMAL, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_COLOR:
		glGetFloatv( GL_CURRENT_RASTER_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_DISTANCE:
		glGetFloatv( GL_CURRENT_RASTER_DISTANCE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_INDEX:
		glGetFloatv( GL_CURRENT_RASTER_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION:
		glGetFloatv( GL_CURRENT_RASTER_POSITION, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_TEXTURE_COORDS:
		glGetFloatv( GL_CURRENT_RASTER_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_CURRENT_RASTER_POSITION_VALID:
		glGetFloatv( GL_CURRENT_RASTER_POSITION_VALID, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_CURRENT_TEXTURE_COORDS:
		glGetFloatv( GL_CURRENT_TEXTURE_COORDS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_DEPTH_BIAS:
		glGetFloatv( GL_DEPTH_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_CLEAR_VALUE:
		glGetFloatv( GL_DEPTH_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_FUNC:
		glGetFloatv( GL_DEPTH_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_RANGE:
		glGetFloatv( GL_DEPTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_DEPTH_SCALE:
		glGetFloatv( GL_DEPTH_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		glGetFloatv( GL_DEPTH_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DEPTH_WRITEMASK:
		glGetFloatv( GL_DEPTH_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DITHER:
		glGetFloatv( GL_DITHER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DOUBLEBUFFER:
		glGetFloatv( GL_DOUBLEBUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_DRAW_BUFFER:
		glGetFloatv( GL_DRAW_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_EDGE_FLAG:
		glGetFloatv( GL_EDGE_FLAG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG:
		glGetFloatv( GL_FOG, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_COLOR:
		glGetFloatv( GL_FOG_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_FOG_DENSITY:
		glGetFloatv( GL_FOG_DENSITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_END:
		glGetFloatv( GL_FOG_END, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_HINT:
		glGetFloatv( GL_FOG_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_INDEX:
		glGetFloatv( GL_FOG_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_MODE:
		glGetFloatv( GL_FOG_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FOG_START:
		glGetFloatv( GL_FOG_START, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_FRONT_FACE:
		glGetFloatv( GL_FRONT_FACE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BIAS:
		glGetFloatv( GL_GREEN_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_BITS:
		glGetFloatv( GL_GREEN_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_GREEN_SCALE:
		glGetFloatv( GL_GREEN_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_BITS:
		glGetFloatv( GL_INDEX_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_CLEAR_VALUE:
		glGetFloatv( GL_INDEX_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_MODE:
		glGetFloatv( GL_INDEX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_OFFSET:
		glGetFloatv( GL_INDEX_OFFSET, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_SHIFT:
		glGetFloatv( GL_INDEX_SHIFT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_INDEX_WRITEMASK:
		glGetFloatv( GL_INDEX_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		glGetFloatv( GL_LIGHT0, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		glGetFloatv( GL_LIGHT1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		glGetFloatv( GL_LIGHT2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		glGetFloatv( GL_LIGHT3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		glGetFloatv( GL_LIGHT4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		glGetFloatv( GL_LIGHT5, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		glGetFloatv( GL_LIGHT6, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		glGetFloatv( GL_LIGHT7, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		glGetFloatv( GL_LIGHTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		glGetFloatv( GL_LIGHT_MODEL_AMBIENT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glGetFloatv( GL_LIGHT_MODEL_LOCAL_VIEWER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glGetFloatv( GL_LIGHT_MODEL_TWO_SIDE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		glGetFloatv( GL_LINE_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH_HINT:
		glGetFloatv( GL_LINE_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		glGetFloatv( GL_LINE_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_PATTERN:
		glGetFloatv( GL_LINE_STIPPLE_PATTERN, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE_REPEAT:
		glGetFloatv( GL_LINE_STIPPLE_REPEAT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH:
		glGetFloatv( GL_LINE_WIDTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_GRANULARITY:
		glGetFloatv( GL_LINE_WIDTH_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LINE_WIDTH_RANGE:
		glGetFloatv( GL_LINE_WIDTH_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_LIST_BASE:
		glGetFloatv( GL_LIST_BASE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_INDEX:
		glGetFloatv( GL_LIST_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LIST_MODE:
		glGetFloatv( GL_LIST_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		glGetFloatv( GL_LOGIC_OP, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP_MODE:
		glGetFloatv( GL_LOGIC_OP_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		glGetFloatv( GL_MAP1_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_DOMAIN:
		glGetFloatv( GL_MAP1_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP1_GRID_SEGMENTS:
		glGetFloatv( GL_MAP1_GRID_SEGMENTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		glGetFloatv( GL_MAP1_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		glGetFloatv( GL_MAP1_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		glGetFloatv( GL_MAP1_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		glGetFloatv( GL_MAP1_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		glGetFloatv( GL_MAP1_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		glGetFloatv( GL_MAP1_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		glGetFloatv( GL_MAP1_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		glGetFloatv( GL_MAP1_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		glGetFloatv( GL_MAP2_COLOR_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_DOMAIN:
		glGetFloatv( GL_MAP2_GRID_DOMAIN, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_MAP2_GRID_SEGMENTS:
		glGetFloatv( GL_MAP2_GRID_SEGMENTS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		glGetFloatv( GL_MAP2_INDEX, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		glGetFloatv( GL_MAP2_NORMAL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		glGetFloatv( GL_MAP2_TEXTURE_COORD_1, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		glGetFloatv( GL_MAP2_TEXTURE_COORD_2, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		glGetFloatv( GL_MAP2_TEXTURE_COORD_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		glGetFloatv( GL_MAP2_TEXTURE_COORD_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		glGetFloatv( GL_MAP2_VERTEX_3, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		glGetFloatv( GL_MAP2_VERTEX_4, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_COLOR:
		glGetFloatv( GL_MAP_COLOR, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAP_STENCIL:
		glGetFloatv( GL_MAP_STENCIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MATRIX_MODE:
		glGetFloatv( GL_MATRIX_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_ATTRIB_STACK_DEPTH:
		glGetFloatv( GL_MAX_ATTRIB_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_CLIP_PLANES:
		glGetFloatv( GL_MAX_CLIP_PLANES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_EVAL_ORDER:
		glGetFloatv( GL_MAX_EVAL_ORDER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIGHTS:
		glGetFloatv( GL_MAX_LIGHTS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_LIST_NESTING:
		glGetFloatv( GL_MAX_LIST_NESTING, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_MODELVIEW_STACK_DEPTH:
		glGetFloatv( GL_MAX_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_NAME_STACK_DEPTH:
		glGetFloatv( GL_MAX_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PIXEL_MAP_TABLE:
		glGetFloatv( GL_MAX_PIXEL_MAP_TABLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_PROJECTION_STACK_DEPTH:
		glGetFloatv( GL_MAX_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_SIZE:
		glGetFloatv( GL_MAX_TEXTURE_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_TEXTURE_STACK_DEPTH:
		glGetFloatv( GL_MAX_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_MAX_VIEWPORT_DIMS:
		glGetFloatv( GL_MAX_VIEWPORT_DIMS, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_MATRIX:
		glGetFloatv( GL_LINE_WIDTH, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_MODELVIEW_STACK_DEPTH:
		glGetFloatv( GL_MODELVIEW_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NAME_STACK_DEPTH:
		glGetFloatv( GL_NAME_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		glGetFloatv( GL_NORMALIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ALIGNMENT:
		glGetFloatv( GL_PACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_LSB_FIRST:
		glGetFloatv( GL_PACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_ROW_LENGTH:
		glGetFloatv( GL_PACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_PIXELS:
		glGetFloatv( GL_PACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SKIP_ROWS:
		glGetFloatv( GL_PACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PACK_SWAP_BYTES:
		glGetFloatv( GL_PACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PERSPECTIVE_CORRECTION_HINT:
		glGetFloatv( GL_PERSPECTIVE_CORRECTION_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_A_TO_A_SIZE:
		glGetFloatv( GL_PIXEL_MAP_A_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_B_TO_B_SIZE:
		glGetFloatv( GL_PIXEL_MAP_B_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_G_TO_G_SIZE:
		glGetFloatv( GL_PIXEL_MAP_G_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_A_SIZE:
		glGetFloatv( GL_PIXEL_MAP_I_TO_A_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_B_SIZE:
		glGetFloatv( GL_PIXEL_MAP_I_TO_B_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_G_SIZE:
		glGetFloatv( GL_PIXEL_MAP_I_TO_G_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_I_SIZE:
		glGetFloatv( GL_PIXEL_MAP_I_TO_I_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_I_TO_R_SIZE:
		glGetFloatv( GL_PIXEL_MAP_I_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_R_TO_R_SIZE:
		glGetFloatv( GL_PIXEL_MAP_R_TO_R_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PIXEL_MAP_S_TO_S_SIZE:
		glGetFloatv( GL_PIXEL_MAP_S_TO_S_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE:
		glGetFloatv( GL_POINT_SIZE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_GRANULARITY:
		glGetFloatv( GL_POINT_SIZE_GRANULARITY, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SIZE_RANGE:
		glGetFloatv( GL_POINT_SIZE_RANGE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		glGetFloatv( GL_POINT_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH_HINT:
		glGetFloatv( GL_POINT_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_MODE:
		glGetFloatv( GL_POLYGON_MODE, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		glGetFloatv( GL_POLYGON_SMOOTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH_HINT:
		glGetFloatv( GL_POLYGON_SMOOTH_HINT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		glGetFloatv( GL_POLYGON_STIPPLE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_PROJECTION_MATRIX:
		glGetFloatv( GL_PROJECTION_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_PROJECTION_STACK_DEPTH:
		glGetFloatv( GL_PROJECTION_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_READ_BUFFER:
		glGetFloatv( GL_READ_BUFFER, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BIAS:
		glGetFloatv( GL_RED_BIAS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_BITS:
		glGetFloatv( GL_RED_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RED_SCALE:
		glGetFloatv( GL_RED_SCALE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RENDER_MODE:
		glGetFloatv( GL_RENDER_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_RGBA_MODE:
		glGetFloatv( GL_RGBA_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_BOX:
		glGetFloatv( GL_SCISSOR_BOX, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		glGetFloatv( GL_SCISSOR_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SHADE_MODEL:
		glGetFloatv( GL_SHADE_MODEL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_BITS:
		glGetFloatv( GL_STENCIL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_CLEAR_VALUE:
		glGetFloatv( GL_STENCIL_CLEAR_VALUE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FAIL:
		glGetFloatv( GL_STENCIL_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_FUNC:
		glGetFloatv( GL_STENCIL_FUNC, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_FAIL:
		glGetFloatv( GL_STENCIL_PASS_DEPTH_FAIL, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_PASS_DEPTH_PASS:
		glGetFloatv( GL_STENCIL_PASS_DEPTH_PASS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_REF:
		glGetFloatv( GL_STENCIL_REF, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		glGetFloatv( GL_STENCIL_TEST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_VALUE_MASK:
		glGetFloatv( GL_STENCIL_VALUE_MASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STENCIL_WRITEMASK:
		glGetFloatv( GL_STENCIL_WRITEMASK, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_STEREO:
		glGetFloatv( GL_STEREO, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_SUBPIXEL_BITS:
		glGetFloatv( GL_SUBPIXEL_BITS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		glGetFloatv( GL_TEXTURE_1D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		glGetFloatv( GL_TEXTURE_2D, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_COLOR:
		glGetFloatv( GL_TEXTURE_ENV_COLOR, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		glGetFloatv( GL_TEXTURE_ENV_MODE, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		glGetFloatv( GL_TEXTURE_GEN_S, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		glGetFloatv( GL_TEXTURE_GEN_T, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		glGetFloatv( GL_TEXTURE_GEN_R, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		glGetFloatv( GL_TEXTURE_GEN_Q, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_TEXTURE_MATRIX:
		glGetFloatv( GL_TEXTURE_MATRIX, params );
		for( i=0; i < 16; i++ ) {
			*ptr = params[i];
			ptr++;
		}
		break;
	case OpenGL_OpenGLwidget_TEXTURE_STACK_DEPTH:
		glGetFloatv( GL_TEXTURE_STACK_DEPTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ALIGNMENT:
		glGetFloatv( GL_UNPACK_ALIGNMENT, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_LSB_FIRST:
		glGetFloatv( GL_UNPACK_LSB_FIRST, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_ROW_LENGTH:
		glGetFloatv( GL_UNPACK_ROW_LENGTH, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_PIXELS:
		glGetFloatv( GL_UNPACK_SKIP_PIXELS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SKIP_ROWS:
		glGetFloatv( GL_UNPACK_SKIP_ROWS, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_UNPACK_SWAP_BYTES:
		glGetFloatv( GL_UNPACK_SWAP_BYTES, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_VIEWPORT:
		glGetFloatv( GL_VIEWPORT, params );
		*ptr = params[0];
		ptr++;
		*ptr = params[1];
		ptr++;
		*ptr = params[2];
		ptr++;
		*ptr = params[3];
		break;
	case OpenGL_OpenGLwidget_ZOOM_X:
		glGetFloatv( GL_ZOOM_X, params );
		*ptr = params[0];
		break;
	case OpenGL_OpenGLwidget_ZOOM_Y:
		glGetFloatv( GL_ZOOM_Y, params );
		*ptr = params[0];
		break;
	default:
		return;
	}
}

/* TO DO: glGenLists */

void OpenGL_OpenGLwidget_hint(struct HOpenGL_OpenGLwidget *this,
									long target,
									long mode)
{
	GLenum gl_target, gl_mode;
	switch( target ) {
	case OpenGL_OpenGLwidget_FOG_HINT:
		gl_target = GL_FOG_HINT;
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH_HINT:
		gl_target = GL_LINE_SMOOTH_HINT;
		break;
	case OpenGL_OpenGLwidget_PERSPECTIVE_CORRECTION_HINT:
		gl_target = GL_PERSPECTIVE_CORRECTION_HINT;
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH_HINT:
		gl_target = GL_POINT_SMOOTH_HINT;
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH_HINT:
		gl_target = GL_POLYGON_SMOOTH_HINT;
		break;
	default:
		return;
	}
	switch( mode ) {
	case OpenGL_OpenGLwidget_FASTEST:
		gl_mode = GL_FASTEST;
		break;
	case OpenGL_OpenGLwidget_NICEST:
		gl_mode = GL_NICEST;
		break;
	case OpenGL_OpenGLwidget_DONT_CARE:
		gl_mode = GL_DONT_CARE;
		break;
	default:
		return;
	}
	glHint( gl_target, gl_mode );
}

void OpenGL_OpenGLwidget_indexd(struct HOpenGL_OpenGLwidget *this,
									double c)
{
	glIndexd( c );
}

void OpenGL_OpenGLwidget_indexf(struct HOpenGL_OpenGLwidget *this,
									float c)
{
	glIndexf( c );
}

void OpenGL_OpenGLwidget_indexi(struct HOpenGL_OpenGLwidget *this,
									long c)
{
	glIndexi( (GLint) c );
}

void OpenGL_OpenGLwidget_indexs(struct HOpenGL_OpenGLwidget *this,
									short c)
{
	glIndexs( c );
}

void OpenGL_OpenGLwidget_indexMask(struct HOpenGL_OpenGLwidget *this,
									long mask)
{
	glIndexMask( (GLuint)mask );
}

/* TO DO: glInitNames */

/*boolean*/ long OpenGL_OpenGLwidget_isEnabled(
									struct HOpenGL_OpenGLwidget *this,
									long cap)
{
	GLboolean retval;

	switch( cap ) {
	case OpenGL_OpenGLwidget_ALPHA_TEST:
		retval = glIsEnabled( GL_ALPHA_TEST );
		break;
	case OpenGL_OpenGLwidget_AUTO_NORMAL:
		retval = glIsEnabled( GL_AUTO_NORMAL );
		break;
	case OpenGL_OpenGLwidget_BLEND:
		retval = glIsEnabled( GL_BLEND );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE0:
		retval = glIsEnabled( GL_CLIP_PLANE0 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE1:
		retval = glIsEnabled( GL_CLIP_PLANE1 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE2:
		retval = glIsEnabled( GL_CLIP_PLANE2 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE3:
		retval = glIsEnabled( GL_CLIP_PLANE3 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE4:
		retval = glIsEnabled( GL_CLIP_PLANE4 );
		break;
	case OpenGL_OpenGLwidget_CLIP_PLANE5:
		retval = glIsEnabled( GL_CLIP_PLANE5 );
		break;
	case OpenGL_OpenGLwidget_COLOR_MATERIAL:
		retval = glIsEnabled( GL_COLOR_MATERIAL );
		break;
	case OpenGL_OpenGLwidget_CULL_FACE:
		retval = glIsEnabled( GL_CULL_FACE );
		break;
	case OpenGL_OpenGLwidget_DEPTH_TEST:
		retval = glIsEnabled( GL_DEPTH_TEST );
		break;
	case OpenGL_OpenGLwidget_DITHER:
		retval = glIsEnabled( GL_DITHER );
		break;
	case OpenGL_OpenGLwidget_FOG:
		retval = glIsEnabled( GL_FOG );
		break;
	case OpenGL_OpenGLwidget_LIGHT0:
		retval = glIsEnabled( GL_LIGHT0 );
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		retval = glIsEnabled( GL_LIGHT1 );
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		retval = glIsEnabled( GL_LIGHT2 );
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		retval = glIsEnabled( GL_LIGHT3 );
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		retval = glIsEnabled( GL_LIGHT4 );
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		retval = glIsEnabled( GL_LIGHT5 );
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		retval = glIsEnabled( GL_LIGHT6 );
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		retval = glIsEnabled( GL_LIGHT7 );
		break;
	case OpenGL_OpenGLwidget_LIGHTING:
		retval = glIsEnabled( GL_LIGHTING );
		break;
	case OpenGL_OpenGLwidget_LINE_SMOOTH:
		retval = glIsEnabled( GL_LINE_SMOOTH );
		break;
	case OpenGL_OpenGLwidget_LINE_STIPPLE:
		retval = glIsEnabled( GL_LINE_STIPPLE );
		break;
	case OpenGL_OpenGLwidget_LOGIC_OP:
		retval = glIsEnabled( GL_LOGIC_OP );
		break;
	case OpenGL_OpenGLwidget_MAP1_COLOR_4:
		retval = glIsEnabled( GL_MAP1_COLOR_4 );
		break;
	case OpenGL_OpenGLwidget_MAP1_INDEX:
		retval = glIsEnabled( GL_MAP1_INDEX );
		break;
	case OpenGL_OpenGLwidget_MAP1_NORMAL:
		retval = glIsEnabled( GL_MAP1_NORMAL);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_1:
		retval = glIsEnabled( GL_MAP1_TEXTURE_COORD_1);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_2:
		retval = glIsEnabled( GL_MAP1_TEXTURE_COORD_2);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_3:
		retval = glIsEnabled( GL_MAP1_TEXTURE_COORD_3);
		break;
	case OpenGL_OpenGLwidget_MAP1_TEXTURE_COORD_4:
		retval = glIsEnabled( GL_MAP1_TEXTURE_COORD_4);
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_3:
		retval = glIsEnabled( GL_MAP1_VERTEX_3);
		break;
	case OpenGL_OpenGLwidget_MAP1_VERTEX_4:
		retval = glIsEnabled( GL_MAP1_VERTEX_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_COLOR_4:
		retval = glIsEnabled( GL_MAP2_COLOR_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_INDEX:
		retval = glIsEnabled( GL_MAP2_INDEX);
		break;
	case OpenGL_OpenGLwidget_MAP2_NORMAL:
		retval = glIsEnabled( GL_MAP2_NORMAL);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_1:
		retval = glIsEnabled( GL_MAP2_TEXTURE_COORD_1);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_2:
		retval = glIsEnabled( GL_MAP2_TEXTURE_COORD_2);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_3:
		retval = glIsEnabled( GL_MAP2_TEXTURE_COORD_3);
		break;
	case OpenGL_OpenGLwidget_MAP2_TEXTURE_COORD_4:
		retval = glIsEnabled( GL_MAP2_TEXTURE_COORD_4);
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_3:
		retval = glIsEnabled( GL_MAP2_VERTEX_3);
		break;
	case OpenGL_OpenGLwidget_MAP2_VERTEX_4:
		retval = glIsEnabled( GL_MAP2_VERTEX_4);
		break;
	case OpenGL_OpenGLwidget_NORMALIZE:
		retval = glIsEnabled( GL_NORMALIZE);
		break;
	case OpenGL_OpenGLwidget_POINT_SMOOTH:
		retval = glIsEnabled( GL_POINT_SMOOTH);
		break;
	case OpenGL_OpenGLwidget_POLYGON_SMOOTH:
		retval = glIsEnabled( GL_POLYGON_SMOOTH);
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE:
		retval = glIsEnabled( GL_POLYGON_STIPPLE);
		break;
	case OpenGL_OpenGLwidget_SCISSOR_TEST:
		retval = glIsEnabled( GL_SCISSOR_TEST);
		break;
	case OpenGL_OpenGLwidget_STENCIL_TEST:
		retval = glIsEnabled( GL_STENCIL_TEST);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_1D:
		retval = glIsEnabled( GL_TEXTURE_1D);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_2D:
		retval = glIsEnabled( GL_TEXTURE_2D);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_Q:
		retval = glIsEnabled( GL_TEXTURE_GEN_Q);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_R:
		retval = glIsEnabled( GL_TEXTURE_GEN_R);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_S:
		retval = glIsEnabled( GL_TEXTURE_GEN_S);
		break;
	case OpenGL_OpenGLwidget_TEXTURE_GEN_T:
		retval = glIsEnabled( GL_TEXTURE_GEN_T);
		break;
	default:
		return;
	}
	if( retval == GL_TRUE )
		return 1;

	return 0;
}

/* TO DO: glIsList */

void OpenGL_OpenGLwidget_lightf(struct HOpenGL_OpenGLwidget *this,
									long light,
									long pname,
									float param)
{
	GLenum gl_lightnum, gl_pname;

	switch( light ) {
	case OpenGL_OpenGLwidget_LIGHT0:
		gl_lightnum = GL_LIGHT0;
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		gl_lightnum = GL_LIGHT1;
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		gl_lightnum = GL_LIGHT2;
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		gl_lightnum = GL_LIGHT3;
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		gl_lightnum = GL_LIGHT4;
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		gl_lightnum = GL_LIGHT5;
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		gl_lightnum = GL_LIGHT6;
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		gl_lightnum = GL_LIGHT7;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_SPOT_EXPONENT:
		gl_pname = GL_SPOT_EXPONENT;
		break;
	case OpenGL_OpenGLwidget_SPOT_CUTOFF:
		gl_pname = GL_SPOT_CUTOFF;
		break;
	case OpenGL_OpenGLwidget_CONSTANT_ATTENUATION:
		gl_pname = GL_CONSTANT_ATTENUATION;
		break;
	case OpenGL_OpenGLwidget_LINEAR_ATTENUATION:
		gl_pname = GL_LINEAR_ATTENUATION;
		break;
	case OpenGL_OpenGLwidget_QUADRATIC_ATTENUATION:
		gl_pname = GL_QUADRATIC_ATTENUATION;
		break;
	default:
		return;
	}
	glLightf( gl_lightnum, gl_pname, param );
}

void OpenGL_OpenGLwidget_lighti(struct HOpenGL_OpenGLwidget *this,
									long light,
									long pname,
									long param)
{
	GLenum gl_lightnum, gl_pname;

	switch( light ) {
	case OpenGL_OpenGLwidget_LIGHT0:
		gl_lightnum = GL_LIGHT0;
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		gl_lightnum = GL_LIGHT1;
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		gl_lightnum = GL_LIGHT2;
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		gl_lightnum = GL_LIGHT3;
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		gl_lightnum = GL_LIGHT4;
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		gl_lightnum = GL_LIGHT5;
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		gl_lightnum = GL_LIGHT6;
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		gl_lightnum = GL_LIGHT7;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_SPOT_EXPONENT:
		gl_pname = GL_SPOT_EXPONENT;
		break;
	case OpenGL_OpenGLwidget_SPOT_CUTOFF:
		gl_pname = GL_SPOT_CUTOFF;
		break;
	case OpenGL_OpenGLwidget_CONSTANT_ATTENUATION:
		gl_pname = GL_CONSTANT_ATTENUATION;
		break;
	case OpenGL_OpenGLwidget_LINEAR_ATTENUATION:
		gl_pname = GL_LINEAR_ATTENUATION;
		break;
	case OpenGL_OpenGLwidget_QUADRATIC_ATTENUATION:
		gl_pname = GL_QUADRATIC_ATTENUATION;
		break;
	default:
		return;
	}
	glLightf( gl_lightnum, gl_pname, (GLint)param );
}

void OpenGL_OpenGLwidget_lightiv(struct HOpenGL_OpenGLwidget *this,
								long light,
								long pname,
								long param1, long param2, long param3, 
								long param4 )
{
	GLenum gl_lightnum, gl_pname;
	GLint  gl_params[4];

	gl_params[0] = param1; gl_params[1] = param2;
	gl_params[2] = param3; gl_params[3] = param4;

	switch( light ) {
	case OpenGL_OpenGLwidget_LIGHT0:
		gl_lightnum = GL_LIGHT0;
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		gl_lightnum = GL_LIGHT1;
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		gl_lightnum = GL_LIGHT2;
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		gl_lightnum = GL_LIGHT3;
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		gl_lightnum = GL_LIGHT4;
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		gl_lightnum = GL_LIGHT5;
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		gl_lightnum = GL_LIGHT6;
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		gl_lightnum = GL_LIGHT7;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_AMBIENT:
		gl_pname = GL_AMBIENT; break;
	case OpenGL_OpenGLwidget_DIFFUSE:
		gl_pname = GL_DIFFUSE; break;
	case OpenGL_OpenGLwidget_SPECULAR:
		gl_pname = GL_SPECULAR; break;
	case OpenGL_OpenGLwidget_POSITION:
		gl_pname = GL_POSITION; break;
	case OpenGL_OpenGLwidget_SPOT_DIRECTION:
		gl_pname = GL_SPOT_DIRECTION; break;
	case OpenGL_OpenGLwidget_CONSTANT_ATTENUATION:
		gl_pname = GL_CONSTANT_ATTENUATION; break;
	case OpenGL_OpenGLwidget_LINEAR_ATTENUATION:
		gl_pname = GL_LINEAR_ATTENUATION; break;
	case OpenGL_OpenGLwidget_QUADRATIC_ATTENUATION:
		gl_pname = GL_QUADRATIC_ATTENUATION; break;
	case OpenGL_OpenGLwidget_SPOT_EXPONENT:
		gl_pname = GL_SPOT_EXPONENT; break;
	case OpenGL_OpenGLwidget_SPOT_CUTOFF:
		gl_pname = GL_SPOT_CUTOFF; break;
	}
	glLightiv( gl_lightnum, gl_pname, gl_params );
}

void OpenGL_OpenGLwidget_lightfv(struct HOpenGL_OpenGLwidget *this,
								long light,
								long pname,
								float param1, float param2, float param3, 
								float param4 )
{
	GLenum gl_lightnum, gl_pname;
	GLfloat  gl_params[4];

	gl_params[0] = param1; gl_params[1] = param2;
	gl_params[2] = param3; gl_params[3] = param4;

	switch( light ) {
	case OpenGL_OpenGLwidget_LIGHT0:
		gl_lightnum = GL_LIGHT0;
		break;
	case OpenGL_OpenGLwidget_LIGHT1:
		gl_lightnum = GL_LIGHT1;
		break;
	case OpenGL_OpenGLwidget_LIGHT2:
		gl_lightnum = GL_LIGHT2;
		break;
	case OpenGL_OpenGLwidget_LIGHT3:
		gl_lightnum = GL_LIGHT3;
		break;
	case OpenGL_OpenGLwidget_LIGHT4:
		gl_lightnum = GL_LIGHT4;
		break;
	case OpenGL_OpenGLwidget_LIGHT5:
		gl_lightnum = GL_LIGHT5;
		break;
	case OpenGL_OpenGLwidget_LIGHT6:
		gl_lightnum = GL_LIGHT6;
		break;
	case OpenGL_OpenGLwidget_LIGHT7:
		gl_lightnum = GL_LIGHT7;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_AMBIENT:
		gl_pname = GL_AMBIENT; break;
	case OpenGL_OpenGLwidget_DIFFUSE:
		gl_pname = GL_DIFFUSE; break;
	case OpenGL_OpenGLwidget_SPECULAR:
		gl_pname = GL_SPECULAR; break;
	case OpenGL_OpenGLwidget_POSITION:
		gl_pname = GL_POSITION; break;
	case OpenGL_OpenGLwidget_SPOT_DIRECTION:
		gl_pname = GL_SPOT_DIRECTION; break;
	case OpenGL_OpenGLwidget_CONSTANT_ATTENUATION:
		gl_pname = GL_CONSTANT_ATTENUATION; break;
	case OpenGL_OpenGLwidget_LINEAR_ATTENUATION:
		gl_pname = GL_LINEAR_ATTENUATION; break;
	case OpenGL_OpenGLwidget_QUADRATIC_ATTENUATION:
		gl_pname = GL_QUADRATIC_ATTENUATION; break;
	case OpenGL_OpenGLwidget_SPOT_EXPONENT:
		gl_pname = GL_SPOT_EXPONENT; break;
	case OpenGL_OpenGLwidget_SPOT_CUTOFF:
		gl_pname = GL_SPOT_CUTOFF; break;
	}
	glLightfv( gl_lightnum, gl_pname, gl_params );
}

void OpenGL_OpenGLwidget_lightModeli(struct HOpenGL_OpenGLwidget *this,
									long pname,
									long param )
{
	switch( pname ) {
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glLightModelf( GL_LIGHT_MODEL_TWO_SIDE, (GLint) param );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glLightModelf( GL_LIGHT_MODEL_LOCAL_VIEWER, (GLint) param );
		break;
	}
}

void OpenGL_OpenGLwidget_lightModelf(struct HOpenGL_OpenGLwidget *this,
									long pname,
									float param )
{
	switch( pname ) {
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		glLightModelf( GL_LIGHT_MODEL_TWO_SIDE, (GLint) param );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		glLightModelf( GL_LIGHT_MODEL_LOCAL_VIEWER, (GLint) param );
		break;
	}
}

void OpenGL_OpenGLwidget_lightModeliv(struct HOpenGL_OpenGLwidget *this,
									long pname,
									HArrayOfInt *params )
{
	GLint gl_params[4] = {0,0,0,0};
	switch( pname ) {
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		gl_params[0] = (GLint)(unhand(params)->body[0]);
		gl_params[1] = (GLint)(unhand(params)->body[1]);
		gl_params[2] = (GLint)(unhand(params)->body[2]);
		gl_params[3] = (GLint)(unhand(params)->body[3]);
		glLightModeliv( GL_LIGHT_MODEL_AMBIENT, gl_params );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		gl_params[0] = (GLint)(unhand(params)->body[0]);
		glLightModeliv( GL_LIGHT_MODEL_LOCAL_VIEWER, gl_params );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		gl_params[0] = (GLint)(unhand(params)->body[0]);
		glLightModeliv( GL_LIGHT_MODEL_TWO_SIDE, gl_params );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_lightModelfv(struct HOpenGL_OpenGLwidget *this,
									long pname,
									HArrayOfFloat *params )
{
	GLfloat gl_params[4] = {0,0,0,0};
	switch( pname ) {
	case OpenGL_OpenGLwidget_LIGHT_MODEL_AMBIENT:
		gl_params[0] = (GLfloat)(unhand(params)->body[0]);
		gl_params[1] = (GLfloat)(unhand(params)->body[1]);
		gl_params[2] = (GLfloat)(unhand(params)->body[2]);
		gl_params[3] = (GLfloat)(unhand(params)->body[3]);
		glLightModelfv( GL_LIGHT_MODEL_AMBIENT, gl_params );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_LOCAL_VIEWER:
		gl_params[0] = (GLfloat)(unhand(params)->body[0]);
		glLightModelfv( GL_LIGHT_MODEL_LOCAL_VIEWER, gl_params );
		break;
	case OpenGL_OpenGLwidget_LIGHT_MODEL_TWO_SIDE:
		gl_params[0] = (GLfloat)(unhand(params)->body[0]);
		glLightModelfv( GL_LIGHT_MODEL_TWO_SIDE, gl_params );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_lineStipple(struct HOpenGL_OpenGLwidget *this,
									long factor,
									short pattern)
{
	glLineStipple( (GLint) factor, pattern );
}

void OpenGL_OpenGLwidget_lineWidth(struct HOpenGL_OpenGLwidget *this,
									float width)
{
	glLineWidth( width );
}

void OpenGL_OpenGLwidget_loadIdentity(struct HOpenGL_OpenGLwidget *this)
{
	glLoadIdentity();
}

void OpenGL_OpenGLwidget_loadMatrixd(struct HOpenGL_OpenGLwidget *this,
									HArrayOfDouble *thisDarr )
{
	double *ptr = unhand(thisDarr)->body;
	glLoadMatrixd( ptr );
}

void OpenGL_OpenGLwidget_loadMatrixf(struct HOpenGL_OpenGLwidget *this,
									HArrayOfFloat *thisFarr )
{
	float *ptr = unhand(thisFarr)->body;
	glLoadMatrixf( ptr );
}

void OpenGL_OpenGLwidget_loadName(struct HOpenGL_OpenGLwidget *this,
									long name )
{
	glLoadName( (GLuint) name );
}

void OpenGL_OpenGLwidget_logicOp(struct HOpenGL_OpenGLwidget *this,
									long opcode)
{
	switch( opcode ) {
	case OpenGL_OpenGLwidget_CLEAR:
		glLogicOp( GL_CLEAR );
		break;
	case OpenGL_OpenGLwidget_SET:
		glLogicOp( GL_SET );
		break;
	case OpenGL_OpenGLwidget_COPY:
		glLogicOp( GL_COPY );
		break;
	case OpenGL_OpenGLwidget_COPY_INVERTED:
		glLogicOp( GL_COPY_INVERTED );
		break;
	case OpenGL_OpenGLwidget_NOOP:
		glLogicOp( GL_NOOP );
		break;
	case OpenGL_OpenGLwidget_INVERT:
		glLogicOp( GL_INVERT );
		break;
	case OpenGL_OpenGLwidget_AND:
		glLogicOp( GL_AND );
		break;
	case OpenGL_OpenGLwidget_NAND:
		glLogicOp( GL_NAND );
		break;
	case OpenGL_OpenGLwidget_OR:
		glLogicOp( GL_OR );
		break;
	case OpenGL_OpenGLwidget_NOR:
		glLogicOp( GL_NOR );
		break;
	case OpenGL_OpenGLwidget_XOR:
		glLogicOp( GL_XOR );
		break;
	case OpenGL_OpenGLwidget_EQUIV:
		glLogicOp( GL_EQUIV );
		break;
	case OpenGL_OpenGLwidget_AND_REVERSE:
		glLogicOp( GL_AND_REVERSE );
		break;
	case OpenGL_OpenGLwidget_AND_INVERTED:
		glLogicOp( GL_AND_INVERTED );
		break;
	case OpenGL_OpenGLwidget_OR_REVERSE:
		glLogicOp( GL_OR_REVERSE );
		break;
	case OpenGL_OpenGLwidget_OR_INVERTED:
		glLogicOp( GL_OR_INVERTED );
		break;
	default:
		return;
	}
}

/* TO DO: glMap1, glMap2 */

void OpenGL_OpenGLwidget_mapGrid1d(struct HOpenGL_OpenGLwidget *this,
									long un,
									double u1,
									double u2)
{
	glMapGrid1d( (GLint)un, u1, u2 );
}

void OpenGL_OpenGLwidget_mapGrid1f(struct HOpenGL_OpenGLwidget *this,
									long un,
									float u1,
									float u2)
{
	glMapGrid1f( (GLint)un, u1, u2 );
}
void OpenGL_OpenGLwidget_mapGrid2d(struct HOpenGL_OpenGLwidget *this,
									long un,
									double u1,
									double u2,
									long vn,
									double v1,
									double v2)
{
	glMapGrid2f( (GLint)un, u1, u2, (GLint) vn, v1, v2 );
}

void OpenGL_OpenGLwidget_mapGrid2f(struct HOpenGL_OpenGLwidget *this,
									long un,
									float u1,
									float u2,
									long vn,
									float v1,
									float v2)
{
	glMapGrid2f( (GLint)un, u1, u2, (GLint) vn, v1, v2 );
}

void OpenGL_OpenGLwidget_materialf(struct HOpenGL_OpenGLwidget *this,
									long face,
									long pname,
									float param)
{
	GLenum gl_pname, gl_face;
	switch( pname ) {
	case OpenGL_OpenGLwidget_SHININESS:
		gl_pname = GL_SHININESS;	
		break;
	default:
		return;
	}
	switch( face ) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}
	glMaterialf( gl_face, gl_pname, param );
}

void OpenGL_OpenGLwidget_materiali(struct HOpenGL_OpenGLwidget *this,
									long face,
									long pname,
									long param)
{
	GLenum gl_pname, gl_face;
	switch( pname ) {
	case OpenGL_OpenGLwidget_SHININESS:
		gl_pname = GL_SHININESS;	
		break;
	default:
		return;
	}
	switch( face ) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}
	glMateriali( gl_face, gl_pname, param );
}

void OpenGL_OpenGLwidget_materialiv(struct HOpenGL_OpenGLwidget *this,
									long face,
									long pname,
									long param1,
									long param2,
									long param3,
									long param4 )
{
	GLenum gl_face;
	int    gl_params[4];

	gl_params[0] = (int)param1; gl_params[1] = (int)param2;
	gl_params[2] = (int)param3; gl_params[3] = (int)param4;

	switch( face ) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}

	switch( pname ) {
	case OpenGL_OpenGLwidget_AMBIENT:
		glMaterialiv( gl_face, GL_AMBIENT, gl_params );
		break;
	case OpenGL_OpenGLwidget_DIFFUSE:
		glMaterialiv( gl_face, GL_DIFFUSE, gl_params );
		break;
	case OpenGL_OpenGLwidget_SPECULAR:
		glMaterialiv( gl_face, GL_SPECULAR, gl_params );
		break;
	case OpenGL_OpenGLwidget_EMISSION:
		glMaterialiv( gl_face, GL_EMISSION, gl_params );
		break;
	case OpenGL_OpenGLwidget_SHININESS:
		glMaterialiv( gl_face, GL_SHININESS, gl_params );
		break;
	case OpenGL_OpenGLwidget_AMBIENT_AND_DIFFUSE:
		glMaterialiv( gl_face, GL_AMBIENT_AND_DIFFUSE, gl_params );
		break;
	case OpenGL_OpenGLwidget_COLOR_INDEXES:
		glMaterialiv( gl_face, GL_COLOR_INDEXES, gl_params );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_materialfv(struct HOpenGL_OpenGLwidget *this,
									long face,
									long pname,
									float param1,
									float param2,
									float param3,
									float param4 )
{
	GLenum gl_face;
	float  gl_params[4];

	gl_params[0] = param1; gl_params[1] = param2;
	gl_params[2] = param3; gl_params[3] = param4;

	switch( face ) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}

	switch( pname ) {
	case OpenGL_OpenGLwidget_AMBIENT:
		glMaterialfv( gl_face, GL_AMBIENT, gl_params );
		break;
	case OpenGL_OpenGLwidget_DIFFUSE:
		glMaterialfv( gl_face, GL_DIFFUSE, gl_params );
		break;
	case OpenGL_OpenGLwidget_SPECULAR:
		glMaterialfv( gl_face, GL_SPECULAR, gl_params );
		break;
	case OpenGL_OpenGLwidget_EMISSION:
		glMaterialfv( gl_face, GL_EMISSION, gl_params );
		break;
	case OpenGL_OpenGLwidget_SHININESS:
		glMaterialfv( gl_face, GL_SHININESS, gl_params );
		break;
	case OpenGL_OpenGLwidget_AMBIENT_AND_DIFFUSE:
		glMaterialfv( gl_face, GL_AMBIENT_AND_DIFFUSE, gl_params );
		break;
	case OpenGL_OpenGLwidget_COLOR_INDEXES:
		glMaterialfv( gl_face, GL_COLOR_INDEXES, gl_params );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_matrixMode(struct HOpenGL_OpenGLwidget *this,
									long mode )
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_MODELVIEW:
		glMatrixMode( GL_MODELVIEW );
		break;
	case OpenGL_OpenGLwidget_PROJECTION:
		glMatrixMode( GL_PROJECTION );
		break;
	case OpenGL_OpenGLwidget_TEXTURE:
		glMatrixMode( GL_TEXTURE );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_multMatrixd( struct HOpenGL_OpenGLwidget *this,
									 HArrayOfDouble *M )
{
	double *ptr = unhand(M)->body;
	glMultMatrixd( ptr );
}

void OpenGL_OpenGLwidget_multMatrixf( struct HOpenGL_OpenGLwidget *this,
									 HArrayOfFloat *M )
{
	float *ptr = unhand(M)->body;
	glMultMatrixf( ptr );
}

/* TO DO: glNewList */

void OpenGL_OpenGLwidget_normal3b(struct HOpenGL_OpenGLwidget *this,
									char x,
									char y,
									char z)
{
	glNormal3b( (GLbyte)x, (GLbyte)y, (GLbyte)z );
}

void OpenGL_OpenGLwidget_normal3d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z)
{
	glNormal3d( x, y ,z );
}

void OpenGL_OpenGLwidget_normal3f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z)
{
	glNormal3f( x, y, z );
}

void OpenGL_OpenGLwidget_normal3s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y,
									short z)
{
	glNormal3s( x, y, z );
}
void OpenGL_OpenGLwidget_normal3i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long z)
{
	glNormal3i( (GLint)x, (GLint)y, (GLint)z );
}

void OpenGL_OpenGLwidget_ortho(struct HOpenGL_OpenGLwidget *this,
									double left,
									double right,
									double bottom,
									double top,
									double near,
									double far)
{
	glOrtho( left, right, bottom, top, near, far );
}

void OpenGL_OpenGLwidget_passThrough(struct HOpenGL_OpenGLwidget *this,
									float token)
{
	glPassThrough( token );
}

/* TO DO: glPixelMapfv, glPixelMapiv, glPixelMapsv, glPixelStore,
		  glPixelTransfer, glPixelZoom */

void OpenGL_OpenGLwidget_pointSize(struct HOpenGL_OpenGLwidget *this,
									float size )
{
	glPointSize( size );
}

void OpenGL_OpenGLwidget_polygonMode(struct HOpenGL_OpenGLwidget *this,
									long face,
									long mode)
{
	GLenum gl_face, gl_mode;
	
	switch( face) {
	case OpenGL_OpenGLwidget_FRONT:
		gl_face = GL_FRONT;
		break;
	case OpenGL_OpenGLwidget_BACK:
		gl_face = GL_BACK;
		break;
	case OpenGL_OpenGLwidget_FRONT_AND_BACK:
		gl_face = GL_FRONT_AND_BACK;
		break;
	default:
		return;
	}
	switch( mode ) {
	case OpenGL_OpenGLwidget_POINT:
		gl_mode = GL_POINT;
		break;
	case OpenGL_OpenGLwidget_LINE:
		gl_mode = GL_LINE;
		break;
	case OpenGL_OpenGLwidget_FILL:
		gl_mode = GL_FILL;
		break;
	default:
		return;
	}
	glPolygonMode( gl_face, gl_mode );
}

/* TO DO: glPolygonStipple */

void OpenGL_OpenGLwidget_pushAttrib(struct HOpenGL_OpenGLwidget *this,
									long mask )
{
	switch( mask ) {
	case OpenGL_OpenGLwidget_ACCUM_BUFFER_BIT:
		glPushAttrib( GL_ACCUM_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_COLOR_BUFFER_BIT:
		glPushAttrib( GL_COLOR_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_CURRENT_BIT:
		glPushAttrib( GL_CURRENT_BIT );
		break;
	case OpenGL_OpenGLwidget_DEPTH_BUFFER_BIT:
		glPushAttrib( GL_DEPTH_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_ENABLE_BIT:
		glPushAttrib( GL_ENABLE_BIT );
		break;
	case OpenGL_OpenGLwidget_EVAL_BIT:
		glPushAttrib( GL_EVAL_BIT );
		break;
	case OpenGL_OpenGLwidget_FOG_BIT:
		glPushAttrib( GL_FOG_BIT );
		break;
	case OpenGL_OpenGLwidget_HINT_BIT:
		glPushAttrib( GL_HINT_BIT );
		break;
	case OpenGL_OpenGLwidget_LIGHTING_BIT:
		glPushAttrib( GL_LIGHTING_BIT );
		break;
	case OpenGL_OpenGLwidget_LINE_BIT:
		glPushAttrib( GL_LINE_BIT );
		break;
	case OpenGL_OpenGLwidget_LIST_BIT:
		glPushAttrib( GL_LIST_BIT );
		break;
	case OpenGL_OpenGLwidget_PIXEL_MODE_BIT:
		glPushAttrib( GL_PIXEL_MODE_BIT );
		break;
	case OpenGL_OpenGLwidget_POINT_BIT:
		glPushAttrib( GL_POINT_BIT );
		break;
	case OpenGL_OpenGLwidget_POLYGON_BIT:
		glPushAttrib( GL_POLYGON_BIT );
		break;
	case OpenGL_OpenGLwidget_POLYGON_STIPPLE_BIT:
		glPushAttrib( GL_POLYGON_STIPPLE_BIT );
		break;
	case OpenGL_OpenGLwidget_SCISSOR_BIT:
		glPushAttrib( GL_SCISSOR_BIT );
		break;
	case OpenGL_OpenGLwidget_STENCIL_BUFFER_BIT:
		glPushAttrib( GL_STENCIL_BUFFER_BIT );
		break;
	case OpenGL_OpenGLwidget_TEXTURE_BIT:
		glPushAttrib( GL_TEXTURE_BIT );
		break;
	case OpenGL_OpenGLwidget_TRANSFORM_BIT:
		glPushAttrib( GL_TRANSFORM_BIT );
		break;
	case OpenGL_OpenGLwidget_VIEWPORT_BIT:
		glPushAttrib( GL_VIEWPORT_BIT );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_popAttrib(struct HOpenGL_OpenGLwidget *this )
{
	glPopAttrib();
}

void OpenGL_OpenGLwidget_pushMatrix(struct HOpenGL_OpenGLwidget *this)
{
	glPushMatrix();
}

void OpenGL_OpenGLwidget_popMatrix(struct HOpenGL_OpenGLwidget *this)
{
	glPopMatrix();
}

void OpenGL_OpenGLwidget_pushName(struct HOpenGL_OpenGLwidget *this,
									long name)
{
	glPushName( (GLuint) name );
}

void OpenGL_OpenGLwidget_popName(struct HOpenGL_OpenGLwidget *this )
{
	glPopName();
}

void OpenGL_OpenGLwidget_rasterPos2d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y)
{
	glRasterPos2d( x, y );
}

void OpenGL_OpenGLwidget_rasterPos2f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y)
{
	glRasterPos2f( x, y );
}

void OpenGL_OpenGLwidget_rasterPos2i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y)
{
	glRasterPos2i( (GLint)x, (GLint)y );
}

void OpenGL_OpenGLwidget_rasterPos2s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y)
{
	glRasterPos2s( x, y );
}

void OpenGL_OpenGLwidget_rasterPos3d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z)
{
	glRasterPos3d( x, y, z );
}

void OpenGL_OpenGLwidget_rasterPos3f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z)
{
	glRasterPos3f( x, y, z );
}

void OpenGL_OpenGLwidget_rasterPos3i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long z)
{
	glRasterPos3i( (GLint)x, (GLint)y, (GLint)z );
}

void OpenGL_OpenGLwidget_rasterPos3s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y,
									short z)
{
	glRasterPos3s( x, y, z );
}

void OpenGL_OpenGLwidget_readBuffer(struct HOpenGL_OpenGLwidget *this,
									long mode)
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_FRONT_LEFT:
		glReadBuffer( GL_FRONT_LEFT );
		break;
	case OpenGL_OpenGLwidget_FRONT_RIGHT:
		glReadBuffer( GL_FRONT_RIGHT );
		break;
	case OpenGL_OpenGLwidget_BACK_LEFT:
		glReadBuffer( GL_BACK_LEFT );
		break;
	case OpenGL_OpenGLwidget_BACK_RIGHT:
		glReadBuffer( GL_BACK_RIGHT );
		break;
	case OpenGL_OpenGLwidget_FRONT:
		glReadBuffer( GL_FRONT );
		break;
	case OpenGL_OpenGLwidget_BACK:
		glReadBuffer( GL_BACK );
		break;
	case OpenGL_OpenGLwidget_LEFT:
		glReadBuffer( GL_LEFT );
		break;
	case OpenGL_OpenGLwidget_RIGHT:
		glReadBuffer( GL_RIGHT );
		break;
	case OpenGL_OpenGLwidget_AUX0:
		glReadBuffer( GL_AUX0 );
		break;
	case OpenGL_OpenGLwidget_AUX1:
		glReadBuffer( GL_AUX1 );
		break;
	case OpenGL_OpenGLwidget_AUX2:
		glReadBuffer( GL_AUX2 );
		break;
	case OpenGL_OpenGLwidget_AUX3:
		glReadBuffer( GL_AUX3 );
		break;
	default:
		return;
	}
}

/* TO DO: glReadPixels */

void OpenGL_OpenGLwidget_rectd(struct HOpenGL_OpenGLwidget *this,
									double x1,
									double y1,
									double x2,
									double y2)
{
	glRectd( x1, y1, x2, y2 );
}

void OpenGL_OpenGLwidget_rectf(struct HOpenGL_OpenGLwidget *this,
									float x1,
									float y1,
									float x2,
									float y2)
{
	glRectf( x1, y1, x2, y2 );
}

void OpenGL_OpenGLwidget_recti(struct HOpenGL_OpenGLwidget *this,
									long x1,
									long y1,
									long x2,
									long y2)
{
	glRecti( (GLint)x1, (GLint)y1, (GLint)x2, (GLint)y2 );
}

void OpenGL_OpenGLwidget_renderMode(struct HOpenGL_OpenGLwidget *this,
									long mode)
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_RENDER:
		glRenderMode( GL_RENDER );
		break;
	case OpenGL_OpenGLwidget_SELECT:
		glRenderMode( GL_SELECT );
		break;
	case OpenGL_OpenGLwidget_FEEDBACK:
		glRenderMode( GL_FEEDBACK );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_rotated(struct HOpenGL_OpenGLwidget *this,
									double angle,
									double x,
									double y,
									double z)
{
	glRotated( angle, x, y, z );	
}

void OpenGL_OpenGLwidget_rotatef(struct HOpenGL_OpenGLwidget *this,
									float angle,
									float x,
									float y,
									float z)
{
	glRotatef( angle, x, y, z );	
}

void OpenGL_OpenGLwidget_scaled(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z)
{
	glScaled( x, y, z );
}
void OpenGL_OpenGLwidget_scalef(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z)
{
	glScalef( x, y, z );
}

void OpenGL_OpenGLwidget_scissor(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long width,
									long height)
{
	glScissor( (GLint)x, (GLint)y, (GLsizei)width, (GLsizei)height );
}

/* TO DO: glSelectBuffer */

void OpenGL_OpenGLwidget_shadeModel(struct HOpenGL_OpenGLwidget *this,
									long mode )
{
	switch( mode ) {
	case OpenGL_OpenGLwidget_FLAT:
		glShadeModel( GL_FLAT );
		break;
	case OpenGL_OpenGLwidget_SMOOTH:
		glShadeModel( GL_SMOOTH );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_stencilFunc(struct HOpenGL_OpenGLwidget *this,
									long func,
									long ref,
									long mask)
{
	switch( func ) {
	case OpenGL_OpenGLwidget_NEVER:
		glStencilFunc( GL_NEVER, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_LESS:
		glStencilFunc( GL_LESS, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_LEQUAL:
		glStencilFunc( GL_LEQUAL, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_GREATER:
		glStencilFunc( GL_GREATER, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_GEQUAL:
		glStencilFunc( GL_GEQUAL, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_EQUAL:
		glStencilFunc( GL_EQUAL, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_NOTEQUAL:
		glStencilFunc( GL_NOTEQUAL, (GLint)ref, (GLuint)mask );
		break;
	case OpenGL_OpenGLwidget_ALWAYS:
		glStencilFunc( GL_ALWAYS, (GLint)ref, (GLuint)mask );
		break;
	default:
		return;
	}
}

void OpenGL_OpenGLwidget_stencilMask(struct HOpenGL_OpenGLwidget *this,
									long mask)
{
	glStencilMask( (GLuint)mask );
}
void OpenGL_OpenGLwidget_stencilOp(struct HOpenGL_OpenGLwidget *this,
									long fail,
									long zfail,
									long zpass)
{
	GLenum gl_fail, gl_zfail, gl_zpass;

	switch( fail ) {
	case OpenGL_OpenGLwidget_KEEP:
		gl_fail = GL_KEEP;
		break;
	case OpenGL_OpenGLwidget_ZERO:
		gl_fail = GL_ZERO;
		break;
	case OpenGL_OpenGLwidget_REPLACE:
		gl_fail = GL_REPLACE;
		break;
	case OpenGL_OpenGLwidget_INCR:
		gl_fail = GL_INCR;
		break;
	case OpenGL_OpenGLwidget_DECR:
		gl_fail = GL_DECR;
		break;
	case OpenGL_OpenGLwidget_INVERT:
		gl_fail = GL_INVERT;
		break;
	default:
		return;
	}

	switch( zfail ) {
	case OpenGL_OpenGLwidget_KEEP:
		gl_zfail = GL_KEEP;
		break;
	case OpenGL_OpenGLwidget_ZERO:
		gl_zfail = GL_ZERO;
		break;
	case OpenGL_OpenGLwidget_REPLACE:
		gl_zfail = GL_REPLACE;
		break;
	case OpenGL_OpenGLwidget_INCR:
		gl_zfail = GL_INCR;
		break;
	case OpenGL_OpenGLwidget_DECR:
		gl_zfail = GL_DECR;
		break;
	case OpenGL_OpenGLwidget_INVERT:
		gl_zfail = GL_INVERT;
		break;
	default:
		return;
	}

	switch( zpass ) {
	case OpenGL_OpenGLwidget_KEEP:
		gl_zpass = GL_KEEP;
		break;
	case OpenGL_OpenGLwidget_ZERO:
		gl_zpass = GL_ZERO;
		break;
	case OpenGL_OpenGLwidget_REPLACE:
		gl_zpass = GL_REPLACE;
		break;
	case OpenGL_OpenGLwidget_INCR:
		gl_zpass = GL_INCR;
		break;
	case OpenGL_OpenGLwidget_DECR:
		gl_zpass = GL_DECR;
		break;
	case OpenGL_OpenGLwidget_INVERT:
		gl_zpass = GL_INVERT;
		break;
	default:
		return;
	}

	glStencilOp( gl_fail, gl_zfail, gl_zpass );
}

void OpenGL_OpenGLwidget_texCoord1d(struct HOpenGL_OpenGLwidget *this,
									double s)
{
	glTexCoord1d( s );
}

void OpenGL_OpenGLwidget_texCoord1f(struct HOpenGL_OpenGLwidget *this,
									float s)
{
	glTexCoord1f( s );
}

void OpenGL_OpenGLwidget_texCoord1i(struct HOpenGL_OpenGLwidget *this,
									long s)
{
	glTexCoord1i( (GLint)s );
}

void OpenGL_OpenGLwidget_texCoord1s(struct HOpenGL_OpenGLwidget *this,
									short s)
{
	glTexCoord1s( s );
}

void OpenGL_OpenGLwidget_texCoord2d(struct HOpenGL_OpenGLwidget *this,
									double s,
									double t)
{
	glTexCoord2d( s,t );
}

void OpenGL_OpenGLwidget_texCoord2f(struct HOpenGL_OpenGLwidget *this,
									float s,
									float t)
{
	glTexCoord2f( s,t );
}

void OpenGL_OpenGLwidget_texCoord2i(struct HOpenGL_OpenGLwidget *this,
									long s,
									long t)
{
	glTexCoord2i( s,t );
}

void OpenGL_OpenGLwidget_texCoord2s(struct HOpenGL_OpenGLwidget *this,
									short s,
									short t)
{
	glTexCoord2s( s,t );
}

void OpenGL_OpenGLwidget_texCoord3d(struct HOpenGL_OpenGLwidget *this,
									double s,
									double t,
									double r)
{
	glTexCoord3d( s,t,r );
}

void OpenGL_OpenGLwidget_texCoord3f(struct HOpenGL_OpenGLwidget *this,
									float s,
									float t,
									float r)
{
	glTexCoord3f( s,t,r );
}

void OpenGL_OpenGLwidget_texCoord3i(struct HOpenGL_OpenGLwidget *this,
									long s,
									long t,
									long r)
{
	glTexCoord3i( (GLint)s,(GLint)t,(GLint)r );
}

void OpenGL_OpenGLwidget_texCoord3s(struct HOpenGL_OpenGLwidget *this,
									short s,
									short t,
									short r)
{
	glTexCoord3s( s,t,r );
}

void OpenGL_OpenGLwidget_texCoord4d(struct HOpenGL_OpenGLwidget *this,
									double s,
									double t,
									double r,
									double q)
{
	glTexCoord4d( s,t,r,q );
}

void OpenGL_OpenGLwidget_texCoord4f(struct HOpenGL_OpenGLwidget *this,
									float s,
									float t,
									float r,
									float q)
{
	glTexCoord4f( s,t,r,q );
}

void OpenGL_OpenGLwidget_texCoord4i(struct HOpenGL_OpenGLwidget *this,
									long s,
									long t,
									long r,
									long q)
{
	glTexCoord4i( (GLint)s, (GLint)t, (GLint)r, (GLint)q );
}

void OpenGL_OpenGLwidget_texCoord4s(struct HOpenGL_OpenGLwidget *this,
									short s,
									short t,
									short r,
									short q)
{
	glTexCoord4s( s,t,r,q );
}

void OpenGL_OpenGLwidget_texEnvf(struct HOpenGL_OpenGLwidget *this,
									long target,
									long pname,
									float param)
{
	GLenum gl_target, gl_pname;
	GLfloat gl_param;

	switch( target ) {
	case OpenGL_OpenGLwidget_TEXTURE_ENV:
		gl_target = GL_TEXTURE_ENV;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		gl_pname = GL_TEXTURE_ENV_MODE;
		break;
	default:
		return;
	}
	if( param == (float)OpenGL_OpenGLwidget_MODULATE) 
		gl_param = GL_MODULATE;
	else if( param == (float)OpenGL_OpenGLwidget_DECAL )
		gl_param = GL_DECAL;
	else if( param == (float)OpenGL_OpenGLwidget_BLEND )
		gl_param = GL_BLEND;
	else
		return;

	glTexEnvf( gl_target, gl_pname, gl_param );
	
}

void OpenGL_OpenGLwidget_texEnvi(struct HOpenGL_OpenGLwidget *this,
									long target,
									long pname,
									long param)
{
	GLenum gl_target, gl_pname;
	GLfloat gl_param;

	switch( target ) {
	case OpenGL_OpenGLwidget_TEXTURE_ENV:
		gl_target = GL_TEXTURE_ENV;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_TEXTURE_ENV_MODE:
		gl_pname = GL_TEXTURE_ENV_MODE;
		break;
	default:
		return;
	}
	switch( param ) {
	case OpenGL_OpenGLwidget_MODULATE:
		gl_param = GL_MODULATE;
		break;
	case OpenGL_OpenGLwidget_DECAL:
		gl_param = GL_DECAL;
		break;
	case OpenGL_OpenGLwidget_BLEND:
		gl_param = GL_BLEND;
		break;
	default:
		return;
	}
	glTexEnvi( gl_target, gl_pname, gl_param );
}

void OpenGL_OpenGLwidget_texGend(struct HOpenGL_OpenGLwidget *this,
									long coord,
									long pname,
									double param)
{
	GLenum gl_coord, gl_pname;
	GLdouble gl_param;

	switch( coord ) {
	case OpenGL_OpenGLwidget_S:
		gl_coord = GL_S;
		break;
	case OpenGL_OpenGLwidget_T:
		gl_coord = GL_T;
		break;
	case OpenGL_OpenGLwidget_R:
		gl_coord = GL_R;
		break;
	case OpenGL_OpenGLwidget_Q:
		gl_coord = GL_Q;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_TEXTURE_GEN_MODE:
		gl_pname = GL_TEXTURE_GEN_MODE;
		break;
	default:
		return;
	}
	if( param == (double)OpenGL_OpenGLwidget_OBJECT_LINEAR)
		gl_param = GL_OBJECT_LINEAR;
	else if( param == (double)OpenGL_OpenGLwidget_EYE_LINEAR )
		gl_param = GL_EYE_LINEAR;
	else if( param == (double)OpenGL_OpenGLwidget_SPHERE_MAP )
		gl_param = GL_SPHERE_MAP;
	else
		return;

	glTexGend( gl_coord, gl_pname, gl_param );
}

void OpenGL_OpenGLwidget_texGenf(struct HOpenGL_OpenGLwidget *this,
									long coord,
									long pname,
									float param)
{
	GLenum gl_coord, gl_pname;
	GLfloat gl_param;

	switch( coord ) {
	case OpenGL_OpenGLwidget_S:
		gl_coord = GL_S;
		break;
	case OpenGL_OpenGLwidget_T:
		gl_coord = GL_T;
		break;
	case OpenGL_OpenGLwidget_R:
		gl_coord = GL_R;
		break;
	case OpenGL_OpenGLwidget_Q:
		gl_coord = GL_Q;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_TEXTURE_GEN_MODE:
		gl_pname = GL_TEXTURE_GEN_MODE;
		break;
	default:
		return;
	}

	if( param == (float)OpenGL_OpenGLwidget_OBJECT_LINEAR)
		gl_param = GL_OBJECT_LINEAR;
	else if( param == (float)OpenGL_OpenGLwidget_EYE_LINEAR )
		gl_param = GL_EYE_LINEAR;
	else if( param == (float)OpenGL_OpenGLwidget_SPHERE_MAP )
		gl_param = GL_SPHERE_MAP;
	else
		return;

	glTexGenf( gl_coord, gl_pname, gl_param );
}

void OpenGL_OpenGLwidget_texGeni(struct HOpenGL_OpenGLwidget *this,
									long coord,
									long pname,
									long param)
{
	GLenum gl_coord, gl_pname;
	GLint gl_param;

	switch( coord ) {
	case OpenGL_OpenGLwidget_S:
		gl_coord = GL_S;
		break;
	case OpenGL_OpenGLwidget_T:
		gl_coord = GL_T;
		break;
	case OpenGL_OpenGLwidget_R:
		gl_coord = GL_R;
		break;
	case OpenGL_OpenGLwidget_Q:
		gl_coord = GL_Q;
		break;
	default:
		return;
	}
	switch( pname ) {
	case OpenGL_OpenGLwidget_TEXTURE_GEN_MODE:
		gl_pname = GL_TEXTURE_GEN_MODE;
		break;
	default:
		return;
	}
	switch( param ) {
	case ((long)OpenGL_OpenGLwidget_OBJECT_LINEAR):
		gl_param = GL_OBJECT_LINEAR;
		break;
	case ((long)OpenGL_OpenGLwidget_EYE_LINEAR):
		gl_param = GL_EYE_LINEAR;
		break;
	case ((long)OpenGL_OpenGLwidget_SPHERE_MAP):
		gl_param = GL_SPHERE_MAP;
		break;
	default:
		return;
	}
	glTexGeni( gl_coord, gl_pname, gl_param );
}

/* TO DO: glTexImage1D, glTexImage2D glTexParameter */

void OpenGL_OpenGLwidget_translated(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z)
{
	glTranslated( x, y, z );
}

void OpenGL_OpenGLwidget_translatef(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z)
{
	glTranslatef( x, y, z );
}

void OpenGL_OpenGLwidget_vertex2d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y)
{
	glVertex2d( x, y );
}

void OpenGL_OpenGLwidget_vertex2f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y)
{
	glVertex2f( x,y );
}

void OpenGL_OpenGLwidget_vertex2i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y)
{
	glVertex2i( (GLint)x, (GLint)y );
}

void OpenGL_OpenGLwidget_vertex2s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y)
{
	glVertex2s( x,y );
}

void OpenGL_OpenGLwidget_vertex3d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z)
{
	glVertex3d( x,y,z );
}

void OpenGL_OpenGLwidget_vertex3f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z)
{
	glVertex3f( x,y,z );
}

void OpenGL_OpenGLwidget_vertex3i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long z)
{
	glVertex3i( (GLint) x, (GLint)y, (GLint)z );
}

void OpenGL_OpenGLwidget_vertex3s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y,
									short z)
{
	glVertex3s( x,y,z );
}

void OpenGL_OpenGLwidget_vertex4d(struct HOpenGL_OpenGLwidget *this,
									double x,
									double y,
									double z,
									double w)
{
	glVertex4d( x,y,z,w );
}

void OpenGL_OpenGLwidget_vertex4f(struct HOpenGL_OpenGLwidget *this,
									float x,
									float y,
									float z,
									float w)
{
	glVertex4f( x,y,z,w );
}

void OpenGL_OpenGLwidget_vertex4i(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long z,
									long w)
{
	glVertex4i( (GLint)x, (GLint)y, (GLint)z, (GLint)w );
}

void OpenGL_OpenGLwidget_vertex4s(struct HOpenGL_OpenGLwidget *this,
									short x,
									short y,
									short z,
									short w)
{
	glVertex4s( x,y,z,w );
}
void OpenGL_OpenGLwidget_viewport(struct HOpenGL_OpenGLwidget *this,
									long x,
									long y,
									long width,
									long height)
{
	glViewport( (GLint)x, (GLint)y, (GLsizei)width, (GLsizei)height ); 
}
