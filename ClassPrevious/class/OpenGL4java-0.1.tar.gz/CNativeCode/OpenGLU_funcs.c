/*
 * Leo Chan -- 1995
 *
 * This C file takes care of all the native implementation for the
 * OpenGL utility commands
 */

/* 
 * need to include the JAVA internal header files for macros and function
 * prototypes required to maipulated JAVA data structures and functions
 *
 * StubPreamble.h includes the structure and macro definitions neede to
 * convert JAVA data structures into C data structures.
 *
 */

#include "StubPreamble.h"

/*
 * the next thing to include are special headers that were created by
 * JAVAH.  They include the C structure definitions for the JAVA classes
 */
#include "OpenGL_OpenGLwidget.h"

/*--------------------------------------------------------------------------
 * here on in is just regular apple pie C
 */

/*
 * next put any C UNIX specific header files that are necessary to implement
 * this native code
 */			

#include <GL/glu.h>

/**
 * herein lies the native JAVA methods for the OpenGL functions.  
 */

void OpenGL_OpenGLwidget_perspective(struct HOpenGL_OpenGLwidget *this,
									double fov,
									double aspect,
									double near,
									double far)
{
	gluPerspective( fov, aspect, near, far );
}
