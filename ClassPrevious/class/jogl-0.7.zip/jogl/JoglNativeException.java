/* Copyright 1997 Free Software Foundation, Inc.
 */

package jogl;

public class JoglNativeException extends RuntimeException
{
  public JoglNativeException(String details)
    {
      super(details);
    }
}
