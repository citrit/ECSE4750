#undef NEED_OWN_WINDOW
#undef HAVE_SGI_EXTENSIONS
#undef VERSION
#undef JNI_CFLAGS
#undef OGL_CFLAGS
#undef OGL_LIBS
#undef PACKAGE
