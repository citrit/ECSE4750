//////////////////////////////////////////////////////////////////////////
//
//  This code is for instructional purposes only. It was generated for
//  use in a graduate level course to show certain aspects of data
//  storage algorithms. It has problems and should not be used
//  outside the class environment.
//
//  Author:  Thomas D. Citriniti     citrit@rpi.edu
//  Class:   Advanced Computer Graphics and Data visualization
//           Rensselaer Polytechnic Institute
//  Date:    March 2001
//
//////////////////////////////////////////////////////////////////////////

import java.awt.*;
import java.awt.event.*;

class myKey implements KeyCallback
{
	Renderer aRen;
	
	public myKey(Renderer aren)
	{
		aRen = aren;
	}
	
	/** Callback so client can handle keystrokes.  */
	public void keyCallback(KeyEvent e)
	{
		switch(e.getKeyChar())
		{
			case '1':
				aRen.startScene();
				break;
			case '2':
				aRen.stopScene();
				break;
		}
	}
}

class JumpAction extends Action
{
	/** Method to handle whenever the SceneClock ticks.
	 * This will be over-ridden by the derived class for a specific 
	 * action.
	 */
	public void tick(int tickTime)
	{
		int ii;
		for (ii=0;ii<Actors.size();ii++) {
			((Actor)Actors.elementAt(ii)).rotateX(5);
			System.out.print("Tick: " + tickTime + "\r");
		}
	}
}

public class AnimateScene extends Frame
{
	public static void main(String argv[])
	{

		//STLReader stlr = new STLReader("small.stl");
		CubeCell cube = new CubeCell();
		MaterialSet mats = new MaterialSet();
		mats.addMaterial(new Material(1.0F,1.0F,0.0F,1.0F));
		cube.setMaterials(mats);
		Actor cubeActor = new Actor();
		cubeActor.addCell(cube);
		GL4JRenderer aren = new GL4JRenderer();
		aren.addActor(cubeActor);
		aren.addCamera(new GL4JCamera());
		aren.addLight(new GL4JLight(0));
		aren.addKeyCallback(new myKey(aren));
		JumpAction ja = new JumpAction();
		ja.addActor(cubeActor);
		aren.addAction(ja);

		AnimateScene scene = new AnimateScene();
		// Make it visible and set size
		aren.setVisible(true);
		aren.setSize(300, 300);
		aren.getCamera().setFrom(0.0F, 0.0F, 5.0F);
		System.out.println("Here we go");

		// Add the canvas to the frame and make it show
  		scene.add("Center", aren);
		scene.pack();
		scene.show();
	}
	
}
