/* juggle/CanvasTest.java - Test canvas for JGL package
 *
 * $Id$
 *
 * Written by Mark Matthews, 1996.
 *
 */



import java.util.*;
import java.awt.*;
import java.applet.*;

public class WireTest extends Applet 
{  
  public void init()
  {
    try 
      {
	MyCanvas3 TestCanvas = new MyCanvas3();
	this.add( TestCanvas );
      }
    catch ( JGLexception e )
      {
	// do nothing 
      }
  }

}

class MyCanvas3 extends JGLcanvas 
{

  private double azimuth = 45, inclination = 70, dist=0;
  private int dx, dy, x1, x2, y1, y2;
  private double panx = 0, pany = 0;

  public MyCanvas3() throws JGLexception 
  {
  }
  
  public void Reset()
  {
    azimuth = 0;
    inclination =0;
    repaint();
  }

  public boolean handleEvent( Event event )
  {
   
    switch( event.id )
      {
      case Event.MOUSE_DOWN:
	x1 = event.x;
	y1 = event.y;
	break;
      case Event.MOUSE_DRAG:
	x2 = event.x;
	y2 = event.y;
	dx = x2 -x1;
	dy = y2 - y1;
	if ( dx != 0 || dy != 0 )
	  {
	    if ( (event.modifiers & Event.META_MASK) != 0 )
	      {
		panx += dx / 50.0;
		pany -= dy / 50.0;
	      }
	    else if ( (event.modifiers & Event.ALT_MASK) != 0 )
	      {
		dist += dy / 4;
	      }
	    else
	      {
		azimuth += 1 * dx;
		inclination += 1 * dy;
	      }
	  }
	x1 = x2;
	y1 = y2;
	repaint();
	break;
      }
    return false;
  }

  public void update( Graphics g ) 
  {
    
    try
      {
	SetGraphics( g );
	MatrixMode(jgl.GL_MODELVIEW);
	LoadIdentity();
	Translate( panx, pany, -6.0 + dist );
	Rotate( azimuth, 0, 1, 0 );
	Rotate( -inclination, 1, 0 ,0 );
	MatrixMode( jgl.GL_PROJECTION );
	LoadIdentity();
	Ortho( -6.0, 6.0, -6.0, 6.0, .1, 20.0 );
	MatrixMode( jgl.GL_MODELVIEW );
	DrawBuffer( jgl.GL_BACK );
	Clear();
	qtc1();
	SwapBuffers();
      }
    catch ( JGLexception e )
      {
	// Do nothing
      }
  }

  // Breps from TWIN

  public void qtc1() throws JGLexception
  {
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, 0.000000 );
    Vertex3( 4.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 0.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 0.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.107365, 2.471178, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, 0.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, -1.000000 );
    Vertex3( 3.107365, 2.471178, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, -1.000000 );
    Vertex3( 3.107365, 2.471178, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, 0.000000 );
    Vertex3( 2.825975, 2.385819, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, -1.000000 );
    Vertex3( 2.825975, 2.385819, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, -1.000000 );
    Vertex3( 2.825975, 2.385819, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, 0.000000 );
    Vertex3( 2.566645, 2.247204, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, -1.000000 );
    Vertex3( 2.566645, 2.247204, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, -1.000000 );
    Vertex3( 2.566645, 2.247204, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, 0.000000 );
    Vertex3( 2.339340, 2.060660, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, -1.000000 );
    Vertex3( 2.339340, 2.060660, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, -1.000000 );
    Vertex3( 2.339340, 2.060660, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, 0.000000 );
    Vertex3( 2.152796, 1.833355, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, -1.000000 );
    Vertex3( 2.152796, 1.833355, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, -1.000000 );
    Vertex3( 2.152796, 1.833355, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, 0.000000 );
    Vertex3( 2.014181, 1.574025, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, -1.000000 );
    Vertex3( 2.014181, 1.574025, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, -1.000000 );
    Vertex3( 2.014181, 1.574025, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, 0.000000 );
    Vertex3( 1.928822, 1.292636, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, -1.000000 );
    Vertex3( 1.928822, 1.292636, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, -1.000000 );
    Vertex3( 1.928822, 1.292636, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, 0.000000 );
    Vertex3( 1.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, -1.000000 );
    Vertex3( 1.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 1.900000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, 0.000000 );
    Vertex3( 1.966987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 1.966987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 2.150000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, 0.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.150000, 0.566987, -1.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.150000, 0.566987, -1.000000 );
    Vertex3( 2.400000, 0.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, 0.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, -1.000000 );
    Vertex3( 2.400000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, -1.000000 );
    Vertex3( 2.650000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, 0.000000 );
    Vertex3( 2.400000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, -1.000000 );
    Vertex3( 2.650000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, -1.000000 );
    Vertex3( 2.833013, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, 0.000000 );
    Vertex3( 2.650000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, -1.000000 );
    Vertex3( 2.833013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, -1.000000 );
    Vertex3( 2.900000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, 0.000000 );
    Vertex3( 2.833013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, -1.000000 );
    Vertex3( 2.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, -1.000000 );
    Vertex3( 2.909607, 1.097545, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, 0.000000 );
    Vertex3( 2.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, -1.000000 );
    Vertex3( 2.909607, 1.097545, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, -1.000000 );
    Vertex3( 2.938060, 1.191342, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, 0.000000 );
    Vertex3( 2.909607, 1.097545, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, -1.000000 );
    Vertex3( 2.938060, 1.191342, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, -1.000000 );
    Vertex3( 2.984265, 1.277785, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, 0.000000 );
    Vertex3( 2.938060, 1.191342, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, -1.000000 );
    Vertex3( 2.984265, 1.277785, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, -1.000000 );
    Vertex3( 3.046447, 1.353553, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, 0.000000 );
    Vertex3( 2.984265, 1.277785, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, -1.000000 );
    Vertex3( 3.046447, 1.353553, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, -1.000000 );
    Vertex3( 3.122215, 1.415735, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, 0.000000 );
    Vertex3( 3.046447, 1.353553, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, -1.000000 );
    Vertex3( 3.122215, 1.415735, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, -1.000000 );
    Vertex3( 3.208658, 1.461940, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, 0.000000 );
    Vertex3( 3.122215, 1.415735, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, -1.000000 );
    Vertex3( 3.208658, 1.461940, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, -1.000000 );
    Vertex3( 3.302455, 1.490393, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, 0.000000 );
    Vertex3( 3.208658, 1.461940, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, -1.000000 );
    Vertex3( 3.302455, 1.490393, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, -1.000000 );
    Vertex3( 3.400000, 1.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, 0.000000 );
    Vertex3( 3.302455, 1.490393, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, -1.000000 );
    Vertex3( 3.400000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, -1.000000 );
    Vertex3( 3.650000, 1.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, 0.000000 );
    Vertex3( 3.400000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, -1.000000 );
    Vertex3( 3.650000, 1.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, -1.000000 );
    Vertex3( 3.833013, 1.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, 0.000000 );
    Vertex3( 3.650000, 1.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, -1.000000 );
    Vertex3( 3.833013, 1.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, -1.000000 );
    Vertex3( 3.900000, 2.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, 0.000000 );
    Vertex3( 3.833013, 1.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, -1.000000 );
    Vertex3( 3.900000, 2.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, -1.000000 );
    Vertex3( 3.833013, 2.250000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, 0.000000 );
    Vertex3( 3.833013, 2.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, -1.000000 );
    Vertex3( 3.833013, 2.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, -1.000000 );
    Vertex3( 3.650000, 2.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, 0.000000 );
    Vertex3( 3.650000, 2.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 2.433013, -1.000000 );
    Vertex3( 3.650000, 2.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.650000, 2.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 2.433013, 0.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, -1.000000 );
    Vertex3( 0.566987, 1.250000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, -1.000000 );
    Vertex3( 0.750000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, 0.000000 );
    Vertex3( 0.750000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, -1.000000 );
    Vertex3( 0.566987, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, -1.000000 );
    Vertex3( 0.750000, 1.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, -1.000000 );
    Vertex3( 1.000000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, 0.000000 );
    Vertex3( 1.000000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 1.433013, -1.000000 );
    Vertex3( 1.000000, 1.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 1.433013, -1.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, 0.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.250000, 1.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.433013, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, 0.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, -1.000000 );
    Vertex3( 1.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, 0.000000 );
    Vertex3( 1.433013, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, -1.000000 );
    Vertex3( 1.433013, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, -1.000000 );
    Vertex3( 1.433013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, 0.000000 );
    Vertex3( 1.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, -1.000000 );
    Vertex3( 1.250000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, -1.000000 );
    Vertex3( 1.250000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, 0.000000 );
    Vertex3( 1.433013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, -1.000000 );
    Vertex3( 1.000000, 0.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, -1.000000 );
    Vertex3( 1.000000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, 0.000000 );
    Vertex3( 1.250000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, -1.000000 );
    Vertex3( 0.750000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, -1.000000 );
    Vertex3( 0.750000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, 0.000000 );
    Vertex3( 0.750000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, -1.000000 );
    Vertex3( 0.566987, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 0.750000, -1.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, 0.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 0.750000, -1.000000 );
    Vertex3( 0.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, -1.000000 );
    Vertex3( 0.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, 0.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, -1.000000 );
    Vertex3( 0.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, 0.000000 );
    Vertex3( 0.566987, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 3.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, -1.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, -1.000000 );
    Vertex3( 0.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, 0.000000 );
    Vertex3( 0.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 0.000000, 3.000000, -1.000000 );
    End();
  }
}
    
