/* juggle/CanvasTest.java - Test canvas for JGL package
 *
 * $Id$
 *
 * Written by Mark Matthews, 1996.
 *
 */



import java.util.*;
import java.awt.*;
import cadlab.jgl.*;


public class CanvasTest {

  private final String rcsid = "$Id$";
  

  public static void main(String[] args) throws JGLexception
  {
    Frame f = new Frame("JGL Canvas Test");
    f.resize( 400, 400 );
    MyCanvas TestCanvas = new MyCanvas();
    f.add( "Center", TestCanvas );
    f.show();
  }

}

class MyCanvas extends JGLcanvas {

  private double azimuth = 0, inclination = 0, dist=0;
  private int dx, dy, x1, x2, y1, y2;
  private double panx = 0, pany = 0;
  private boolean picking = false;

  private Vector4 no_mat = new Vector4( 0.0, 0.0, 0.0, 1.0 );
  private Vector4 mat_diffuse = new Vector4( 0.6, 0.6, 0.6, 1.0 );
  private Vector4 mat_specular = new Vector4( 0.0, 0.0, 0.0, 1.0 );
  private Vector4 mat_emission = new Vector4( 0.0, 0.0, 0.0, 0.0 );
  private Vector4 spot_ambient = new Vector4( 0.0, 0.0, 0.0, 1.0 );
  private Vector4 spot_color = new Vector4( 1.0, 1.0, 1.0, 0.0 );
  private Vector4 spot_pos = new Vector4( 0.0, 0.0, 1.0, 1.0 );
  private Vector4 spot_dir = new Vector4( 0.0, 0.0, -1.0, 0.0 );

  
  
  private Side1 S1 = new Side1();
  private Side2 S2 = new Side2();
  private Side3 S3 = new Side3();
  private Side4 S4 = new Side4();
  private Side5 S5 = new Side5();
  private Side6 S6 = new Side6();
  private Side7 S7 = new Side7();
  private Side8 S8 = new Side8();

  private int hits = 0;


  public MyCanvas() throws JGLexception 
  {
    // This sets up the paramaters and capabilities of the 
    // JGLcanvas
    
    enabler();
   
  }

  // Here's a fancy event handler that implements
  // Prof. Anderson's familiar azimuth/inclination navigation
  // for 3D-space

  public boolean handleEvent( Event event )
  {
   
    switch( event.id )
      {
	// look for MOUSE_DOWN events
      case Event.MOUSE_DOWN:
	x1 = event.x;
	y1 = event.y;

	// If it's a double-click, go into picking mode, and repaint
	// to run the object through the selection routines
	if ( event.clickCount == 2 )
	  {
	    picking = true;
	    repaint();
	  }
	break;
	
      case Event.MOUSE_DRAG:
	x2 = event.x;
	y2 = event.y;
	dx = x2 -x1;
	dy = y2 - y1;
	
	// Have dx and/or dy changed?
	// and if so, what mouse button are we pressing?

	// Pan
	if ( dx != 0 || dy != 0 )
	  {
	    if ( (event.modifiers & Event.META_MASK) != 0 )
	      {
		panx += dx / 50.0;
		pany -= dy / 50.0;
	      }

	    // Zoom
	    else if ( (event.modifiers & Event.ALT_MASK) != 0 )
	      {
		dist += dy / 4;
	      }

	    // Rotate
	    else
	      {
		azimuth += 1 * dx;
		inclination += 1 * dy;
	      }
	  }
	x1 = x2;
	y1 = y2;
	repaint();
	break;
      }
    return false;
  }

  public void paint( Graphics g ) 
  {
    
    // Notice that almost all JGL canvas operations
    // can potentially throw an exception, so put your
    // drawing routine within a try block, unless you want
    // to handle the exceptions on a section-by-section basis

    try
      {
	SetGraphics( g );
	// alphatest();
	picktest();
	//wireframe();
      }
    catch ( JGLexception e )
      {
	// Do nothing
      }
  }

  public void wireframe() throws JGLexception
  {
    MatrixMode(jgl.MODELVIEW);
    LoadIdentity();
   
    Translate( panx, pany, -6.0 + dist );
    Rotate( azimuth, 0, 1, 0 );
    Rotate( -inclination, 1, 0 ,0 );
	
    MatrixMode( jgl.PROJECTION );
    // Start from the beginning
    LoadIdentity();
    
    // Pick your favorite projection here...
    Ortho( -6.0, 6.0, -6.0, 6.0, .1, 20.0 );
    // Frustum( -6.0, 6.0, -6.0, 6.0, .1, 120.0 );
    // Perspective( 600.0, 1.0, 0.1, 100.0 );
    
    MatrixMode( jgl.MODELVIEW );
    DrawBuffer( jgl.BACK );
    
   
    Clear();

    // Draw
    // qtc1();
    trackBall();

    SwapBuffers();
  }


  public final void alphatest() throws JGLexception
  {
    MatrixMode(jgl.MODELVIEW);
    LoadIdentity();
   
    Translate( panx, pany, -6.0 + dist );
    Rotate( azimuth, 0, 1, 0 );
    Rotate( -inclination, 1, 0 ,0 );
	
    MatrixMode( jgl.PROJECTION );
    // Start from the beginning
    LoadIdentity();
    
    // Pick your favorite projection here...
    Ortho( -6.0, 6.0, -6.0, 6.0, .1, 20.0 );
    // Frustum( -6.0, 6.0, -6.0, 6.0, .1, 120.0 );
    // Perspective( 600.0, 1.0, 0.1, 100.0 );
    
    MatrixMode( jgl.MODELVIEW );
    DrawBuffer( jgl.BACK );
    
    Enable( jgl.BLENDING );
    Clear();

    // Draw
  

    // Bottom
    Color4( 1.0F, 0.0F, 1.0F, 1.0F );
    Begin( jgl.POLYGON );
    Vertex3(  3.0, -3.0, -1.0 );
    Vertex3(  3.0,  3.0, -1.0 );
    Vertex3( -1.0,  3.0, -1.0 );
    Vertex3( -1.0, -3.0, -1.0 );
    End();
    
    // Top
    Color4( 1.0F, 0.0F, 0.0F, 0.5F );
    Begin( jgl.POLYGON );
    Vertex3(  2.0, -2.0, 0.0 );
    Vertex3(  2.0,  2.0, 0.0 );
    Vertex3( -2.0,  2.0, 0.0 );
    Vertex3( -2.0, -2.0, 0.0 );
    End();

  
   

    SwapBuffers();
  }
    
  public final void picktest() throws JGLexception
  {
      	Color3 ( 1.0F, 1.0F, 1.0F );
	MatrixMode(jgl.MODELVIEW);
	LoadIdentity();
	zclear();
	
	// Get the name-stack ready
	InitNames();
	PushName( -1 );
	
	Translate( panx, pany, -6.0 + dist );
	Rotate( azimuth, 0, 1, 0 );
	Rotate( -inclination, 1, 0 ,0 );
	
	MatrixMode( jgl.PROJECTION );
	// Start from the beginning
	LoadIdentity();
	
	// If the event handler has put us in picking mode,
	// go into picking mode, and set up the Picking Transform
	if ( picking )
	  {
	    RenderMode( jgl.SELECT );
	    PickMatrix( x1, y1, 10, 10 );
	  }
	
	// Pick your favorite projection here...
	Ortho( -6.0, 6.0, -6.0, 6.0, .1, 20.0 );
	// Frustum( -6.0, 6.0, -6.0, 6.0, .1, 120.0 );
	// Perspective( 600.0, 1.0, 0.1, 100.0 );
	
	MatrixMode( jgl.MODELVIEW );
	
	DrawBuffer( jgl.BACK );
	
	
	Clear();
	
	// Draw the basic qtc brep, this is broken into different
	// classes to show how Object-based picking might be done.
	// More on this later ( when I get it working :) )
	S1.draw( this );
	S2.draw( this );
	S3.draw( this );
	S4.draw( this );
	S5.draw( this );
	S6.draw( this );
	S7.draw( this );
	S8.draw( this );
	
	// If we aren't in picking mode, process all of the 
	// hit records, and draw the objects in another color
	if ( !picking && hits != 0 )
	  {
	    for ( int k = 0; k <= ( hits - 1); k++ )
	      {
		// We want to be able to draw over what
		// we've already drawn, so clear the z-buffer
		zclear();
		
		int h;
		h = GetGLHit( k );
		
		// Disable lighting so we can choose the colors
		Disable(jgl.LIGHTING);
		if ( h == 1 )
		  S1.drawSelected( this );
		if ( h == 2 )
		  S2.drawSelected( this );
		if ( h == 3 )
		  S3.drawSelected( this );
		if ( h == 4 )
		  S4.drawSelected( this );
		if ( h == 5 )
		  S5.drawSelected( this );
		if ( h == 6 )
		  S6.drawSelected( this );
		if ( h == 7 )
		  S7.drawSelected( this );
		if ( h == 8 )
		  S8.drawSelected( this );
		// Enable lighting so that things look right afterwards
		Enable(jgl.LIGHTING);
	      }
	  }
	
	// We don't want to swap buffers if we are in pick mode
	// as our object would disappear!
	if ( !picking )
	  {
	    SwapBuffers();
	  }
	
	// If we are in pick-mode go back to render mode so we can
	// process the hits
	if ( picking )
	  {
	    hits = RenderMode( jgl.RENDER );
	    picking = false;
	    repaint();
	  }
	
  }

  // Breps from TWIN

  public void qtc1() throws JGLexception
  {
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, 0.000000 );
    Vertex3( 4.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 0.000000, 0.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 0.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.107365, 2.471178, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, 0.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, -1.000000 );
    Vertex3( 3.107365, 2.471178, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, -1.000000 );
    Vertex3( 3.107365, 2.471178, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.107365, 2.471178, 0.000000 );
    Vertex3( 2.825975, 2.385819, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, -1.000000 );
    Vertex3( 2.825975, 2.385819, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, -1.000000 );
    Vertex3( 2.825975, 2.385819, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.825975, 2.385819, 0.000000 );
    Vertex3( 2.566645, 2.247204, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, -1.000000 );
    Vertex3( 2.566645, 2.247204, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, -1.000000 );
    Vertex3( 2.566645, 2.247204, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.566645, 2.247204, 0.000000 );
    Vertex3( 2.339340, 2.060660, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, -1.000000 );
    Vertex3( 2.339340, 2.060660, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, -1.000000 );
    Vertex3( 2.339340, 2.060660, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.339340, 2.060660, 0.000000 );
    Vertex3( 2.152796, 1.833355, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, -1.000000 );
    Vertex3( 2.152796, 1.833355, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, -1.000000 );
    Vertex3( 2.152796, 1.833355, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.152796, 1.833355, 0.000000 );
    Vertex3( 2.014181, 1.574025, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, -1.000000 );
    Vertex3( 2.014181, 1.574025, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, -1.000000 );
    Vertex3( 2.014181, 1.574025, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.014181, 1.574025, 0.000000 );
    Vertex3( 1.928822, 1.292636, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, -1.000000 );
    Vertex3( 1.928822, 1.292636, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, -1.000000 );
    Vertex3( 1.928822, 1.292636, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.928822, 1.292636, 0.000000 );
    Vertex3( 1.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, -1.000000 );
    Vertex3( 1.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 1.900000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.900000, 1.000000, 0.000000 );
    Vertex3( 1.966987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 1.966987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, -1.000000 );
    Vertex3( 2.150000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.966987, 0.750000, 0.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.150000, 0.566987, -1.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.150000, 0.566987, -1.000000 );
    Vertex3( 2.400000, 0.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, 0.000000 );
    Vertex3( 2.150000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, -1.000000 );
    Vertex3( 2.400000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.400000, 0.500000, -1.000000 );
    Vertex3( 2.650000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, 0.000000 );
    Vertex3( 2.400000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, -1.000000 );
    Vertex3( 2.650000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.650000, 0.566987, -1.000000 );
    Vertex3( 2.833013, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, 0.000000 );
    Vertex3( 2.650000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, -1.000000 );
    Vertex3( 2.833013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.833013, 0.750000, -1.000000 );
    Vertex3( 2.900000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, 0.000000 );
    Vertex3( 2.833013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, -1.000000 );
    Vertex3( 2.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.900000, 1.000000, -1.000000 );
    Vertex3( 2.909607, 1.097545, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, 0.000000 );
    Vertex3( 2.900000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, -1.000000 );
    Vertex3( 2.909607, 1.097545, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.909607, 1.097545, -1.000000 );
    Vertex3( 2.938060, 1.191342, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, 0.000000 );
    Vertex3( 2.909607, 1.097545, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, -1.000000 );
    Vertex3( 2.938060, 1.191342, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.938060, 1.191342, -1.000000 );
    Vertex3( 2.984265, 1.277785, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, 0.000000 );
    Vertex3( 2.938060, 1.191342, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, -1.000000 );
    Vertex3( 2.984265, 1.277785, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 2.984265, 1.277785, -1.000000 );
    Vertex3( 3.046447, 1.353553, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, 0.000000 );
    Vertex3( 2.984265, 1.277785, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, -1.000000 );
    Vertex3( 3.046447, 1.353553, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.046447, 1.353553, -1.000000 );
    Vertex3( 3.122215, 1.415735, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, 0.000000 );
    Vertex3( 3.046447, 1.353553, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, -1.000000 );
    Vertex3( 3.122215, 1.415735, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.122215, 1.415735, -1.000000 );
    Vertex3( 3.208658, 1.461940, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, 0.000000 );
    Vertex3( 3.122215, 1.415735, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, -1.000000 );
    Vertex3( 3.208658, 1.461940, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.208658, 1.461940, -1.000000 );
    Vertex3( 3.302455, 1.490393, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, 0.000000 );
    Vertex3( 3.208658, 1.461940, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, -1.000000 );
    Vertex3( 3.302455, 1.490393, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.302455, 1.490393, -1.000000 );
    Vertex3( 3.400000, 1.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, 0.000000 );
    Vertex3( 3.302455, 1.490393, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, -1.000000 );
    Vertex3( 3.400000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 1.500000, -1.000000 );
    Vertex3( 3.650000, 1.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, 0.000000 );
    Vertex3( 3.400000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, -1.000000 );
    Vertex3( 3.650000, 1.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 1.566987, -1.000000 );
    Vertex3( 3.833013, 1.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, 0.000000 );
    Vertex3( 3.650000, 1.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, -1.000000 );
    Vertex3( 3.833013, 1.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 1.750000, -1.000000 );
    Vertex3( 3.900000, 2.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, 0.000000 );
    Vertex3( 3.833013, 1.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, -1.000000 );
    Vertex3( 3.900000, 2.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, -1.000000 );
    Vertex3( 3.833013, 2.250000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.900000, 2.000000, 0.000000 );
    Vertex3( 3.833013, 2.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, -1.000000 );
    Vertex3( 3.833013, 2.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, -1.000000 );
    Vertex3( 3.650000, 2.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.833013, 2.250000, 0.000000 );
    Vertex3( 3.650000, 2.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 2.433013, -1.000000 );
    Vertex3( 3.650000, 2.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.400000, 2.500000, -1.000000 );
    Vertex3( 3.650000, 2.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 3.650000, 2.433013, 0.000000 );
    Vertex3( 3.400000, 2.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, -1.000000 );
    Vertex3( 0.566987, 1.250000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, -1.000000 );
    Vertex3( 0.750000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, 0.000000 );
    Vertex3( 0.750000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, -1.000000 );
    Vertex3( 0.566987, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, -1.000000 );
    Vertex3( 0.750000, 1.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, -1.000000 );
    Vertex3( 1.000000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 1.433013, 0.000000 );
    Vertex3( 1.000000, 1.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 1.433013, -1.000000 );
    Vertex3( 1.000000, 1.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 1.433013, -1.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 1.500000, 0.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.250000, 1.433013, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.433013, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, 0.000000 );
    Vertex3( 1.250000, 1.433013, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 1.250000, -1.000000 );
    Vertex3( 1.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, -1.000000 );
    Vertex3( 1.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, 0.000000 );
    Vertex3( 1.433013, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.500000, 1.000000, -1.000000 );
    Vertex3( 1.433013, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, -1.000000 );
    Vertex3( 1.433013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, 0.000000 );
    Vertex3( 1.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.433013, 0.750000, -1.000000 );
    Vertex3( 1.250000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, -1.000000 );
    Vertex3( 1.250000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, 0.000000 );
    Vertex3( 1.433013, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.250000, 0.566987, -1.000000 );
    Vertex3( 1.000000, 0.500000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, -1.000000 );
    Vertex3( 1.000000, 0.500000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, 0.000000 );
    Vertex3( 1.250000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, -1.000000 );
    Vertex3( 0.750000, 0.566987, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, -1.000000 );
    Vertex3( 0.750000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 1.000000, 0.500000, 0.000000 );
    Vertex3( 0.750000, 0.566987, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, -1.000000 );
    Vertex3( 0.566987, 0.750000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 0.750000, -1.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.750000, 0.566987, 0.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 0.750000, -1.000000 );
    Vertex3( 0.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, -1.000000 );
    Vertex3( 0.500000, 1.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, 0.000000 );
    Vertex3( 0.566987, 0.750000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.566987, 1.250000, -1.000000 );
    Vertex3( 0.500000, 1.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.500000, 1.000000, 0.000000 );
    Vertex3( 0.566987, 1.250000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, -1.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 3.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 4.000000, 0.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, -1.000000 );
    Vertex3( 4.000000, 3.000000, -1.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, -1.000000 );
    Vertex3( 0.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 3.000000, 0.000000 );
    Vertex3( 4.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, 0.000000 );
    Vertex3( 0.000000, 3.000000, 0.000000 );
    End();
    
    Begin(jgl.LINE);
    Vertex3( 0.000000, 0.000000, -1.000000 );
    Vertex3( 0.000000, 3.000000, -1.000000 );
    End();
  }

  public void cylinder() throws JGLexception
  {
    Begin(jgl.LINE);
    Vertex3(0.965926, 0.000000, -0.258819);
    Vertex3(0.965926, 5.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.965926, 5.000000, -0.258819);
    Vertex3(1.000000, 5.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(1.000000, 0.000000, 0.000000);
    Vertex3(1.000000, 5.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.965926, 0.000000, -0.258819);
    Vertex3(1.000000, 0.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 0.000000, -0.500000);
    Vertex3(0.866025, 5.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 5.000000, -0.500000);
    Vertex3(0.965926, 5.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 0.000000, -0.500000);
    Vertex3(0.965926, 0.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 0.000000, -0.707107);
    Vertex3(0.707107, 5.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 5.000000, -0.707107);
    Vertex3(0.866025, 5.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 0.000000, -0.707107);
    Vertex3(0.866025, 0.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 0.000000, -0.866025);
    Vertex3(0.500000, 5.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 5.000000, -0.866025);
    Vertex3(0.707107, 5.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 0.000000, -0.866025);
    Vertex3(0.707107, 0.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 0.000000, -0.965926);
    Vertex3(0.258819, 5.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 5.000000, -0.965926);
    Vertex3(0.500000, 5.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 0.000000, -0.965926);
    Vertex3(0.500000, 0.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 0.000000, -1.000000);
    Vertex3(0.000000, 5.000000, -1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 5.000000, -1.000000);
    Vertex3(0.258819, 5.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 0.000000, -1.000000);
    Vertex3(0.258819, 0.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 0.000000, -0.965926);
    Vertex3(-0.258819, 5.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 5.000000, -0.965926);
    Vertex3(0.000000, 5.000000, -1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 0.000000, -0.965926);
    Vertex3(0.000000, 0.000000, -1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 0.000000, -0.866025);
    Vertex3(-0.500000, 5.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 5.000000, -0.866025);
    Vertex3(-0.258819, 5.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 0.000000, -0.866025);
    Vertex3(-0.258819, 0.000000, -0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 0.000000, -0.707107);
    Vertex3(-0.707107, 5.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 5.000000, -0.707107);
    Vertex3(-0.500000, 5.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 0.000000, -0.707107);
    Vertex3(-0.500000, 0.000000, -0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 0.000000, -0.500000);
    Vertex3(-0.866025, 5.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 5.000000, -0.500000);
    Vertex3(-0.707107, 5.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 0.000000, -0.500000);
    Vertex3(-0.707107, 0.000000, -0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 0.000000, -0.258819);
    Vertex3(-0.965926, 5.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 5.000000, -0.258819);
    Vertex3(-0.866025, 5.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 0.000000, -0.258819);
    Vertex3(-0.866025, 0.000000, -0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-1.000000, 0.000000, 0.000000);
    Vertex3(-1.000000, 5.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-1.000000, 5.000000, 0.000000);
    Vertex3(-0.965926, 5.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-1.000000, 0.000000, 0.000000);
    Vertex3(-0.965926, 0.000000, -0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 0.000000, 0.258819);
    Vertex3(-0.965926, 5.000000, 0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 5.000000, 0.258819);
    Vertex3(-1.000000, 5.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.965926, 0.000000, 0.258819);
    Vertex3(-1.000000, 0.000000, 0.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 0.000000, 0.500000);
    Vertex3(-0.866025, 5.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 5.000000, 0.500000);
    Vertex3(-0.965926, 5.000000, 0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.866025, 0.000000, 0.500000);
    Vertex3(-0.965926, 0.000000, 0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 0.000000, 0.707107);
    Vertex3(-0.707107, 5.000000, 0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 5.000000, 0.707107);
    Vertex3(-0.866025, 5.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.707107, 0.000000, 0.707107);
    Vertex3(-0.866025, 0.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 0.000000, 0.866025);
    Vertex3(-0.500000, 5.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 5.000000, 0.866025);
    Vertex3(-0.707107, 5.000000, 0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.500000, 0.000000, 0.866025);
    Vertex3(-0.707107, 0.000000, 0.707107);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 0.000000, 0.965926);
    Vertex3(-0.258819, 5.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 5.000000, 0.965926);
    Vertex3(-0.500000, 5.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(-0.258819, 0.000000, 0.965926);
    Vertex3(-0.500000, 0.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 0.000000, 1.000000);
    Vertex3(0.000000, 5.000000, 1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 5.000000, 1.000000);
    Vertex3(-0.258819, 5.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.000000, 0.000000, 1.000000);
    Vertex3(-0.258819, 0.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 0.000000, 0.965926);
    Vertex3(0.258819, 5.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 5.000000, 0.965926);
    Vertex3(0.000000, 5.000000, 1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.258819, 0.000000, 0.965926);
    Vertex3(0.000000, 0.000000, 1.000000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 0.000000, 0.866025);
    Vertex3(0.500000, 5.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 5.000000, 0.866025);
    Vertex3(0.258819, 5.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.500000, 0.000000, 0.866025);
    Vertex3(0.258819, 0.000000, 0.965926);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 0.000000, 0.707106);
    Vertex3(0.707107, 5.000000, 0.707106);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 5.000000, 0.707106);
    Vertex3(0.500000, 5.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.707107, 0.000000, 0.707106);
    Vertex3(0.500000, 0.000000, 0.866025);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 0.000000, 0.500000);
    Vertex3(0.866025, 5.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 5.000000, 0.500000);
    Vertex3(0.707107, 5.000000, 0.707106);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.866025, 0.000000, 0.500000);
    Vertex3(0.707107, 0.000000, 0.707106);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.965925, 0.000000, 0.258819);
    Vertex3(0.965925, 5.000000, 0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.965925, 5.000000, 0.258819);
    Vertex3(0.866025, 5.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(0.965925, 0.000000, 0.258819);
    Vertex3(0.866025, 0.000000, 0.500000);
    End();
    
    Begin(jgl.LINE);
    Vertex3(1.000000, 5.000000, 0.000000);
    Vertex3(0.965925, 5.000000, 0.258819);
    End();
    
    Begin(jgl.LINE);
    Vertex3(1.000000, 0.000000, 0.000000);
    Vertex3(0.965925, 0.000000, 0.258819);
    End();
  }

  public void qtcsolid() throws JGLexception
  {


// Top
Normal3( 0.000000, 0.000000, 1.000000 );
Begin(jgl.POLYGON);
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 3.833013, 2.250000, 0.000000 );
Vertex3( 3.900000, 2.000000, 0.000000 );
Vertex3( 3.833013, 1.750000, 0.000000 );
Vertex3( 3.650000, 1.566987, 0.000000 );
Vertex3( 3.400000, 1.500000, 0.000000 );
Vertex3( 3.302455, 1.490393, 0.000000 );
Vertex3( 3.208658, 1.461940, 0.000000 );
Vertex3( 3.122215, 1.415735, 0.000000 );
Vertex3( 3.046447, 1.353553, 0.000000 );
Vertex3( 2.984265, 1.277785, 0.000000 );
Vertex3( 2.938060, 1.191342, 0.000000 );
Vertex3( 2.909607, 1.097545, 0.000000 );
Vertex3( 2.900000, 1.000000, 0.000000 );
Vertex3( 2.833013, 0.750000, 0.000000 );
Vertex3( 2.650000, 0.566987, 0.000000 );
Vertex3( 2.400000, 0.500000, 0.000000 );
Vertex3( 2.150000, 0.566987, 0.000000 );
Vertex3( 1.966987, 0.750000, 0.000000 );
Vertex3( 1.900000, 1.000000, 0.000000 );
Vertex3( 1.928822, 1.292636, 0.000000 );
Vertex3( 2.014181, 1.574025, 0.000000 );
Vertex3( 2.152796, 1.833355, 0.000000 );
Vertex3( 2.339340, 2.060660, 0.000000 );
Vertex3( 2.566645, 2.247204, 0.000000 );
Vertex3( 2.825975, 2.385819, 0.000000 );
Vertex3( 3.107365, 2.471178, 0.000000 );
Vertex3( 3.400000, 2.500000, 0.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.566987, 1.250000, 0.000000 );
Vertex3( 0.750000, 1.433013, 0.000000 );
Vertex3( 1.000000, 1.500000, 0.000000 );
Vertex3( 1.250000, 1.433013, 0.000000 );
Vertex3( 1.433013, 1.250000, 0.000000 );
Vertex3( 1.500000, 1.000000, 0.000000 );
Vertex3( 1.433013, 0.750000, 0.000000 );
Vertex3( 1.250000, 0.566987, 0.000000 );
Vertex3( 1.000000, 0.500000, 0.000000 );
Vertex3( 0.750000, 0.566987, 0.000000 );
Vertex3( 0.566987, 0.750000, 0.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 4.000000, 0.000000, 0.000000 );
End();
    // Bottom
Normal3( 0.000000, 0.000000, -1.000000 );
Begin(jgl.POLYGON);
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 3.400000, 2.500000, -1.000000 );
Vertex3( 3.107365, 2.471178, -1.000000 );
Vertex3( 2.825975, 2.385819, -1.000000 );
Vertex3( 2.566645, 2.247204, -1.000000 );
Vertex3( 2.339340, 2.060660, -1.000000 );
Vertex3( 2.152796, 1.833355, -1.000000 );
Vertex3( 2.014181, 1.574025, -1.000000 );
Vertex3( 1.928822, 1.292636, -1.000000 );
Vertex3( 1.900000, 1.000000, -1.000000 );
Vertex3( 1.966987, 0.750000, -1.000000 );
Vertex3( 2.150000, 0.566987, -1.000000 );
Vertex3( 2.400000, 0.500000, -1.000000 );
Vertex3( 2.650000, 0.566987, -1.000000 );
Vertex3( 2.833013, 0.750000, -1.000000 );
Vertex3( 2.900000, 1.000000, -1.000000 );
Vertex3( 2.909607, 1.097545, -1.000000 );
Vertex3( 2.938060, 1.191342, -1.000000 );
Vertex3( 2.984265, 1.277785, -1.000000 );
Vertex3( 3.046447, 1.353553, -1.000000 );
Vertex3( 3.122215, 1.415735, -1.000000 );
Vertex3( 3.208658, 1.461940, -1.000000 );
Vertex3( 3.302455, 1.490393, -1.000000 );
Vertex3( 3.400000, 1.500000, -1.000000 );
Vertex3( 3.650000, 1.566987, -1.000000 );
Vertex3( 3.833013, 1.750000, -1.000000 );
Vertex3( 3.900000, 2.000000, -1.000000 );
Vertex3( 3.833013, 2.250000, -1.000000 );
Vertex3( 3.650000, 2.433013, -1.000000 );
Vertex3( 3.400000, 2.500000, -1.000000 );
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 4.000000, 0.000000, -1.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 0.566987, 0.750000, -1.000000 );
Vertex3( 0.750000, 0.566987, -1.000000 );
Vertex3( 1.000000, 0.500000, -1.000000 );
Vertex3( 1.250000, 0.566987, -1.000000 );
Vertex3( 1.433013, 0.750000, -1.000000 );
Vertex3( 1.500000, 1.000000, -1.000000 );
Vertex3( 1.433013, 1.250000, -1.000000 );
Vertex3( 1.250000, 1.433013, -1.000000 );
Vertex3( 1.000000, 1.500000, -1.000000 );
Vertex3( 0.750000, 1.433013, -1.000000 );
Vertex3( 0.566987, 1.250000, -1.000000 );
Vertex3( 0.500000, 1.000000, -1.000000 );
Vertex3( 0.566987, 0.750000, -1.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, -1.000000 );
End();

// Top
Normal3( 0.000000, 1.000000, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 4.000000, 3.000000, 0.000000 );
End();


    

Normal3( 0.098017, -0.995185, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.400000, 2.500000, -1.000000 );
Vertex3( 3.400000, 2.500000, 0.000000 );
Vertex3( 3.107365, 2.471178, 0.000000 );
Vertex3( 3.107365, 2.471178, -1.000000 );
End();
Normal3( 0.290286, -0.956940, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.107365, 2.471178, -1.000000 );
Vertex3( 3.107365, 2.471178, 0.000000 );
Vertex3( 2.825975, 2.385819, 0.000000 );
Vertex3( 2.825975, 2.385819, -1.000000 );
End();
Normal3( 0.471397, -0.881921, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.825975, 2.385819, -1.000000 );
Vertex3( 2.825975, 2.385819, 0.000000 );
Vertex3( 2.566645, 2.247204, 0.000000 );
Vertex3( 2.566645, 2.247204, -1.000000 );
End();
Normal3( 0.634392, -0.773011, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.566645, 2.247204, -1.000000 );
Vertex3( 2.566645, 2.247204, 0.000000 );
Vertex3( 2.339340, 2.060660, 0.000000 );
Vertex3( 2.339340, 2.060660, -1.000000 );
End();
Normal3( 0.773011, -0.634392, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.339340, 2.060660, -1.000000 );
Vertex3( 2.339340, 2.060660, 0.000000 );
Vertex3( 2.152796, 1.833355, 0.000000 );
Vertex3( 2.152796, 1.833355, -1.000000 );
End();
Normal3( 0.881921, -0.471397, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.152796, 1.833355, -1.000000 );
Vertex3( 2.152796, 1.833355, 0.000000 );
Vertex3( 2.014181, 1.574025, 0.000000 );
Vertex3( 2.014181, 1.574025, -1.000000 );
End();
Normal3( 0.956940, -0.290286, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.014181, 1.574025, -1.000000 );
Vertex3( 2.014181, 1.574025, 0.000000 );
Vertex3( 1.928822, 1.292636, 0.000000 );
Vertex3( 1.928822, 1.292636, -1.000000 );
End();
Normal3( 0.995185, -0.098017, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.928822, 1.292636, -1.000000 );
Vertex3( 1.928822, 1.292636, 0.000000 );
Vertex3( 1.900000, 1.000000, 0.000000 );
Vertex3( 1.900000, 1.000000, -1.000000 );
End();
Normal3( 0.965926, 0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.900000, 1.000000, -1.000000 );
Vertex3( 1.900000, 1.000000, 0.000000 );
Vertex3( 1.966987, 0.750000, 0.000000 );
Vertex3( 1.966987, 0.750000, -1.000000 );
End();
Normal3( 0.707107, 0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.966987, 0.750000, -1.000000 );
Vertex3( 1.966987, 0.750000, 0.000000 );
Vertex3( 2.150000, 0.566987, 0.000000 );
Vertex3( 2.150000, 0.566987, -1.000000 );
End();
Normal3( 0.258818, 0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.150000, 0.566987, -1.000000 );
Vertex3( 2.150000, 0.566987, 0.000000 );
Vertex3( 2.400000, 0.500000, 0.000000 );
Vertex3( 2.400000, 0.500000, -1.000000 );
End();
Normal3( -0.258818, 0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.400000, 0.500000, -1.000000 );
Vertex3( 2.400000, 0.500000, 0.000000 );
Vertex3( 2.650000, 0.566987, 0.000000 );
Vertex3( 2.650000, 0.566987, -1.000000 );
End();
Normal3( -0.707107, 0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.650000, 0.566987, -1.000000 );
Vertex3( 2.650000, 0.566987, 0.000000 );
Vertex3( 2.833013, 0.750000, 0.000000 );
Vertex3( 2.833013, 0.750000, -1.000000 );
End();
Normal3( -0.965926, 0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.833013, 0.750000, -1.000000 );
Vertex3( 2.833013, 0.750000, 0.000000 );
Vertex3( 2.900000, 1.000000, 0.000000 );
Vertex3( 2.900000, 1.000000, -1.000000 );
End();
Normal3( -0.995185, 0.098014, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.900000, 1.000000, -1.000000 );
Vertex3( 2.900000, 1.000000, 0.000000 );
Vertex3( 2.909607, 1.097545, 0.000000 );
Vertex3( 2.909607, 1.097545, -1.000000 );
End();
Normal3( -0.956940, 0.290285, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.909607, 1.097545, -1.000000 );
Vertex3( 2.909607, 1.097545, 0.000000 );
Vertex3( 2.938060, 1.191342, 0.000000 );
Vertex3( 2.938060, 1.191342, -1.000000 );
End();
Normal3( -0.881920, 0.471399, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.938060, 1.191342, -1.000000 );
Vertex3( 2.938060, 1.191342, 0.000000 );
Vertex3( 2.984265, 1.277785, 0.000000 );
Vertex3( 2.984265, 1.277785, -1.000000 );
End();
Normal3( -0.773006, 0.634398, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 2.984265, 1.277785, -1.000000 );
Vertex3( 2.984265, 1.277785, 0.000000 );
Vertex3( 3.046447, 1.353553, 0.000000 );
Vertex3( 3.046447, 1.353553, -1.000000 );
End();
Normal3( -0.634398, 0.773006, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.046447, 1.353553, -1.000000 );
Vertex3( 3.046447, 1.353553, 0.000000 );
Vertex3( 3.122215, 1.415735, 0.000000 );
Vertex3( 3.122215, 1.415735, -1.000000 );
End();
Normal3( -0.471399, 0.881920, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.122215, 1.415735, -1.000000 );
Vertex3( 3.122215, 1.415735, 0.000000 );
Vertex3( 3.208658, 1.461940, 0.000000 );
Vertex3( 3.208658, 1.461940, -1.000000 );
End();
Normal3( -0.290285, 0.956940, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.208658, 1.461940, -1.000000 );
Vertex3( 3.208658, 1.461940, 0.000000 );
Vertex3( 3.302455, 1.490393, 0.000000 );
Vertex3( 3.302455, 1.490393, -1.000000 );
End();
Normal3( -0.098014, 0.995185, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.302455, 1.490393, -1.000000 );
Vertex3( 3.302455, 1.490393, 0.000000 );
Vertex3( 3.400000, 1.500000, 0.000000 );
Vertex3( 3.400000, 1.500000, -1.000000 );
End();
Normal3( -0.258818, 0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.400000, 1.500000, -1.000000 );
Vertex3( 3.400000, 1.500000, 0.000000 );
Vertex3( 3.650000, 1.566987, 0.000000 );
Vertex3( 3.650000, 1.566987, -1.000000 );
End();
Normal3( -0.707107, 0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.650000, 1.566987, -1.000000 );
Vertex3( 3.650000, 1.566987, 0.000000 );
Vertex3( 3.833013, 1.750000, 0.000000 );
Vertex3( 3.833013, 1.750000, -1.000000 );
End();
Normal3( -0.965926, 0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.833013, 1.750000, -1.000000 );
Vertex3( 3.833013, 1.750000, 0.000000 );
Vertex3( 3.900000, 2.000000, 0.000000 );
Vertex3( 3.900000, 2.000000, -1.000000 );
End();
Normal3( -0.965926, -0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.900000, 2.000000, -1.000000 );
Vertex3( 3.900000, 2.000000, 0.000000 );
Vertex3( 3.833013, 2.250000, 0.000000 );
Vertex3( 3.833013, 2.250000, -1.000000 );
End();
Normal3( -0.707107, -0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.833013, 2.250000, -1.000000 );
Vertex3( 3.833013, 2.250000, 0.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 3.650000, 2.433013, -1.000000 );
End();
Normal3( -0.258818, -0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 3.650000, 2.433013, -1.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 3.400000, 2.500000, 0.000000 );
Vertex3( 3.400000, 2.500000, -1.000000 );
End();
Normal3( 0.707107, -0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.750000, 1.433013, -1.000000 );
Vertex3( 0.750000, 1.433013, 0.000000 );
Vertex3( 0.566987, 1.250000, 0.000000 );
Vertex3( 0.566987, 1.250000, -1.000000 );
End();
Normal3( 0.258818, -0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.000000, 1.500000, -1.000000 );
Vertex3( 1.000000, 1.500000, 0.000000 );
Vertex3( 0.750000, 1.433013, 0.000000 );
Vertex3( 0.750000, 1.433013, -1.000000 );
End();
Normal3( -0.258818, -0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.250000, 1.433013, -1.000000 );
Vertex3( 1.250000, 1.433013, 0.000000 );
Vertex3( 1.000000, 1.500000, 0.000000 );
Vertex3( 1.000000, 1.500000, -1.000000 );
End();
Normal3( -0.707107, -0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.433013, 1.250000, -1.000000 );
Vertex3( 1.433013, 1.250000, 0.000000 );
Vertex3( 1.250000, 1.433013, 0.000000 );
Vertex3( 1.250000, 1.433013, -1.000000 );
End();
Normal3( -0.965926, -0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.500000, 1.000000, -1.000000 );
Vertex3( 1.500000, 1.000000, 0.000000 );
Vertex3( 1.433013, 1.250000, 0.000000 );
Vertex3( 1.433013, 1.250000, -1.000000 );
End();
Normal3( -0.965926, 0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.433013, 0.750000, -1.000000 );
Vertex3( 1.433013, 0.750000, 0.000000 );
Vertex3( 1.500000, 1.000000, 0.000000 );
Vertex3( 1.500000, 1.000000, -1.000000 );
End();
Normal3( -0.707107, 0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.250000, 0.566987, -1.000000 );
Vertex3( 1.250000, 0.566987, 0.000000 );
Vertex3( 1.433013, 0.750000, 0.000000 );
Vertex3( 1.433013, 0.750000, -1.000000 );
End();
Normal3( -0.258818, 0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 1.000000, 0.500000, -1.000000 );
Vertex3( 1.000000, 0.500000, 0.000000 );
Vertex3( 1.250000, 0.566987, 0.000000 );
Vertex3( 1.250000, 0.566987, -1.000000 );
End();
Normal3( 0.258818, 0.965926, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.750000, 0.566987, -1.000000 );
Vertex3( 0.750000, 0.566987, 0.000000 );
Vertex3( 1.000000, 0.500000, 0.000000 );
Vertex3( 1.000000, 0.500000, -1.000000 );
End();
Normal3( 0.707107, 0.707107, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.566987, 0.750000, -1.000000 );
Vertex3( 0.566987, 0.750000, 0.000000 );
Vertex3( 0.750000, 0.566987, 0.000000 );
Vertex3( 0.750000, 0.566987, -1.000000 );
End();
Normal3( 0.965926, 0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.500000, 1.000000, -1.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.566987, 0.750000, 0.000000 );
Vertex3( 0.566987, 0.750000, -1.000000 );
End();
Normal3( 0.965926, -0.258818, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.566987, 1.250000, -1.000000 );
Vertex3( 0.566987, 1.250000, 0.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.500000, 1.000000, -1.000000 );
End();




// Left side
Color3 ( 1.0F, 0.0F, 0.0F );
Normal3( -1.000000, 0.000000, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Color3 ( 0.0F, 1.0F, 0.0F );
Vertex3( 0.000000, 3.000000, -1.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
End();

// Right side
Color3 ( 1.0F, 0.0F, 0.0F);
Normal3( 1.000000, 0.000000, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 4.000000, 0.000000, -1.000000 );
Vertex3( 4.000000, 3.000000, -1.000000 );
Color3 ( 0.0F, 1.0F, 0.0F );
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 4.000000, 0.000000, 0.000000 );
End();

// Bottom
Normal3( 0.000000, -1.000000, 0.000000 );
Begin(jgl.POLYGON);
Vertex3( 4.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 4.000000, 0.000000, -1.000000 );
End();




  }
  
  private void flag() throws JGLexception
  {
    Begin( jgl.POLYGON );
    Normal3( 0.00, 0.00, -1.0 );
    Vertex3( 0.00, 0.00, -0.0 );
    Vertex3( 0.00, 3.00, -0.0 );
    Vertex3( 3.00, 3.00, -0.0 );
    Vertex3( 4.00, 1.50, -0.0 );
    Vertex3( 3.00, 0.00, -0.0 );
    End();
  }


  private void smooth() throws JGLexception
  {
    Begin(jgl.POLYGON);
Normal3( 0.000000, -1.000000, 0.000000);
Vertex3( 4.000000, 0.000000, -1.000000 );
Vertex3( 4.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.195091, -0.980785, 0.000000);
Vertex3( 3.107365, 2.471178, 0.000000 );
Normal3( 0.195091, -0.980785, 0.000000);
Vertex3( 3.107365, 2.471178, -1.000000 );
Normal3( 0.098017, -0.995185, 0.000000);
Vertex3( 3.400000, 2.500000, -1.000000 );
Normal3( 0.098017, -0.995185, 0.000000);
Vertex3( 3.400000, 2.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.382684, -0.923879, 0.000000);
Vertex3( 2.825975, 2.385819, 0.000000 );
Normal3( 0.382684, -0.923879, 0.000000);
Vertex3( 2.825975, 2.385819, -1.000000 );
Normal3( 0.195091, -0.980785, 0.000000);
Vertex3( 3.107365, 2.471178, -1.000000 );
Normal3( 0.195091, -0.980785, 0.000000);
Vertex3( 3.107365, 2.471178, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.555570, -0.831470, 0.000000);
Vertex3( 2.566645, 2.247204, 0.000000 );
Normal3( 0.555570, -0.831470, 0.000000);
Vertex3( 2.566645, 2.247204, -1.000000 );
Normal3( 0.382684, -0.923879, 0.000000);
Vertex3( 2.825975, 2.385819, -1.000000 );
Normal3( 0.382684, -0.923879, 0.000000);
Vertex3( 2.825975, 2.385819, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.707107, -0.707107, 0.000000);
Vertex3( 2.339340, 2.060660, 0.000000 );
Normal3( 0.707107, -0.707107, 0.000000);
Vertex3( 2.339340, 2.060660, -1.000000 );
Normal3( 0.555570, -0.831470, 0.000000);
Vertex3( 2.566645, 2.247204, -1.000000 );
Normal3( 0.555570, -0.831470, 0.000000);
Vertex3( 2.566645, 2.247204, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.831470, -0.555570, 0.000000);
Vertex3( 2.152796, 1.833355, 0.000000 );
Normal3( 0.831470, -0.555570, 0.000000);
Vertex3( 2.152796, 1.833355, -1.000000 );
Normal3( 0.707107, -0.707107, 0.000000);
Vertex3( 2.339340, 2.060660, -1.000000 );
Normal3( 0.707107, -0.707107, 0.000000);
Vertex3( 2.339340, 2.060660, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.923879, -0.382685, 0.000000);
Vertex3( 2.014181, 1.574025, 0.000000 );
Normal3( 0.923879, -0.382685, 0.000000);
Vertex3( 2.014181, 1.574025, -1.000000 );
Normal3( 0.831470, -0.555570, 0.000000);
Vertex3( 2.152796, 1.833355, -1.000000 );
Normal3( 0.831470, -0.555570, 0.000000);
Vertex3( 2.152796, 1.833355, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.980785, -0.195091, 0.000000);
Vertex3( 1.928822, 1.292636, 0.000000 );
Normal3( 0.980785, -0.195091, 0.000000);
Vertex3( 1.928822, 1.292636, -1.000000 );
Normal3( 0.923879, -0.382685, 0.000000);
Vertex3( 2.014181, 1.574025, -1.000000 );
Normal3( 0.923879, -0.382685, 0.000000);
Vertex3( 2.014181, 1.574025, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.995185, -0.098017, 0.000000);
Vertex3( 1.900000, 1.000000, -1.000000 );
Normal3( 0.980785, -0.195091, 0.000000);
Vertex3( 1.928822, 1.292636, -1.000000 );
Normal3( 0.980785, -0.195091, 0.000000);
Vertex3( 1.928822, 1.292636, 0.000000 );
Normal3( 0.995185, -0.098017, 0.000000);
Vertex3( 1.900000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 1.966987, 0.750000, 0.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 1.966987, 0.750000, -1.000000 );
Normal3( 0.965926, 0.258818, 0.000000);
Vertex3( 1.900000, 1.000000, -1.000000 );
Normal3( 0.965926, 0.258818, 0.000000);
Vertex3( 1.900000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 2.150000, 0.566987, 0.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 2.150000, 0.566987, -1.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 1.966987, 0.750000, -1.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 1.966987, 0.750000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 2.400000, 0.500000, 0.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 2.400000, 0.500000, -1.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 2.150000, 0.566987, -1.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 2.150000, 0.566987, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 2.650000, 0.566987, 0.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 2.650000, 0.566987, -1.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 2.400000, 0.500000, -1.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 2.400000, 0.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 2.833013, 0.750000, 0.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 2.833013, 0.750000, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 2.650000, 0.566987, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 2.650000, 0.566987, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.965926, 0.258818, 0.000000);
Vertex3( 2.900000, 1.000000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 2.833013, 0.750000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 2.833013, 0.750000, 0.000000 );
Normal3( -0.965926, 0.258818, 0.000000);
Vertex3( 2.900000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.980786, 0.195089, 0.000000);
Vertex3( 2.909607, 1.097545, 0.000000 );
Normal3( -0.980786, 0.195089, 0.000000);
Vertex3( 2.909607, 1.097545, -1.000000 );
Normal3( -0.995185, 0.098014, 0.000000);
Vertex3( 2.900000, 1.000000, -1.000000 );
Normal3( -0.995185, 0.098014, 0.000000);
Vertex3( 2.900000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.923879, 0.382684, 0.000000);
Vertex3( 2.938060, 1.191342, 0.000000 );
Normal3( -0.923879, 0.382684, 0.000000);
Vertex3( 2.938060, 1.191342, -1.000000 );
Normal3( -0.980786, 0.195089, 0.000000);
Vertex3( 2.909607, 1.097545, -1.000000 );
Normal3( -0.980786, 0.195089, 0.000000);
Vertex3( 2.909607, 1.097545, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.831467, 0.555574, 0.000000);
Vertex3( 2.984265, 1.277785, 0.000000 );
Normal3( -0.831467, 0.555574, 0.000000);
Vertex3( 2.984265, 1.277785, -1.000000 );
Normal3( -0.923879, 0.382684, 0.000000);
Vertex3( 2.938060, 1.191342, -1.000000 );
Normal3( -0.923879, 0.382684, 0.000000);
Vertex3( 2.938060, 1.191342, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.707107, 0.707107, 0.000000);
Vertex3( 3.046447, 1.353553, 0.000000 );
Normal3( -0.707107, 0.707107, 0.000000);
Vertex3( 3.046447, 1.353553, -1.000000 );
Normal3( -0.831467, 0.555574, 0.000000);
Vertex3( 2.984265, 1.277785, -1.000000 );
Normal3( -0.831467, 0.555574, 0.000000);
Vertex3( 2.984265, 1.277785, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.555574, 0.831467, 0.000000);
Vertex3( 3.122215, 1.415735, 0.000000 );
Normal3( -0.555574, 0.831467, 0.000000);
Vertex3( 3.122215, 1.415735, -1.000000 );
Normal3( -0.707107, 0.707107, 0.000000);
Vertex3( 3.046447, 1.353553, -1.000000 );
Normal3( -0.707107, 0.707107, 0.000000);
Vertex3( 3.046447, 1.353553, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.382684, 0.923879, 0.000000);
Vertex3( 3.208658, 1.461940, 0.000000 );
Normal3( -0.382684, 0.923879, 0.000000);
Vertex3( 3.208658, 1.461940, -1.000000 );
Normal3( -0.555574, 0.831467, 0.000000);
Vertex3( 3.122215, 1.415735, -1.000000 );
Normal3( -0.555574, 0.831467, 0.000000);
Vertex3( 3.122215, 1.415735, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.195089, 0.980786, 0.000000);
Vertex3( 3.302455, 1.490393, 0.000000 );
Normal3( -0.195089, 0.980786, 0.000000);
Vertex3( 3.302455, 1.490393, -1.000000 );
Normal3( -0.382684, 0.923879, 0.000000);
Vertex3( 3.208658, 1.461940, -1.000000 );
Normal3( -0.382684, 0.923879, 0.000000);
Vertex3( 3.208658, 1.461940, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.098014, 0.995185, 0.000000);
Vertex3( 3.400000, 1.500000, -1.000000 );
Normal3( -0.195089, 0.980786, 0.000000);
Vertex3( 3.302455, 1.490393, -1.000000 );
Normal3( -0.195089, 0.980786, 0.000000);
Vertex3( 3.302455, 1.490393, 0.000000 );
Normal3( -0.098014, 0.995185, 0.000000);
Vertex3( 3.400000, 1.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 3.650000, 1.566987, 0.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 3.650000, 1.566987, -1.000000 );
Normal3( -0.258818, 0.965926, 0.000000);
Vertex3( 3.400000, 1.500000, -1.000000 );
Normal3( -0.258818, 0.965926, 0.000000);
Vertex3( 3.400000, 1.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 3.833013, 1.750000, 0.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 3.833013, 1.750000, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 3.650000, 1.566987, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 3.650000, 1.566987, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 3.900000, 2.000000, 0.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 3.900000, 2.000000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 3.833013, 1.750000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 3.833013, 1.750000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 3.833013, 2.250000, 0.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 3.833013, 2.250000, -1.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 3.900000, 2.000000, -1.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 3.900000, 2.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 3.650000, 2.433013, 0.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 3.650000, 2.433013, -1.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 3.833013, 2.250000, -1.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 3.833013, 2.250000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.258818, -0.965926, 0.000000);
Vertex3( 3.400000, 2.500000, 0.000000 );
Normal3( -0.258818, -0.965926, 0.000000);
Vertex3( 3.400000, 2.500000, -1.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 3.650000, 2.433013, -1.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 3.650000, 2.433013, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.866026, -0.500000, 0.000000);
Vertex3( 0.566987, 1.250000, 0.000000 );
Normal3( 0.866026, -0.500000, 0.000000);
Vertex3( 0.566987, 1.250000, -1.000000 );
Normal3( 0.500000, -0.866026, 0.000000);
Vertex3( 0.750000, 1.433013, -1.000000 );
Normal3( 0.500000, -0.866026, 0.000000);
Vertex3( 0.750000, 1.433013, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.500000, -0.866026, 0.000000);
Vertex3( 0.750000, 1.433013, 0.000000 );
Normal3( 0.500000, -0.866026, 0.000000);
Vertex3( 0.750000, 1.433013, -1.000000 );
Normal3( 0.000000, -1.000000, 0.000000);
Vertex3( 1.000000, 1.500000, -1.000000 );
Normal3( 0.000000, -1.000000, 0.000000);
Vertex3( 1.000000, 1.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, -1.000000, 0.000000);
Vertex3( 1.000000, 1.500000, 0.000000 );
Normal3( 0.000000, -1.000000, 0.000000);
Vertex3( 1.000000, 1.500000, -1.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 1.250000, 1.433013, -1.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 1.250000, 1.433013, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 1.250000, 1.433013, 0.000000 );
Normal3( -0.500000, -0.866026, 0.000000);
Vertex3( 1.250000, 1.433013, -1.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 1.433013, 1.250000, -1.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 1.433013, 1.250000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 1.433013, 1.250000, 0.000000 );
Normal3( -0.866026, -0.500000, 0.000000);
Vertex3( 1.433013, 1.250000, -1.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 1.500000, 1.000000, -1.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 1.500000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 1.500000, 1.000000, 0.000000 );
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 1.500000, 1.000000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 1.433013, 0.750000, -1.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 1.433013, 0.750000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 1.433013, 0.750000, 0.000000 );
Normal3( -0.866026, 0.500000, 0.000000);
Vertex3( 1.433013, 0.750000, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 1.250000, 0.566987, -1.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 1.250000, 0.566987, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 1.250000, 0.566987, 0.000000 );
Normal3( -0.500000, 0.866026, 0.000000);
Vertex3( 1.250000, 0.566987, -1.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 1.000000, 0.500000, -1.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 1.000000, 0.500000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 1.000000, 0.500000, 0.000000 );
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 1.000000, 0.500000, -1.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 0.750000, 0.566987, -1.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 0.750000, 0.566987, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 0.750000, 0.566987, 0.000000 );
Normal3( 0.500000, 0.866026, 0.000000);
Vertex3( 0.750000, 0.566987, -1.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 0.566987, 0.750000, -1.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 0.566987, 0.750000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 0.566987, 0.750000, 0.000000 );
Normal3( 0.866026, 0.500000, 0.000000);
Vertex3( 0.566987, 0.750000, -1.000000 );
Normal3( 1.000000, 0.000000, 0.000000);
Vertex3( 0.500000, 1.000000, -1.000000 );
Normal3( 1.000000, 0.000000, 0.000000);
Vertex3( 0.500000, 1.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 1.000000, 0.000000, 0.000000);
Vertex3( 0.500000, 1.000000, 0.000000 );
Normal3( 1.000000, 0.000000, 0.000000);
Vertex3( 0.500000, 1.000000, -1.000000 );
Normal3( 0.866026, -0.500000, 0.000000);
Vertex3( 0.566987, 1.250000, -1.000000 );
Normal3( 0.866026, -0.500000, 0.000000);
Vertex3( 0.566987, 1.250000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 1.000000, 0.000000, 0.000000);
Vertex3( 4.000000, 0.000000, 0.000000 );
Vertex3( 4.000000, 0.000000, -1.000000 );
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 4.000000, 3.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, 1.000000, 0.000000);
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( -1.000000, 0.000000, 0.000000);
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, -1.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, 0.000000, 1.000000);
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 3.833013, 2.250000, 0.000000 );
Vertex3( 3.900000, 2.000000, 0.000000 );
Vertex3( 3.833013, 1.750000, 0.000000 );
Vertex3( 3.650000, 1.566987, 0.000000 );
Vertex3( 3.400000, 1.500000, 0.000000 );
Vertex3( 3.302455, 1.490393, 0.000000 );
Vertex3( 3.208658, 1.461940, 0.000000 );
Vertex3( 3.122215, 1.415735, 0.000000 );
Vertex3( 3.046447, 1.353553, 0.000000 );
Vertex3( 2.984265, 1.277785, 0.000000 );
Vertex3( 2.938060, 1.191342, 0.000000 );
Vertex3( 2.909607, 1.097545, 0.000000 );
Vertex3( 2.900000, 1.000000, 0.000000 );
Vertex3( 2.833013, 0.750000, 0.000000 );
Vertex3( 2.650000, 0.566987, 0.000000 );
Vertex3( 2.400000, 0.500000, 0.000000 );
Vertex3( 2.150000, 0.566987, 0.000000 );
Vertex3( 1.966987, 0.750000, 0.000000 );
Vertex3( 1.900000, 1.000000, 0.000000 );
Vertex3( 1.928822, 1.292636, 0.000000 );
Vertex3( 2.014181, 1.574025, 0.000000 );
Vertex3( 2.152796, 1.833355, 0.000000 );
Vertex3( 2.339340, 2.060660, 0.000000 );
Vertex3( 2.566645, 2.247204, 0.000000 );
Vertex3( 2.825975, 2.385819, 0.000000 );
Vertex3( 3.107365, 2.471178, 0.000000 );
Vertex3( 3.400000, 2.500000, 0.000000 );
Vertex3( 3.650000, 2.433013, 0.000000 );
Vertex3( 4.000000, 3.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.566987, 1.250000, 0.000000 );
Vertex3( 0.750000, 1.433013, 0.000000 );
Vertex3( 1.000000, 1.500000, 0.000000 );
Vertex3( 1.250000, 1.433013, 0.000000 );
Vertex3( 1.433013, 1.250000, 0.000000 );
Vertex3( 1.500000, 1.000000, 0.000000 );
Vertex3( 1.433013, 0.750000, 0.000000 );
Vertex3( 1.250000, 0.566987, 0.000000 );
Vertex3( 1.000000, 0.500000, 0.000000 );
Vertex3( 0.750000, 0.566987, 0.000000 );
Vertex3( 0.566987, 0.750000, 0.000000 );
Vertex3( 0.500000, 1.000000, 0.000000 );
Vertex3( 0.000000, 3.000000, 0.000000 );
Vertex3( 0.000000, 0.000000, 0.000000 );
Vertex3( 4.000000, 0.000000, 0.000000 );
End();
Begin(jgl.POLYGON);
Normal3( 0.000000, 0.000000, -1.000000);
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 3.400000, 2.500000, -1.000000 );
Vertex3( 3.107365, 2.471178, -1.000000 );
Vertex3( 2.825975, 2.385819, -1.000000 );
Vertex3( 2.566645, 2.247204, -1.000000 );
Vertex3( 2.339340, 2.060660, -1.000000 );
Vertex3( 2.152796, 1.833355, -1.000000 );
Vertex3( 2.014181, 1.574025, -1.000000 );
Vertex3( 1.928822, 1.292636, -1.000000 );
Vertex3( 1.900000, 1.000000, -1.000000 );
Vertex3( 1.966987, 0.750000, -1.000000 );
Vertex3( 2.150000, 0.566987, -1.000000 );
Vertex3( 2.400000, 0.500000, -1.000000 );
Vertex3( 2.650000, 0.566987, -1.000000 );
Vertex3( 2.833013, 0.750000, -1.000000 );
Vertex3( 2.900000, 1.000000, -1.000000 );
Vertex3( 2.909607, 1.097545, -1.000000 );
Vertex3( 2.938060, 1.191342, -1.000000 );
Vertex3( 2.984265, 1.277785, -1.000000 );
Vertex3( 3.046447, 1.353553, -1.000000 );
Vertex3( 3.122215, 1.415735, -1.000000 );
Vertex3( 3.208658, 1.461940, -1.000000 );
Vertex3( 3.302455, 1.490393, -1.000000 );
Vertex3( 3.400000, 1.500000, -1.000000 );
Vertex3( 3.650000, 1.566987, -1.000000 );
Vertex3( 3.833013, 1.750000, -1.000000 );
Vertex3( 3.900000, 2.000000, -1.000000 );
Vertex3( 3.833013, 2.250000, -1.000000 );
Vertex3( 3.650000, 2.433013, -1.000000 );
Vertex3( 3.400000, 2.500000, -1.000000 );
Vertex3( 4.000000, 3.000000, -1.000000 );
Vertex3( 4.000000, 0.000000, -1.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 0.566987, 0.750000, -1.000000 );
Vertex3( 0.750000, 0.566987, -1.000000 );
Vertex3( 1.000000, 0.500000, -1.000000 );
Vertex3( 1.250000, 0.566987, -1.000000 );
Vertex3( 1.433013, 0.750000, -1.000000 );
Vertex3( 1.500000, 1.000000, -1.000000 );
Vertex3( 1.433013, 1.250000, -1.000000 );
Vertex3( 1.250000, 1.433013, -1.000000 );
Vertex3( 1.000000, 1.500000, -1.000000 );
Vertex3( 0.750000, 1.433013, -1.000000 );
Vertex3( 0.566987, 1.250000, -1.000000 );
Vertex3( 0.500000, 1.000000, -1.000000 );
Vertex3( 0.566987, 0.750000, -1.000000 );
Vertex3( 0.000000, 0.000000, -1.000000 );
Vertex3( 0.000000, 3.000000, -1.000000 );
End();
  }

  private void trackBall() throws JGLexception
  {
    PushMatrix();
    Scale( 3.0, 3.0, 3.0 );
    halfArc();
    PushMatrix();
    Rotate( 180, 0.0, 0.0, 1.0 );
    halfArc();
    PopMatrix();
    Rotate( 90, 0.0, 1.0, 0.0 );
    halfArc();
    Rotate( 90, 0.0, 0.0, 1.0 );
    halfArc();
    PopMatrix();
  }

  private void halfArc() throws JGLexception
  {
    double piOver180 = Math.PI / 180.0;
    double dTheta = 6.0 * piOver180;
    double a = 15;
    double x = 1.0, y = 1.0, xp = 0, yp = 0;
    double c = Math.cos( dTheta );
    double s = Math.sin( dTheta );
    double dz = .08;
    
  
    Color3( 1.0F, 1.0F, 1.0F );
    
    Begin( jgl.LINE );
    Vertex3( Math.cos( 12.0*piOver180 ), Math.sin( 12.0*piOver180 ), -dz );
    Vertex3( Math.cos( 0.0*piOver180 ), Math.sin( 0.0*piOver180 ), 0.0 );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 0.0*piOver180 ), Math.sin( 0.0*piOver180 ), 0.0 );
    Vertex3( Math.cos( 348.0*piOver180 ), Math.sin( 348.0*piOver180 ), dz );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 12.0*piOver180 ), Math.sin( 12.0*piOver180 ), dz );
    Vertex3( Math.cos( 0.0*piOver180 ), Math.sin( 0.0*piOver180 ), 0.0 );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 0.0*piOver180 ), Math.sin( 0.0*piOver180 ), 0.0 );
    Vertex3( Math.cos( 348.0*piOver180 ), Math.sin( 348.0*piOver180 ), -dz );
    End();

   
    Begin( jgl.LINE );
    Vertex3( Math.cos( 12.0*piOver180 ), Math.sin( 12.0*piOver180 ), -dz );
    while ( a <= 78 )
      {
	xp = Math.cos( a * piOver180 );
	yp = Math.sin( a * piOver180 );
	Vertex3( xp, yp, -dz );
	a += 3.0;
      }
    End();
    
    Begin( jgl.LINE );
    Vertex3( Math.cos( 78.0*piOver180 ), Math.sin( 78.0*piOver180 ), -dz );
    Vertex3( Math.cos( 90.0*piOver180 ), Math.sin( 90.0*piOver180 ), 0.0 );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 90.0*piOver180 ), Math.sin( 90.0*piOver180 ), 0.0 );
    Vertex3( Math.cos( 102.0*piOver180 ), Math.sin( 102.0*piOver180 ), dz );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 78.0*piOver180 ), Math.sin( 78.0*piOver180 ), dz );
    Vertex3( Math.cos( 90.0*piOver180 ), Math.sin( 90.0*piOver180 ), 0.0 );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 90.0*piOver180 ), Math.sin( 90.0*piOver180 ), 0.0 );
    Vertex3( Math.cos( 102.0*piOver180 ), Math.sin( 102.0*piOver180 ), -dz );
    End();

    a = 105.0;
    Begin( jgl.LINE );
    Vertex3( Math.cos( 102.0*piOver180 ), Math.sin( 102.0*piOver180 ), -dz );
    while ( a <= 168 )
      {
	xp = Math.cos( a * piOver180 );
	yp = Math.sin( a * piOver180 );
	Vertex3( xp, yp, -dz );
	a += 3.0;
      }
    End();

    a = 15.0;
    Begin( jgl.LINE );
    Vertex3( Math.cos( 12.0*piOver180 ), Math.sin( 12.0*piOver180 ), dz );
    while ( a <= 78 )
      {
	xp = Math.cos( a * piOver180 );
	yp = Math.sin( a * piOver180 );
	Vertex3( xp, yp, dz );
	a += 3.0;
      }
    End();

    a = 105.0;
    Begin( jgl.LINE );
    Vertex3( Math.cos( 102.0*piOver180 ), Math.sin( 102.0*piOver180 ), dz );
    while ( a <= 168 )
      {
	xp = Math.cos( a * piOver180 );
	yp = Math.sin( a * piOver180 );
	Vertex3( xp, yp, dz );
	a += 3.0;
      }
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 168.0*piOver180 ), Math.sin( 168.0*piOver180 ), -dz );
    Vertex3( Math.cos( Math.PI ), Math.sin( Math.PI ), 0.0 );
    End();
  
    Begin( jgl.LINE );
    Vertex3( Math.cos( Math.PI ) , Math.sin( Math.PI ), 0.0 );
    Vertex3( Math.cos( 192.0*piOver180 ), Math.sin( 192.0*piOver180 ), dz );
    End();

    Begin( jgl.LINE );
    Vertex3( Math.cos( 168.0*piOver180 ), Math.sin( 168.0*piOver180 ), dz );
    Vertex3( Math.cos( Math.PI ), Math.sin( Math.PI ), 0.0 );
    End();
  
    Begin( jgl.LINE );
    Vertex3( Math.cos( Math.PI ) , Math.sin( Math.PI ), 0.0 );
    Vertex3( Math.cos( 192.0*piOver180 ), Math.sin( 192.0*piOver180 ), dz );
    End();
  }

 private void drawCircle( int segments ) throws JGLexception
  {
    double piOver180 = Math.PI / 180.0;
    double dTheta = ( 360 / segments ) * piOver180;
    double a = 0;
    double x = 1.0, y = 1.0, xp = 0, yp = 0;
    double c = Math.cos( dTheta );
    double s = Math.sin( dTheta );
    
    Color3( 1.0F, 1.0F, 1.0F );
    Begin( jgl.LINE );
   
    while ( a <= 360 )
      {
	xp = x * c + y * s;
	yp = x * -s + y * c;
	Vertex3( xp, yp, 0 );
	x = xp;
	y = yp;
	a += dTheta;
      }
    End();
  }

  private void enabler() throws JGLexception
  {
    Enable( jgl.DEPTH_TEST );
    Enable( jgl.LIGHTING );
    Enable( jgl.CULL_FACE );
    Enable( jgl.NORMALIZE );
    EnableLight( 0 );
    EnableLight( 1 );

    // Here's our lighting model
    Light( 1, jgl.AMBIENT, spot_ambient );
    Light( 1, jgl.DIFFUSE, spot_color );
    Light( 1, jgl.SPOT_DIRECTION, spot_dir );
    Light( 1, jgl.POSITION, spot_pos ); 
    Light( 1, jgl.SPOT_CUTOFF, 180.0 );
  }
}
    
