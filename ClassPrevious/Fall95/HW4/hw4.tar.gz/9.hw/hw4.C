// ------------------------------------------------------
// Nils Lohner
// Visualization Homework #4
// ------------------------------------------------------
#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>


void main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderWindowInteractor *iren;
  vtkRenderer *aren;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mcubes;
  vtkPolyMapper *mapper, *omapper;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1, *actor2;
  short val;
  vtkOutlineFilter *outline;


	// create rendering objects that we need
  renWin  = rm.MakeRenderWindow();
  iren    = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  // define geometry of volume
  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(27, 64, 64);
    volume->SetOrigin(0.0, 0.0, 0.0);
    volume->SetAspectRatio(1,1,1);

  cout << "Defined Geometry..." << endl;

  //  Read the data object.
  ifstream inf("MRIdata.bin");

  scalars = new vtkShortScalars(27*64*64);
  for (int i=0;i<27*64*64;i++) {
    inf.read((char *)&val,sizeof(short));
    scalars->SetScalar(i, val);
  }
  volume->GetPointData()->SetScalars(scalars);
  cout << "Read data..." << endl;

	// make the data into marching cubes
  mcubes = new vtkMarchingCubes;
    mcubes->DebugOn();
    mcubes->SetInput(volume);
    mcubes->SetValue(0,255.0);

	// setup the poly mapper with the mcubes output
  mapper = new vtkPolyMapper;
    mapper->SetInput(mcubes->GetOutput());

	// this mapper now has to become an actor
  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(0.8,1.0,0.9);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);
  renWin->Render();

  // interact with data
  iren->Start();
}
