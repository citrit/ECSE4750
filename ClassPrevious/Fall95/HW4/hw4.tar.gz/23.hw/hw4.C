#include <sys/file.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <stdio.h>
#include "vtk.hh"

main ()
{
  /* create an OpenGL-based window */
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *renderer;
  vtkActor *volActor;
  vtkStructuredPoints *vol;
  vtkShortScalars *scalars;
  vtkMarchingCubes *contour;
  vtkPolyMapper *volMapper;
  vtkRenderWindowInteractor *iren;
  int i, j, k, kOffset, jOffset, offset, fd;
  short int in_data;
  float x, y, z, s, ar;
  
  /* Create a device-independent window */
  renWin = rm.MakeRenderWindow();

  /* create user interface */
  iren = renWin->MakeRenderWindowInteractor(); 
  /* create the rendering engine */
  renderer = renWin->MakeRenderer();	

  /* create a structured points object with dimensions 27x64x64 */
  vol = new vtkStructuredPoints;
      vol->SetDimensions(27,64,64);
      vol->SetOrigin(-0.25,-0.5,-0.5);
      ar = 1.0/64.0;
      vol->SetAspectRatio(ar, ar, ar);

  /* open up the data file for binary input */
  fd = open("MRIdata.bin",O_RDONLY);

  /* create a scalar object to hold all of the MRI data and read the data in*/
  scalars = new vtkShortScalars(64*64*27);
  for (offset=0; offset<64*64*27; offset++)
    {
	/* read in 2 bytes of data at a time for a short integer */
	read(fd,&in_data,2);
        scalars->InsertScalar(offset,in_data);
    }

  close(fd);

  /* assign the data just read in to the structured grid */
  vol->GetPointData()->SetScalars(scalars);
  scalars->Delete();

  /* create the contour using Marching Cubes based on the structured grid */
  contour = new vtkMarchingCubes;
      contour->SetInput(vol);
      contour->SetValue(0,225);

  /* create the set of graphics primitives for the contour */
  volMapper = new vtkPolyMapper;
      volMapper->SetInput(contour->GetOutput());
      volMapper->ScalarsVisibleOff();

  /* create the actual image in space somewhere */
  volActor = new vtkActor;
      volActor->SetMapper(volMapper);

  /* add the image of the contour to the list of the renderer's actors */
  renderer->AddActors(volActor);
      renderer->SetBackground(1,1,1);
  renWin->SetSize(450,450);

  // interact with data
  renWin->Render();
  iren->Start();
}
