
#include <unistd.h>
#include <stdio.h>
#include <sys/file.h>
#include <fcntl.h>
#include "vtk.hh"

void main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *renderer;
  vtkActor *volActor;
  vtkStructuredPoints *vol;
  vtkShortScalars *scalars;
  vtkMarchingCubes *contour;
  vtkPolyMapper *volMapper;
  vtkRenderWindowInteractor *iren;
  int i, j, k, kOffset, jOffset, offset;
  float min, max, ar;
  short s;
  
  renWin = rm.MakeRenderWindow();

  iren = renWin->MakeRenderWindowInteractor();
  renderer = renWin->MakeRenderer();

  vol = new vtkStructuredPoints;
      vol->SetDimensions(27,64,64);
      vol->SetOrigin(-0.5,-0.5,-0.5);
      vol->DebugOn();

  //  Get the problem size.
  int fd = open("MRIdata.bin", O_RDONLY, 0600);
  if (fd < 0) { //no data file
    cout << "Could not open data file MRIdata.bin" << endl;
    exit(1);
  }

  scalars = new vtkShortScalars(64*64*27);
  for (k=0; k<27; k++)
    {
    kOffset = k * 64 * 64;
    for (j=0; j<64; j++) 
      {
      jOffset = j * 64;
      for (i=0; i<64; i++) 
        {
        read(fd, &s, sizeof(short));
        offset = i + jOffset + kOffset;
        scalars->InsertScalar(offset,s);
        }
      }
    }

  vol->GetPointData()->SetScalars(scalars);
  scalars->Delete();

  contour = new vtkMarchingCubes;
      contour->SetInput(vol);
      contour->SetValue(0, 225.0);
      contour->DebugOn();

  volMapper = new vtkPolyMapper;
      volMapper->SetInput(contour->GetOutput());
      volMapper->ScalarsVisibleOff();
      volMapper->DebugOn();

  volActor = new vtkActor;
      volActor->SetMapper(volMapper);
      volActor->DebugOn();

  renderer->AddActors(volActor);
      renderer->SetBackground(1,1,1);
  renWin->SetSize(750,750);

  // interact with data
  renWin->Render();
  iren->Start();
}
























































