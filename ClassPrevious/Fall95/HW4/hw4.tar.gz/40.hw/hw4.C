
// Graphics and Visualization Homework 4: submitted by Jingwei Li

#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>

#define SIZE 27*64*64

void main ()
{
  vtkRenderMaster renMaster;  		// required RenderMaster
  vtkRenderWindow *renWin;		// a RenderWindow to draw in 
  vtkRenderer *ren;	       		// a Renderer to do the drawing
  vtkActor *actor;			// an Actor to be drawn
  vtkPolyMapper *iso_mapper;
  vtkMarchingCubes *marchCube;		// a MarchingCube to draw iso-surface
  vtkRenderWindowInteractor *iren;	// interactor
  vtkStructuredPoints *points;
  vtkShortScalars *scalars;		// short scalars
  short value;				// values in file are shorts
  
  renWin = renMaster.MakeRenderWindow();
  ren = renWin->MakeRenderer();
  iren = renWin->MakeRenderWindowInteractor();

  // define topology and geometry of the dataset
  points = new vtkStructuredPoints;
  points->SetDimensions(27, 64, 64);
  points->SetOrigin(-0.5, -0.5, -0.5);
  points->SetAspectRatio(1,1,1);

  // read in data from file
  scalars = new vtkShortScalars(SIZE);
  ifstream datafile("MRIdata.bin");
  for (int i=0;i<SIZE;i++)
    {
      datafile.read((char *)&value, sizeof(short));
      scalars->SetScalar(i, value);
    }
  points->GetPointData()->SetScalars(scalars);
  // scalars->Delete();

  marchCube = new vtkMarchingCubes;
  marchCube->SetInput(points);
  marchCube->SetValue(0, 225.0);

  iso_mapper = new vtkPolyMapper;
  iso_mapper->SetInput(marchCube->GetOutput());
  iso_mapper->ScalarsVisibleOff();

  // define an actor
  actor = new vtkActor;
  actor->SetMapper(iso_mapper);
  // actor->GetProperty()->SetColor(1.0,1.0,1.0);

  // assign the actor to the renderer
  ren->AddActors(actor);	
  ren->SetBackground(0.0,0.0,0.0);
  renWin->AddRenderers(ren);
  renWin->SetSize(300, 300);

  // draw the resulting scene
  renWin->Render();

  // begin mouse and keyboard interaction
  iren->Start();
}


