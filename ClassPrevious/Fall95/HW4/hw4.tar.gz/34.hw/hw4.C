#include "vtkRenderMaster.hh"
#include "vtkMarchingCubes.hh"
#include "vtkPolyMapper.hh"
#include "vtkShortScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>
#include <stdlib.h>

#define CONTOUR_VALUE 225.0

main ()
{

  //first we set up all of the vtk actors and whatnot:

  vtkRenderMaster rm;
  //controlling the window manager...
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkShortScalars *scalars;
  vtkStructuredPoints *volume;
  vtkMarchingCubes *cf;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  vtkActor    *actor1, *actor2;

  short my_array[64*64*27]; //this is what we will load the data into...

  FILE* in_file; //file to read stuff in with.
  
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();
  //open a render window to give user something to look at.

  volume = new vtkStructuredPoints; //set him up...
  volume->SetDimensions(27, 64, 64);
  volume->SetOrigin(0.0, 0.0, 0.0);
  volume->SetAspectRatio(1,1.5,1);

  in_file=fopen("/home/62/citrit/public/VisClass/C++/hw4/MRIdata.bin", "r"); //open up the unsuspecting file..../home/62/citrit/public/VisClass/C++/hw4

  if (in_file==NULL) //note: NULL and 0 not the same thing! 
    {
      cout << "Could not find file MRIdata.bin\n";
      exit(1);
    }
  //read in the file....
  fread(my_array, sizeof(short), 64*64*27, in_file);

  scalars = new vtkShortScalars(64*64*27);
   for (int i=0;i<64*64*27;i++) {
    scalars->SetScalar(i, my_array[i]);
  }
  

  //now set up all the vtk objects for output...
  volume->GetPointData()->SetScalars(scalars); //set up all the point data

  //Basically we take all sorts of guys and send messages back 
  //and forth to make a mounding box and a head appear in 
  //the middle of the screen

  cf = new vtkMarchingCubes; //we need a marching cubes function...
  cf->SetInput(volume);
  cf->SetValue(0, CONTOUR_VALUE);
  
  mapper = new vtkPolyMapper;
  mapper->SetInput(cf->GetOutput());
    
  outline = new vtkOutlineFilter;
  outline->SetInput(volume);

  omapper = new vtkPolyMapper;
  omapper->SetInput(outline->GetOutput());


  actor1 = new vtkActor;
  actor1->SetMapper(mapper);
  actor1->GetProperty()->SetColor(1.0,0.5,0.9); //me an my head


  actor2 = new vtkActor;
  actor2->SetMapper(omapper);
  actor2->GetProperty()->SetColor(1,1,1); //big white box

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);

  renWin->Render(); 

  // start up the engines!
  iren->Start();

  return 0;
}
