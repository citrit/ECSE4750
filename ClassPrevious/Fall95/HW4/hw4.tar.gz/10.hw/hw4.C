//////////////////////////////////////////////////////////////////////////
//	Varina Hammond
//	AGDV Homework #4
//	
//	Reads in a binary file, performs marching cubes and finds
//	an isosurface which is renders.
//
//	To compile (on aix):	make
//	To run:			/tmp/hw4
//////////////////////////////////////////////////////////////////////////

//#include "/locker/44/000644/vtk1.0/include/vtk.hh"
#include "/locker/44/000644/vtk1.0/include/vtkRenderMaster.hh"
#include "/locker/44/000644/vtk1.0/include/vtkPolyMapper.hh"
#include "/locker/44/000644/vtk1.0/include/vtkMarchingCubes.hh"
#include "/locker/44/000644/vtk1.0/include/vtkScalars.hh"
#include "/locker/44/000644/vtk1.0/include/vtkShortScalars.hh"
#include "/locker/44/000644/vtk1.0/include/vtkRenderWindowInteractor.hh"
#include <iostream.h>
#include <fstream.h>

void main (){
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *renderer;
  vtkLight *light;
  vtkActor *actor;
  vtkPolyMapper *mapper;
  vtkRenderWindowInteractor *iren;
  vtkStructuredPoints *data;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mcubes;
  short val;

  ifstream inp("MRIdata.bin");

  renWin = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  renderer = renWin->MakeRenderer();

  data=new vtkStructuredPoints;
  data->DebugOn();
  data->SetDimensions(27,64,64);
  data->SetOrigin(0.0,0.0,0.0);
  data->SetAspectRatio(1,1,1);

  scalars=new vtkShortScalars(27*64*64);
  for(int i=(64*64*27)-1;i>=0;i--){
    inp.read((char *)&val, sizeof(short));
    scalars->SetScalar(i, val);
  }
  cout<<"Done with MRIdata.bin"<<endl;

  data->GetPointData()->SetScalars(scalars);

  mcubes=new vtkMarchingCubes;
  mcubes->DebugOn();
  mcubes->SetInput(data);
  mcubes->SetValue(0,225.0);

  mapper=new vtkPolyMapper;
  mapper->DebugOn();
  mapper->SetInput(mcubes->GetOutput());
  mapper->ScalarsVisibleOff();

  actor=new vtkActor;
  actor->SetMapper(mapper);
  actor->GetProperty()->SetColor(1.0,1.0,1.0);

  light=new vtkLight;

  renWin->AddRenderers(renderer);
  renWin->SetSize(300,300);
  renderer->AddLights(light);
  renderer->AddActors(actor);
  renderer->SetBackground(0.0,0.0,0.0);
  renWin->Render();
  iren->Start();
}
