#include <iostream.h>
#include <fstream.h>

#include "vtkScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkRenderMaster.hh"
#include "vtkContourFilter.hh"
#include "vtkPolyMapper.hh"
#include "vtkStructuredPointsReader.hh"
#include "vtkMarchingCubes.hh"

//Don't need these
/*
#include "PtCell.H"
#include "LineCell.H"
#include "PlyGCell.H"
#include "PlyLCell.H"
#include "TriCell.H"
#include "CellSet.H"
#include "OGLRen.H"
#include "SGrid.H"
*/


main()
{
// Ported over from TCL
vtkRenderMaster rm;
vtkRenderWindow *rw=rm.MakeRenderWindow();
vtkRenderWindowInteractor *INTER=rw->MakeRenderWindowInteractor();
vtkRenderer *REN=rw->MakeRenderer();
vtkCamera *CAM;
//vtkStructuredPoints *shape;
vtkFloatScalars *FC;

// This is a reader for the VTK file because I was having problems
// with the BIN reader.  I had it working and then I tried to 
// "impove" it.  Well, it died so I'm left with reading the VTK file.
//  Here's what's left of the BIN reader:


/******
float Values;

//This is the call to read in the BIN data
ifstream inf("MRIdata.bin");
//shape = new vtkStructuredPointsReader;
//vtkStructuredPointsReader *shape=new vtkStructuredPointsReader;
  shape->SetDimensions(60, 60, 25);
  shape->SetOrigin(0.0, 0.0, 0.0);

FC = new vtkFloatScalars(60*60);
  for (int i=0;i<60*60*25;i++) 
    {
    FC->SetScalar(i, Values);
    }
  shape->GetPointData()->SetScalars(FC);
***************/



// Most of this is directly ported from the TCL....

vtkStructuredPointsReader *shape=new vtkStructuredPointsReader;
  shape->SetFilename("MRIdata.vtk");

vtkMarchingCubes *SURF=new vtkMarchingCubes;
  SURF->SetInput(shape->GetOutput());
  SURF->SetValue(0,255);

vtkPolyMapper *MAP=new vtkPolyMapper;
  MAP->SetInput(SURF->GetOutput());
  MAP->ScalarsVisibleOff();

vtkActor *ACTOR=new vtkActor;
  ACTOR-> SetMapper( MAP);
  ACTOR->GetProperty()->SetColor(1,.5,1);

//  This gives us the bouding box...

vtkOutlineFilter *LINE=new vtkOutlineFilter;
  LINE->SetInput(shape->GetOutput());

vtkPolyMapper *LINEMAP=new vtkPolyMapper;
  LINEMAP->SetInput(LINE->GetOutput());

vtkActor *LINEACT=new vtkActor;
  LINEACT-> SetMapper( LINEMAP);
  LINEACT-> GetProperty()->SetColor(1.0,1.0,0.0);

REN->AddActors(LINEACT);
REN->AddActors(ACTOR);

/*
CAM->SetPosition( 150.0, 90.0, -100.0);
CAM->CalcViewPlaneNormal();
CAM->SetViewUp( -0.25, 0.95, 0.25);
REN->SetActiveCamera(CAM);
*/

REN->AddLights(new vtkLight);
REN->SetBackground(0.0,0.0,0.0);

rw->Render();
INTER->Start();
return 0;
}
