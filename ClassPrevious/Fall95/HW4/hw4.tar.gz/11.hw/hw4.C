// Ron Nemeth
// HW4
// November 19, 1995

#include "vtk.hh"
#include <stdio.h>
#include <iostream.h>

main ()
{
  vtkRenderMaster renMaster;
  vtkRenderWindow *renWindow;
  vtkRenderer *ren;
  vtkRenderWindowInteractor *iren;
  vtkShortScalars *scalars;
  vtkStructuredPoints *volume;
  vtkActor *actor;
  vtkMarchingCubes *mCube;
  vtkPolyMapper *mapper;
  FILE *inf;
  int numRead, i;
  short *s;
  int sliceSize, resolution, numPts, numSlices;

  // create a rendering window and renderer
  renWindow = renMaster.MakeRenderWindow();
  ren = renWindow->MakeRenderer();
  iren = renWindow->MakeRenderWindowInteractor();

  // Make a scalar object to store data
  // allocate memory for the slices
  numSlices = 27;
  resolution = 64;
  sliceSize = resolution * resolution;
  numPts = numSlices * sliceSize;
  scalars = new vtkShortScalars(numPts);

  // Read in Binary data and put it somewhere
  if ((inf = fopen("MRIdata.bin", "r")) == NULL) return NULL;  // Open

  // S gets a pointer to a short at the start of the data
  // If this doesn't work, try using ->InsertScalar
  s = scalars->WritePtr(0,numPts);

  numRead = fread(s, sizeof(short) , numPts, inf);
  fclose(inf);

  scalars->WrotePtr();
  scalars->ComputeRange();
  flush(cout);

  // Set Topology of scalars in Structured Points
  volume = new vtkStructuredPoints;
  volume->GetPointData()->SetScalars(scalars);
  volume->SetDimensions(numSlices, resolution, resolution);
  //volume->SetOrigin(0.0, 0.0 ,0.0);
  //volume->SetAspectRatio(1.0, 1.0, 1.0);

  // Filter volume with MarchingCubes
  mCube = new vtkMarchingCubes;
  mCube->SetInput(volume);
  mCube->SetValue(0,225.0);	// Use Tom's suggested init value
  mCube->DebugOn();

  // create mapper
  mapper = new vtkPolyMapper;
  mapper->SetInput(mCube->GetOutput());
  mapper->ScalarsVisibleOff();
  mapper->DebugOn();

  // create actor
  actor = new vtkActor;
  actor->SetMapper(mapper);
  actor->GetProperty()->SetColor(1.0,1.0,1.0);

  ren->AddActors(actor);
  // ren->SetBackground(1,1,1);
  
  // interact with data
cout << "Open Render Window\n";
flush(cout);
  renWindow->SetSize(400,400);
  renWindow->Render();
  iren->Start();
}
