#include "vtk.hh"



#include <fstream.h>

main ()
{
  vtkRenderMaster rm;
  vtkIndent in;
  vtkRenderWindow *renWin;
  vtkRenderer *renderer;
  vtkActor *volActor;
  vtkStructuredPoints *vol;
  vtkShortScalars *scalars;
    vtkContourFilter *contour;
  vtkMarchingCubes *cubes;
  vtkPolyMapper *volMapper;
  vtkRenderWindowInteractor *iren;
  int slice,row,col, kOffset, jOffset, offset;
  float x, y, z, ar;
  short s;

  
  ifstream inFile("./MRIdata.bin");
  renWin = rm.MakeRenderWindow();

  iren = renWin->MakeRenderWindowInteractor();
  renderer = renWin->MakeRenderer();

  vol = new vtkStructuredPoints;
      vol->SetDimensions(27,64,64);
      ar = 1.0/64;
      vol->SetOrigin(-13.5*ar,-32*ar,-32*ar); 
     vol->SetAspectRatio(ar,ar,ar);

  scalars = new vtkShortScalars(64*64*27);
  for (slice=0; slice < 64*64*27; slice++)  
    {
    inFile.read((char *)&s,sizeof(short));
    scalars->InsertScalar(slice,s);
    }

  vol->GetPointData()->SetScalars(scalars);
  scalars->Delete();
//  vol->PrintSelf(cout,in);

  cubes = new vtkMarchingCubes;
    cubes->SetInput(vol);
    cubes->SetValue(0,225.0);

vtkCleanPolyData *cleaner = new vtkCleanPolyData;
  cleaner->SetTolerance(0.0);
  cleaner->SetInput(cubes->GetOutput());
  volMapper = new vtkPolyMapper;

//vtkDecimate *decimated = new vtkDecimate;
//  decimated->SetInput(cleaner->GetOutput());

vtkStripper *stripper = new vtkStripper;
  stripper->SetInput(cleaner->GetOutput());
//stripper->SetInput(decimated->GetOutput());
  volMapper = new vtkPolyMapper;

      volMapper->SetInput(stripper->GetOutput());
      volMapper->ScalarsVisibleOff();


vtkProperty *flesh = new vtkProperty;
   flesh->SetDiffuseColor(1.0, .49,.25);
   flesh->SetSpecular(.3);
   flesh->SetSpecularPower(20);

  volActor = new vtkActor;
      volActor->SetMapper(volMapper);
      volActor->SetProperty(flesh);  

vtkOutlineFilter *outlineData = new vtkOutlineFilter;
   outlineData->SetInput(vol);
vtkPolyMapper *outMapper = new vtkPolyMapper;
   outMapper->SetInput(outlineData->GetOutput());
vtkActor *outline = new vtkActor;
   outline->SetMapper(outMapper);
   outline->GetProperty()->SetColor(0,0,0);


vtkCamera *aCamera = new vtkCamera;

//  aCamera->SetDistance(3);
//  aCamera->SetViewUp(0,-1,0);
//  aCamera->SetPosition(0,0,-3);
//  aCamera->SetViewPlaneNormal (0, 0, -1);
 
  aCamera->SetDistance(3);
  aCamera->SetViewUp( 0.16667, -0.951663, 0.257991);
  aCamera->SetPosition( -1.36286, -0.919021, -2.50959);
  aCamera->SetViewPlaneNormal( -0.454287, -0.30634, -0.836528);

 aCamera->SetFocalPoint(0,0,0);
 
//  aCamera->DebugOn(),

  renderer->AddActors(volActor);
  renderer->AddActors(outline);
      renderer->SetActiveCamera(aCamera);
      renderer->SetBackground(0.8,0.8,0.8);
//      renderer->DebugOn();

  renWin->SetSize(450,450);

  // interact with data
  renWin->Render();
  iren->Start();
  return(0);
}







