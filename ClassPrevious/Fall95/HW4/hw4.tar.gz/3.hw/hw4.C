//#include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkPolyMapper.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkMarchingCubes.hh"
#include "vtkShortScalars.hh"
#include "vtkStructuredPoints.hh"
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>

main()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renwin;
  vtkRenderer *aren;
  vtkRenderWindowInteractor *iren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1;
  vtkPolyMapper *mapper;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *iso;
  short *s;
  int num_points;
  FILE *mri_file;
 
  // Make the renderer stuff
  renwin  = rm.MakeRenderWindow();
  iren    = renwin->MakeRenderWindowInteractor();
  aren    = renwin->MakeRenderer();
 
 
  // Get the  data
  num_points = 64 * 64 * 27;
  scalars = new vtkShortScalars(num_points);
  s = scalars->WritePtr(0,num_points);
  mri_file = fopen("MRIdata.bin","r");
  fread((char *)s, sizeof(short), num_points, mri_file);
  scalars->WrotePtr();

  volume = new vtkStructuredPoints;
  volume->GetPointData()->SetScalars(scalars);
  volume->SetDimensions(27,64,64);
  volume->SetOrigin(0,0,0);
//  volume->SetAspectRatio((1.0/27),(1.0/64),(1.0/64));
  volume->SetAspectRatio(1.5,1,1);

  iso = new vtkMarchingCubes;
  iso->SetValue(0,225.0);
  iso->SetInput(volume);

  mapper = new vtkPolyMapper;
  mapper->SetInput(iso->GetOutput());
 
  actor1 = new vtkActor;
  actor1->SetMapper(mapper);
  actor1->GetProperty()->SetColor(1.0,0.0,1.0);
 
  light1 = new vtkLight;
  camera1 = new vtkCamera;
 
  renwin->AddRenderers(aren);
//  aren->SetActiveCamera(camera1);
//  aren->AddLights(light1);
  aren->AddActors(actor1);
  aren->SetBackground(0,0,0);
 
//  camera1->SetPosition(2,2.2,1);
//  camera1->SetFocalPoint(0,0,0);
//  camera1->CalcViewPlaneNormal();
 
  /* make the light follow the camera */
//  light1->SetPosition(camera1->GetPosition());
//  light1->SetFocalPoint(camera1->GetFocalPoint());
 
  renwin->Render();
  iren->Start();
}


