/*
 *
 *  hw4.C by Joseph Stayman
 *           for Adv. Comp. Graphics and Data Visualization
 *           Instructor Thomas Citriniti 
 *
*/

#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>


void main()
{
	vtkRenderMaster master;
	vtkRenderWindow *window;
	vtkRenderer *ren;
	vtkRenderWindowInteractor *interactor;
	vtkActor head;
	vtkStructuredPoints grid;
	vtkPolyMapper mapper;
	vtkMarchingCubes surface;
	vtkShortScalars *data;
	ifstream file;
	int i,j,k;
	short point;

	file.open("MRIdata.bin", ios::in);

	window=master.MakeRenderWindow();
	interactor=window->MakeRenderWindowInteractor();
	ren=window->MakeRenderer();

	grid.SetDimensions(27,64,64);
	data=new vtkShortScalars(27*64*64);

	for (k=0;k<64;k++)  
		for (j=0;j<64;j++)  
			for (i=0;i<27;i++) {
				file.read( (char *) &point, sizeof(point));
				data->InsertNextScalar(point);
			}

	grid.GetPointData()->SetScalars(data);

	surface.SetInput(&grid);
	surface.SetValue(0,225);

	mapper.SetInput(surface.GetOutput());
	mapper.SetScalarsVisible(0);
	head.SetMapper(&mapper);
	head.GetProperty()->SetColor(0,0,1);

	ren->AddActors(&head);
	ren->SetBackground(0,0,0);

	window->Render();
	interactor->Start();
}
