#include "vtk.hh"
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>
#include "vtkRenderMaster.hh"
#include "vtkMarchingCubes.hh"
#include "vtkPolyMapper.hh"
#include "vtkScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"

FILE  *input_file;
short scalar_value[27*64*64];
int   dimx, dimy, dimz;
int   scalar_count;          //Should be 64*64*27 actaully

main ()
{
  vtkRenderMaster           rm;
  vtkRenderWindow           *renWin;
  vtkRenderer               *aren;
  vtkCamera                 *camera1;
  vtkLight                  *light1;
  vtkActor                  *actor1, *actor2;
  vtkStructuredPoints       *volume;
  vtkShortScalars           *scalars;
  vtkMarchingCubes          *cf;
  vtkPolyMapper             *mapper, *omapper;
  vtkOutlineFilter          *outline;
  vtkRenderWindowInteractor *iren;
  vtkCleanPolyData          *cleaner; 
  
  FILE  *input_file;
  short scalar_value[27*64*64];
  int   dimx, dimy, dimz;
  int   scalar_count;          //Should be 64*64*27 actaully

  dimx = 27;
  dimy = 64;
  dimz = 64;
    
  renWin  = rm.MakeRenderWindow();
  iren    = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  // define geometry of volume
    volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(dimx, dimy, dimz);
    volume->SetOrigin(0, 0, 0);
    volume->SetAspectRatio(1.0, 1.0, 1.0);

  // define scalar values to contour
     scalars = new vtkShortScalars(dimx*dimy*dimz);
     input_file = fopen("MRIdata.bin","r");
     scalar_count = fread(scalar_value, sizeof(short), dimx*dimy*dimz,
                         input_file);
    for (int i = 0; i<dimx*dimy*dimz; i++) {
    scalars->SetScalar(i,scalar_value[i]);
 //   cout<<"the scalar value is "<<i<< " "<<scalar_value[i]<<endl;
    }
  volume->GetPointData()->SetScalars(scalars);

  cf = new vtkMarchingCubes;
    cf->DebugOn();
    cf->SetInput(volume);
    cf->SetValue(0, 225.0);
 
  mapper = new vtkPolyMapper;
    mapper->SetInput(cf->GetOutput());

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(1.0,1.0,1.0);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);

  cleaner = new vtkCleanPolyData;
    cleaner->SetTolerance(0.0);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.2,0.2,0.2);
  
  renWin->Render();

  // interact with data
  iren->Start();
}


