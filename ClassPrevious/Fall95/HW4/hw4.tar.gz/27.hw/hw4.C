#include "vtkRenderWindowInteractor.hh"
#include "vtkRenderWindow.hh"
#include "vtkRenderMaster.hh"
#include "vtkRenderer.hh"
#include "vtkLODActor.hh"
#include "vtkPolyMapper.hh"
#include "vtkCamera.hh"
#include "vtkStructuredPoints.hh"
#include "vtkShortScalars.hh"
#include "vtkMarchingCubes.hh"
#include "vtkCleanPolyData.hh"
#include "vtkDecimate.hh"
#include "vtkOutlineFilter.hh"
#include <fstream.h>
#include <iostream.h>

main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *renderer;
  vtkLODActor *actor1;
  vtkActor *actor2;
  vtkPolyMapper *mapper1, *mapper2;
  vtkRenderWindowInteractor *iren;
  short *s;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *surface;
  vtkCleanPolyData *mergesurface;
  vtkDecimate *decimatesurface;
  vtkOutlineFilter *outline;
  int numPts=64*64*27;
  
  // graphics stuff
  renWin = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  renderer = renWin->MakeRenderer();

  // read data
  ifstream inFile("MRIdata.bin", ios::in);

  scalars = new vtkShortScalars(numPts);
  s = scalars->WritePtr(0,numPts);
  inFile.read((char *)s,numPts*2);
  scalars->WrotePtr();
  inFile.close();

  volume = new vtkStructuredPoints;
  volume->DebugOn();
  volume->GetPointData()->SetScalars(scalars);
  volume->SetDimensions(27,64,64);
  volume->SetOrigin(0.0,0.0,0.0);
  volume->SetAspectRatio(1.0,1.0,1.0);

  surface = new vtkMarchingCubes;
  surface->DebugOn();
  surface->SetInput(volume); 
  surface->SetValue(0,225.0); 

  mergesurface = new vtkCleanPolyData;
  mergesurface->DebugOn();
  mergesurface->SetInput(surface->GetOutput());

  decimatesurface = new vtkDecimate;
  decimatesurface->DebugOn();
  decimatesurface->SetMaximumIterations(3);
  decimatesurface->SetTargetReduction(.70);
  decimatesurface->SetInput(mergesurface->GetOutput());

  outline = new vtkOutlineFilter;
  outline->DebugOn();
  outline->SetInput(decimatesurface->GetOutput());

  // create mapper
  mapper1 = new vtkPolyMapper;
  mapper1->SetInput(decimatesurface->GetOutput());
  mapper1->ScalarsVisibleOff();

  mapper2 = new vtkPolyMapper;
  mapper2->SetInput(outline->GetOutput());

  // create actors
  actor1 = new vtkLODActor;
  actor1->SetMapper(mapper1);
  actor2 = new vtkActor;
  actor2->SetMapper(mapper2);

  //set up renderer
  renderer->AddActors(actor1);
  renderer->AddActors(actor2);
  renderer->SetBackground(0,0,0);

  renWin->SetSize(750,750);

  // interact with data
  iren->Initialize();
  iren->Start();

return(1);
}
