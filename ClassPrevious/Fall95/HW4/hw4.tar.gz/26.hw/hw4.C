//////////////////////////////////////////////////////////////////////////
//
//  This code is for instructional purposes only. It was generated for
//  use in a graduate level course to show certain aspects of data
//  storage algorithms. It has problems and should not be used 
//  outside the class environment.
//
//  Author:  Thomas D. Citriniti     citrit@rpi.edu
//  Class:   Advanced Computer Graphics and Data visualization
//           Rensselaer Polytechnic Institute
//  Date:    October 3, 1995
//
//////////////////////////////////////////////////////////////////////////

// #include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkMarchingCubes.hh"
#include "vtkPolyMapper.hh"
#include "vtkShortScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>

int LoadData(vtkShortScalars *scalars)
{
  short tempArr[64*64*27];
  FILE *fd;
  size_t ret;

  fd=fopen("MRIdata.bin", "r");
  if (fd==NULL)
    {
     printf("Error opening file.\n");
      return(0);
   }
  ret=fread(tempArr, sizeof(short), 64*64*27, fd);
  if (ret!=64*64*27)
    {
     printf("Error reading file.\n");
     return(0);
   }
  for (int i=0;i<64*64*27;i++) 
      scalars->SetScalar(i, (short)tempArr[i]);
  return(1);
}
  
int main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1, *actor2;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mc;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;

  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

 //  Seed the data object.
  scalars = new vtkShortScalars(64*64*27);
  if (!LoadData(scalars))
    {
     printf("Cannot load data file.\n");
     return(1);
   }
 
  // define geometry of volume
  volume = new vtkStructuredPoints;
  volume->SetDimensions(27, 64, 64);
  volume->SetOrigin(0.0, 0.0, 0.0);
  volume->SetAspectRatio(1,1,1);
  volume->GetPointData()->SetScalars(scalars);

  mc = new vtkMarchingCubes;
  mc->SetInput(volume);
  mc->SetValue(0, 225.0);

  mapper = new vtkPolyMapper;
    mapper->SetInput(mc->GetOutput());

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(0.8,1.0,0.9);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);

  renWin->Render();

  // interact with data
  iren->Start();
}
