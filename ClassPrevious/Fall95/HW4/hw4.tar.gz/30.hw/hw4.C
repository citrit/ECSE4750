/*#  Advance Computer Graphics & Data Visulization
#
#		Homework #4
#
#		Jinhua Huang	12-04-95
#

# define the color 
*/

#include <iostream.h>
#include "vtk.hh"
#include "vtkXRenderWindowInteractor.hh"

void main ()
{
// First create the render master
vtkRenderMaster rm;

// Now create the RenderWindow, Renderer and both Actors

vtkRenderWindow *renWin=rm.MakeRenderWindow();
vtkXRenderWindowInteractor *iren=(vtkXRenderWindowInteractor *) \
				 renWin->MakeRenderWindowInteractor();
vtkRenderer *ren1=renWin->MakeRenderer();
vtkLight *lgt=new vtkLight;

// create pipeline

vtkStructuredPointsReader *reader=new vtkStructuredPointsReader;
    reader->SetFilename ("MRIdata.vtk");

vtkMarchingCubes *iso=new vtkMarchingCubes;
    iso->SetInput(reader->GetOutput());
    iso->SetValue(0, 225.0);

vtkCleanPolyData *cleaner=new vtkCleanPolyData;
    cleaner->SetInput(iso->GetOutput());

vtkPolyNormals *norms=new vtkPolyNormals;
    norms->SetInput(cleaner->GetOutput());
    norms->SetFeatureAngle(60.0);
    norms->FlipNormalsOn();

vtkPolyMapper *isoMapper=new vtkPolyMapper;
    isoMapper->SetInput(iso->GetOutput());
    isoMapper->ScalarsVisibleOff();

vtkActor *isoActor=new vtkActor;
    isoActor->SetMapper(isoMapper);
    (isoActor->GetProperty())->SetColor(0.9804, 0.9216, 0.8431);


vtkOutlineFilter *outline=new vtkOutlineFilter;
    outline->SetInput(reader->GetOutput());
vtkPolyMapper *outlineMapper=new vtkPolyMapper;
    outlineMapper->SetInput(outline->GetOutput());
vtkActor *outlineActor=new vtkActor;
    outlineActor->SetMapper(outlineMapper);
    outlineActor->GetProperty();

//set outlineProp [outlineActor GetProperty];

// Add the actors to the renderer, set the background and size
 
ren1->AddActors(outlineActor);
ren1->AddActors(isoActor);
ren1->SetBackground(1, 1, 1);
ren1->AddLights(lgt);
renWin->SetSize( 400, 300);
ren1->SetBackground(0.1, 0.2, 0.4);
renWin->DoubleBufferOff();

vtkCamera *cam1=ren1->GetActiveCamera();
cam1->Elevation( 0);
cam1->SetViewUp(0, -1, 0);
cam1->Zoom(1.3);
cam1->Azimuth(210);

lgt->SetPosition(cam1->GetPosition());
lgt->SetFocalPoint(cam1->GetFocalPoint());

// render the image
 
//iren->SetUserMethod(iren);
iren->Initialize();
iren->Start();

renWin->Render();
}
