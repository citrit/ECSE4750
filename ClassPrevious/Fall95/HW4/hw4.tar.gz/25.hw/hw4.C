//////////////////////////////////////////////////////////////////////////
//
//  hw4a.C
//
//  This code is for instructional purposes only. It was generated for
//  use in a graduate level course to show certain aspects of data
//  storage algorithms. It has problems and should not be used 
//  outside the class environment.
//
//  Author:  Thomas D. Citriniti     citrit@rpi.edu
//  Class:   Advanced Computer Graphics and Data visualization
//           Rensselaer Polytechnic Institute
//  Date:    October 3, 1995
//
//  Modified: Linda Lim  12/02/95
//
//////////////////////////////////////////////////////////////////////////

// #include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkMarchingCubes.hh"
#include "vtkPolyMapper.hh"
#include "vtkScalars.hh"
#include "vtkShortScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>

main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkLight    *light2;
  vtkActor    *actor1, *actor2;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mc;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  int dimx, dimy, dimz;
  float range[2];
  short int val;
  short data_array[110592];
  FILE *ifp;

  ifp = fopen("MRIdata.bin","rb");

  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  //  Get the problem size.

  dimx = 27;
  dimy = 64;
  dimz = 64;

  // define geometry of volume
  volume = new vtkStructuredPoints;
//  volume->DebugOn();
  volume->SetDimensions(dimx, dimy, dimz);
  volume->SetOrigin(0.0, 0.0, 0.0);
  volume->SetAspectRatio(1,1,1);

  fread(data_array,2,110592,ifp);

  //  Seed the data object.
  scalars = new vtkShortScalars(dimx*dimy*dimz);
  for (int i=0;i<dimx*dimy*dimz;i++) {
//    inf >> val;
//    val = (short) (fgetc(ifp));
    val = (short) data_array[i];
    scalars->SetScalar(i, val);
  }


//  cout<<endl<<"i = "<<i<<"; val = "<<val<<endl;
//  printf("i = %d; val = %c\n",i,val);

  volume->GetPointData()->SetScalars(scalars);


  mc = new vtkMarchingCubes;
    mc->DebugOn();
    mc->SetInput(volume);
    mc->SetValue(0, 225.0);

  mapper = new vtkPolyMapper;
    mapper->SetInput(mc->GetOutput());

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(0.8,1.0,0.9);
/*
  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);
*/

  camera1 = new vtkCamera;
//  camera1->SetViewPlaneNormal(0.0,0.0,0.0);
//  camera1->SetViewPlaneNormal(-1.0,0.0,0.0);
  camera1->Elevation(-20.0);

  light1 = new vtkLight;
  light2 = new vtkLight;
  aren->AddLights(light1);
  aren->AddLights(light2);
//  aren->AddActors(actor2);
  aren->AddActors(actor1);

  aren->DoCameras();

  aren->SetBackground(0.0,0.0,0.0);

  renWin->Render();

  // interact with data
  iren->Start();
}
