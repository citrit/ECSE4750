//////////////////////////////////////////////////////////////////////////
//
//  Class:   Advanced Computer Graphics and Data visualization
//           Rensselaer Polytechnic Institute
//
//  Author:  Xiaoyin WANG
//  Date:    Nov 20, 1995
//
//////////////////////////////////////////////////////////////////////////

// #include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkMarchingCubes.hh"
#include "vtkPolyMapper.hh"
#include "vtkShortScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include <stdio.h>
#include <iostream.h>
#include <fstream.h>

void
main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *cf;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  int dimx, dimy;
  short sval;
  float range[2];
  FILE  *fp;
  short *position;
  
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  //  Get the problem size.

  // define geometry of volume
  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(27, 64, 64);
    volume->SetOrigin(0.0, 0.0, 0.0);
    volume->SetAspectRatio(1,1,1);

  if ((fp=fopen("MRIdata.bin","r"))== NULL){
    fprintf(stderr,"Error in Reading!\n");
  }

  //  Seed the data object.
  scalars = new vtkShortScalars(64*64*27);
  position = scalars->WritePtr(0,64*64*27);
  for (int i=64*64*27-1;i>=0 ;i--) {
    fread(&sval,sizeof(short),1,fp);
//	printf("%d ",sval);
   position[i] = sval; 
//    scalars->SetScalar(i, sval);
  }
  scalars->WrotePtr();
  volume->GetPointData()->SetScalars(scalars);

  cf = new vtkMarchingCubes;
//    cf->DebugOn();
    cf->SetInput(volume);
//    range[0] = 225.0;range[1] = 300.0;
//    cf->GenerateValues(2, range);
    cf->SetValue(0, 225.0);

  mapper = new vtkPolyMapper;
    mapper->SetInput(cf->GetOutput());

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(0.8,1.0,0.9);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);

  renWin->Render();

  // interact with data
  iren->Start();
}
