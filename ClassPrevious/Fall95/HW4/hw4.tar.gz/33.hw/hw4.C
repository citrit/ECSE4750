/***************************************************************
*    Duoli Pei                                                 *
*    Homework #4                                               *
*    Advanced Computer Graphics and Data Visualization         *
*    December 5, 1995                                          *
*    vtk code                                                  *
***************************************************************/

#include <stdio.h>
#include "vtk.hh"

main (int argc, char *argv[])
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor, *actorOutline;
  vtkStructuredPoints *volume;
  vtkFloatScalars *scalars;
  vtkContourFilter *cf;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  FILE *fp;
  int k,j,i,kOffset,jOffset,offset;
  short wd[1];
  float s;
  
  if(argc!=2) {
     printf("usage: hw4 MRIdata.bin\n");
     exit(0);
  }

  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  // define geometry of volume
  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(27,64,64);
    volume->SetOrigin(1,1,0.5);
    volume->SetAspectRatio(1,.5,.333333);

  // define scalar values to contour
  scalars = new vtkFloatScalars(27*64*64);
  fp=fopen(argv[1],"rb");  /* open a binary file */
  for (k=0; k<27; k++)
    {
    kOffset = k * 64 * 64;
    for (j=0; j<64; j++)
      {
      jOffset = j * 64;
      for (i=0; i<64; i++)
        {
        offset = i + jOffset + kOffset;
        fread(wd,sizeof(short),1,fp);  /* each time read one data */
        s = wd[0]/64.0;
        scalars->InsertScalar(offset,s);
        }
      }
    }

  volume->GetPointData()->SetScalars(scalars);

  cf = new vtkContourFilter;
    cf->DebugOn();
    cf->SetInput(volume);
    cf->SetValue(0, 1.3);

  mapper = new vtkPolyMapper;
    mapper->SetInput(cf->GetOutput());

  actor = new vtkActor;
    actor->SetMapper(mapper);
    actor->GetProperty()->SetColor(0.9,0.9,0.9);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actorOutline = new vtkActor;
    actorOutline->SetMapper(omapper);
    actorOutline->GetProperty()->SetColor(0.9,0.9,0.9);
  // rotate so face is visible
  actor->RotateX(0.0);
  actor->RotateY(30.0);
  actorOutline->RotateX(0.0);
  actorOutline->RotateY(30.0);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor);
  aren->AddActors(actorOutline);
  aren->SetBackground(0.,0.,0.);

  renWin->SetSize(300,300);
  renWin->Render();

  camera1 = aren->GetActiveCamera();
  light1->SetPosition(camera1->GetPosition());
  light1->SetFocalPoint(camera1->GetFocalPoint());


  // interact with data
  iren->Start();
}
