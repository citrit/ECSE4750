/* #include "vtk.hh" */
#include "vtkRenderMaster.hh"
#include "vtkRenderWindow.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkRenderer.hh"
#include "vtkActor.hh"
#include "vtkMarchingCubes.hh"
#include "vtkStructuredPoints.hh"
#include "vtkShortScalars.hh"
#include "vtkPolyMapper.hh"

void main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkActor *isoSurfaceActor;
  vtkMarchingCubes *mcubes;
  vtkStructuredPoints *spoints;
  vtkShortScalars *sscalars;
  vtkRenderWindowInteractor *iren;
  vtkPolyMapper *pmapper;
  short *s;
  float x[3], n[3];

  renWin = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren = renWin->MakeRenderer();

  // Create short scalars
#define NPTS 64*64*27
  sscalars = new vtkShortScalars(NPTS);
      s = sscalars->WritePtr(0, NPTS);
      cin.read((char *)s, sizeof(short)*NPTS);
      sscalars->WrotePtr();

  // Create structured points
  spoints = new vtkStructuredPoints;
      spoints->SetDimensions(27, 64, 64);
      spoints->SetAspectRatio(1,-1,-1); // Assume data was read correctly, but
					// data was inverted.
      spoints->GetPointData()->SetScalars(sscalars);
      spoints->DebugOn();

  // MarchingCubes
  mcubes = new vtkMarchingCubes;
      mcubes->DebugOn();
      mcubes->SetInput(spoints);
      mcubes->SetValue(0, 225.0);
  
  // PolyMapper
  pmapper = new vtkPolyMapper;
      pmapper->SetInput(mcubes->GetOutput());
      pmapper->ScalarsVisibleOff();
      pmapper->DebugOn();

  // Actor
  isoSurfaceActor = new vtkActor;
      isoSurfaceActor->SetMapper(pmapper);
      isoSurfaceActor->DebugOn();
     
//
// Rendering stuff
//
  aren->SetBackground(1,1,1);
      aren->AddActors(isoSurfaceActor);

  renWin->SetSize(750,750);
  renWin->Render();

  // interact with data
  iren->Start();

}

