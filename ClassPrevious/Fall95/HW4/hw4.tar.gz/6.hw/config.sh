#!/usr/bin/sh

platform=`/usr/bin/uname`

if [ $? -ne 0 ] ; then
  echo "Your platform does not have /usr/bin/uname.  Sorry."
  exit 1
fi

case $platform in
IRIX)
  name=irix
  ;;

AIX)
  name=aix
  ;;

SunOS)
  name=sunos
  ;;

*)
  echo "Your platform isn't supported.  Sorry."
  exit 2
  ;;
esac

echo "Using config-$name.mk for your config."
echo
set -x
rm -f config-.mk
ln -s config-$name.mk config-.mk
set +x
echo
echo "You can type \"make\" to create the executable, or \"make config\""
echo "  to reconfigure."
echo
echo "Hit ^C in the next 3 seconds to interrupt an auto-make."
sleep 3
echo making...
make
