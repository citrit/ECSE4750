#include <stdio.h>		// Sorry -- this is what Tcl uses.
#include "vtkShortScalars.hh"
#include "vtkTclUtil.hh"


/* Utility function used to read binary short scalars from a file into the
 * data pointer of a ShortScalar.
 * Arguments: name_of_short_scalar_obj tcl_file_descriptor n_points
 */
int vtkShortScalarsRawReadCommand(void *unused, Tcl_Interp *interp,
			       int argc, char *argv[])
{
    vtkShortScalars *ptr;
    FILE *fp;
    short *sptr;
    int npts;
    
    if (argc != 4) {
	Tcl_AppendResult(interp, "Error: Arguments should be: ", argv[0],
			 " name_of_short_scalar tcl_file_descriptor n_points",
			 NULL);
	return(TCL_ERROR);
    }

    if (Tcl_GetInt(interp,argv[3], &npts) != TCL_OK || npts < 0) {
	Tcl_AppendResult(interp, "Error: Invalid number of points \"", argv[3],
			 "\".", NULL);
	return(TCL_ERROR);
    }

    if ((ptr = (vtkShortScalars *)
	 vtkTclGetPointerFromObject(argv[1], "vtkShortScalars")) == NULL) {
	Tcl_AppendResult(interp, "Error: ShortScalar object named \"", argv[1],
			 "\" not found.", NULL);
	return(TCL_ERROR);
    }

    if (Tcl_GetOpenFile(interp, argv[2], 0, 1, &fp) != TCL_OK) {
	Tcl_AppendResult(interp, "Could not open file identifier \"",
			 argv[2], "\".", (char *) NULL);
	return(TCL_ERROR);
    }

    sptr = ptr->WritePtr(0, npts);
    fread(sptr, sizeof(short), npts, fp);
    ptr->WrotePtr();
    return(TCL_OK);
}

extern "C" {
    int Shortread_Init(Tcl_Interp *interp) {
	Tcl_CreateCommand(interp, "ssrawread", vtkShortScalarsRawReadCommand,
			  (ClientData) 0, (Tcl_CmdDeleteProc *) NULL);
	return(TCL_OK);
    }
}

