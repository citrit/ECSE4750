/* Eric C. Rouchka                                   */
/* December 5, 1995                                  */
/* Advanced Computer Graphics and Data Visualization */
/* Homework 4                                        */

#include <stdio.h> 
#include "vtkRenderMaster.hh"
#include "vtkRenderWindow.hh"
#include "vtkRenderer.hh"
#include "vtkActor.hh"
#include "vtkPolyMapper.hh"
#include "vtkMarchingCubes.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkStructuredPoints.hh"
#include "vtkShortScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkLight.hh"
#include "vtkCamera.hh"

#define WIDTH 64
#define HEIGHT 64
#define DEPTH 27

main ()
{
   vtkRenderMaster rm;
   vtkRenderWindow *renwin;
   vtkRenderer *aren;
   vtkActor *actor;
   vtkActor *actor2;
   vtkPolyMapper *mapper;
   vtkPolyMapper *omapper;
   vtkOutlineFilter *outline;
   vtkMarchingCubes *contour;
   vtkRenderWindowInteractor *iren;
   vtkStructuredPoints *volume;
   vtkShortScalars *scalars;
   vtkLight *light1;
   vtkCamera *camera1;

   short *s;
   int numPts;
   FILE *fpt;
   short num;
   int i;

   fpt = fopen("/locker/44/000644/VisClass/C++/hw4/MRIdata.bin", "r");
   numPts = WIDTH * HEIGHT * DEPTH;
   actor = new vtkActor;
   scalars = new vtkShortScalars(numPts);
   s = scalars->WritePtr(0, numPts);
   /* Now Read in the data file into s */
   for (i = 0; i < numPts; i++) {           // Read in the data as
      fread(&num, sizeof(short), 1, fpt);   // binary shorts
      s[i] = num;
   }
   scalars->WrotePtr();
   volume = new vtkStructuredPoints;
   volume->DebugOn();
   volume->GetPointData()->SetScalars(scalars);
   volume->SetDimensions(DEPTH, WIDTH, HEIGHT);
   volume->SetOrigin(0.0, 0.0, 0.0);
   volume->SetAspectRatio(1, 1, 1);
   
   renwin = rm.MakeRenderWindow();
   iren = renwin->MakeRenderWindowInteractor();
   aren = renwin->MakeRenderer(); 
   
   contour = new vtkMarchingCubes;
   contour->SetInput(volume);
   contour->SetValue(0, 225.0);
   contour->DebugOn();

   mapper = new vtkPolyMapper;
   mapper->SetInput(contour->GetOutput());      
   mapper->ScalarsVisibleOff();

   actor = new vtkActor;  
   actor->SetMapper(mapper);
   actor->GetProperty()->SetColor(0.9, 0.9, 0.9);

   // Set an outline box
   outline = new vtkOutlineFilter;
   outline->SetInput(volume);
   omapper = new vtkPolyMapper;
   omapper->SetInput(outline->GetOutput());
 
   camera1 = new vtkCamera; 
   actor2 = new vtkActor;
   actor2->SetMapper(omapper);
   actor2->GetProperty()->SetColor(1, 1, 1);

   actor->RotateX(180);   // Rotate so the face is 
   actor2->RotateX(180);  // Visible
   actor->RotateY(30);
   actor2->RotateY(30);

   light1 = new vtkLight;
   aren->AddLights(light1); 
   aren->SetActiveCamera(camera1);
   aren->AddActors(actor);
   aren->AddActors(actor2);
   aren->SetBackground(0, 0, 0);
  
   // Set the Camera Position
   camera1->SetPosition(0, 100, 300);
   camera1->SetFocalPoint(0, 0, 0);
   camera1->CalcViewPlaneNormal();
   camera1->Zoom(2);

   renwin->SetSize(500, 500);
   renwin->Render();
   iren->Start();
   return(0);
}
