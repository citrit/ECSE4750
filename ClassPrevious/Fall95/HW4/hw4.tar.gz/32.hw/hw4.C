#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>

main()
{
  vtkRenderMaster renMaster; // RenderMaster
  vtkRenderWindow *renWindow;  // a Render windeow to draw in
  vtkRenderer *ren; // a Renderer to do the drawing
  vtkActor *myActor; // actor to be drawn
  vtkPolyMapper *myMapper; // mapper for the model
  vtkRenderWindowInteractor *iren; // interactor
  vtkShortScalars *scalarset; // scalar set
  vtkStructuredPoints *structPoint; // structured point
  vtkMarchingCubes *machCube; // maching cube to filter 

  //create vtk display needed objects
  renWindow=renMaster.MakeRenderWindow(); //create window
  ren=renWindow->MakeRenderer(); //create renderer
  iren=renWindow->MakeRenderWindowInteractor(); //create  window interactor
    
  //initialize scalarset
  int total=64*64*27;
  scalarset=new vtkShortScalars(total);

  //open the file and read the scalar into scalar set
  short value;
  ifstream infile("MRIdata.bin");
  for(int i=0;i<total;i++)
    {
      infile.read((char*)&value,sizeof(short));
      scalarset->InsertScalar(i,value);
      scalarset->DebugOn();
    }

  //insert scalar set into structedpoints
  structPoint=new vtkStructuredPoints;
  structPoint->SetOrigin(0.0,0.0,0.0);
  structPoint->SetDimensions(27,64,64);
  structPoint->SetAspectRatio(1,1,1);
  structPoint->DebugOn();
  structPoint->GetPointData()->SetScalars(scalarset);

  //use marching cube to filter
  machCube=new vtkMarchingCubes;
  machCube->DebugOn();
  machCube->SetInput(structPoint);
  machCube->GenerateValues(1,225.0, 225.0);
 
  //create mapper
  myMapper=new vtkPolyMapper;
  myMapper->SetInput(machCube->GetOutput());

  //create actor
  myActor=new vtkActor;
  myActor->SetMapper(myMapper);
  myActor->GetProperty()->SetColor(1.0,1.0,1.0);
  myActor->GetProperty()->SetAmbientColor(1.0,1.0,1.0);
  myActor->GetProperty()->SetDiffuseColor(1.0,1.0,1.0);
  myActor->GetProperty()->SetSpecularColor(1.0,1.0,1.0);
  myActor->GetProperty()->SetAmbient(0.6);
  myActor->GetProperty()->SetDiffuse(0.8);
  myActor->GetProperty()->SetSpecular(0.2);

  vtkLight* light1=new vtkLight;
  //connect them together
  ren->AddLights(light1);
  ren->AddActors(myActor);
  ren->SetBackground(0.0,0.0,0.0);
  renWindow->AddRenderers(ren);

  //start drawing
  renWindow->Render();
  iren->Start();
}
