#include "vtk.hh"
#include <iostream.h>

#define DIMX 27
#define DIMY 64
#define DIMZ 64

int 
main () {
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mc;
  vtkCleanPolyData *cpd;
  vtkDecimate *decimate;
  vtkPolyMapper *mapper;
  vtkRenderWindowInteractor *iren;
  short *val;

  FILE *inf;

  if ((inf = fopen("MRIdata.bin", "rb")) == NULL) {
	cerr << "Could not open MRIdata.bin" <<  endl;
	exit(1);
	}
  
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(DIMX, DIMY, DIMZ);
    volume->SetOrigin(0.0, 0.0, 0.0);
    volume->SetAspectRatio(1,1,1);

  scalars = new vtkShortScalars(DIMX*DIMY*DIMZ);
  val = scalars->WritePtr(0,DIMX*DIMY*DIMZ);
  fread(val, sizeof(short), DIMX*DIMY*DIMZ, inf);
  scalars->WrotePtr();

  volume->GetPointData()->SetScalars(scalars);

  mc = new vtkMarchingCubes;
    mc->DebugOn();
    mc->SetInput(volume);
//    mc->GenerateValues(100, min, max);
    mc->SetValue(0, 225.0);

    cpd = new vtkCleanPolyData;
    cpd->DebugOn();
	cpd->SetInput(mc->GetOutput());

    decimate = new vtkDecimate;
	decimate->SetInput(cpd->GetOutput());
	decimate->SetTargetReduction(0.6);

    mapper = new vtkPolyMapper;
    mapper->SetInput(decimate->GetOutput());
    mapper->ScalarsVisibleOff();

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(1.0,1.0,1.0);
    actor1->SetPosition(120.0, -120.0, 120.0);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);

  renWin->Render();

  // interact with data
  iren->Start();

  return 0;
}
