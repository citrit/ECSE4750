// HW4.C Advanced Computer Graphics
// Guillermo A. Mena

// #include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkContourFilter.hh"
#include "vtkPolyMapper.hh"
#include "vtkShortScalars.hh"
#include "vtkScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkMarchingCubes.hh"
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>
#define xmax 64
#define ymax 64
#define zmax 27


int main (void)
{
 cout << "In Main\n";
 vtkRenderMaster rm;
 vtkRenderWindow *renWin;
 vtkRenderer     *aren;
 vtkCamera       *camera1;
 vtkLight        *light1;
 vtkActor        *actor1, *actor2;
 vtkStructuredPoints *volume;
 vtkShortScalars    *scalars;
 vtkPolyMapper *mapper, *omapper;
 vtkMarchingCubes *mc;
 vtkOutlineFilter *outline;
 vtkRenderWindowInteractor *iren;
 int i;
 short temp_val;
 short  val;
 float range[2];
 renWin = rm.MakeRenderWindow();
 iren = renWin->MakeRenderWindowInteractor();
 aren = renWin->MakeRenderer();
 
  FILE *fin = fopen("MRIdata.bin","r");
  // Seed the data object
 scalars = new vtkShortScalars(xmax*ymax*zmax);
 
 

 for (i = 0;i < xmax*ymax*zmax; i++)  {
  fread((short *)(&temp_val),1,sizeof(short),fin);
    scalars->SetScalar(i,temp_val); 
  }
 
 // define geometry of volume
 volume = new vtkStructuredPoints;
   volume->DebugOn();
   volume->SetDimensions(zmax,ymax,xmax);
   volume->SetOrigin(0.0,0.0,0.0);
   volume->SetAspectRatio(1.5,1.0,1.0);
   range[0]=0.0;
   range[1]=255.0;
 
 volume->GetPointData()->SetScalars(scalars);

 

 // marching cubes isosurface
 mc = new vtkMarchingCubes;
 mc->DebugOn();
 mc->SetInput(volume);   
 mc->SetValue(0,225.0);

 mapper = new vtkPolyMapper;
   mapper->SetInput(mc->GetOutput());
   
 // draw an outline
 outline = new vtkOutlineFilter;
   outline->SetInput(volume);
   
 omapper = new vtkPolyMapper;
   omapper->SetInput(outline->GetOutput());
 
 actor1 = new vtkActor;
   actor1->SetMapper(mapper);
   actor1->GetProperty()->SetColor(0.8,1.0,0.9);

 actor2 = new vtkActor;
   actor2->SetMapper(omapper);
   actor2->GetProperty()->SetColor(1,1,1);
 
  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);
 
  renWin->Render();

  iren->Start();

  return (0);

}
