// Homework 4
// hw4.C
// Mark Hulber
// Graphics & Visualization


#include "vtk.hh"
#include <assert.h>
#include "vtkCamera.hh"

main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1, *actor2;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mc;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  // define geometry of volume
  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(27,64,64);
    volume->SetOrigin(1,1,1);
    volume->SetAspectRatio(1,.5,.333333);

   short num;
   int i;
   FILE* infile;

   assert(infile = fopen("MRIdata.bin", "rb"));
     int numPts = 27 * 64 * 64;
     scalars = new vtkShortScalars(numPts);
     short* s = scalars->WritePtr(0, numPts);
     fread(s, sizeof(short), numPts, infile);
     fclose(infile);
    scalars->WrotePtr();

  volume->GetPointData()->SetScalars(scalars);

  mc = new vtkMarchingCubes;
    mc->DebugOn();
    mc->SetInput(volume);
    mc->SetValue(0, 225.0);

  mapper = new vtkPolyMapper;
    mapper->SetInput(mc->GetOutput());

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
    actor1->GetProperty()->SetColor(0.8,1.0,0.9);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;

    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);

   actor1->RotateX(180);   // Rotate so the face is 
   actor2->RotateX(180);  // Visible
   actor1->RotateY(30);
   actor2->RotateY(30);

  camera1 = new vtkCamera; 
   camera1->SetPosition(0, 200, 300);
   camera1->SetFocalPoint(1, 1, 1);
   camera1->CalcViewPlaneNormal();
   camera1->Zoom(4);

  light1 = new vtkLight;
  aren->AddLights(light1);
  aren->SetActiveCamera(camera1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.2,0.2,0.2);

  renWin->Render();

  // interact with data
  iren->Start();

  return EXIT_SUCCESS;
}
