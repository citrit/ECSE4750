/* ****************************************
   * Advanced Computer Graphics
   * Homework #4
   * 
   * Brent Chartrand
   ****************************************/

//Include the needed stuff...
//#include "vtk.hh" //Includes to much...

#include "vtkRenderMaster.hh"
#include "vtkContourFilter.hh"
#include "vtkPolyMapper.hh"
#include "vtkScalars.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkStructuredPointsReader.hh"
#include "vtkMarchingCubes.hh"
#include <iostream.h>
#include <fstream.h>

main ()
{
vtkRenderMaster rm;
vtkRenderWindow *rw=rm.MakeRenderWindow();
vtkRenderWindowInteractor *intact=rw->MakeRenderWindowInteractor();
vtkRenderer *aren=rw->MakeRenderer();
vtkCamera *acam;
vtkStructuredPoints *volume;
vtkFloatScalars *scalars;

	
//Read the data
vtkStructuredPointsReader *reader=new vtkStructuredPointsReader;
  reader->SetFilename("MRIdata.vtk");
//  reader->DebugOn();

//The vtkStructuredPointsReader seems to be faster and easier,
// So we'll use that.  This is here anyway  
/*
  //Open the file
  ifstream inf("MRIdata.bin");
    // define geometry of volume

  volume = new vtkStructuredPoints;
  volume->DebugOn();
  volume->SetDimensions(60, 60, 25);
  volume->SetOrigin(0.0, 0.0, 0.0);
  volume->SetAspectRatio(1,1,1);
 
  //Get the Data
  scalars = new vtkFloatScalars(dimx*dimy);
  for (int i=0;i<60*60*25;i++) {
    inf >> val;
    scalars->SetScalar(i, val);
  }
  volume->GetPointData()->SetScalars(scalars);
  vtkMarchingCubes *iso=new vtkMarchingCubes;
  iso->SetInput(volume->GetOutput());
*/

vtkMarchingCubes *iso=new vtkMarchingCubes;
  iso->SetInput(reader->GetOutput());
  iso->SetValue(0,255);
//  iso->DebugOn();
vtkPolyMapper *isoMapper=new vtkPolyMapper;	
  isoMapper->SetInput(iso->GetOutput());
  isoMapper->ScalarsVisibleOff();
vtkActor *isoActor=new vtkActor;
  isoActor-> SetMapper( isoMapper);
  isoActor->GetProperty()->SetColor(1,1,1.0);

vtkOutlineFilter *outline=new vtkOutlineFilter;
  outline->SetInput(reader->GetOutput());
vtkPolyMapper *outlineMapper=new vtkPolyMapper;
  outlineMapper->SetInput(outline->GetOutput());
vtkActor *outlineActor=new vtkActor;
  outlineActor-> SetMapper( outlineMapper);
  outlineActor-> GetProperty()->SetColor(1.0,1.0,1.0);

aren->AddActors(outlineActor);
aren->AddActors(isoActor);
/*
aren->SetBackground(.1,.2,.4);
acam->SetClippingRange( 19.1589, 957.946);
acam->SetFocalPoint( 33.7014, 26.706, 30.5867);
acam->SetPosition( 150.841, 89.374, -107.462);
acam->CalcViewPlaneNormal();
acam->SetViewUp( -0.190015, 0.944614, 0.267578);
aren->SetActiveCamera(acam);
*/
aren->AddLights(new vtkLight);
aren->SetBackground(0.0,0.0,0.0);
rw->Render();
intact->Start();
return 0;
}




