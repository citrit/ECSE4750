#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>

// hw4.C by Jakub Kucera

void main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renwin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1;
  vtkPolyMapper *mapper;
  vtkMarchingCubes *mc;
  vtkRenderWindowInteractor *rwi;
  vtkActor *actor;
  vtkStructuredPoints *points;
  vtkShortScalars *scalars;
  short val;
  
  points = new vtkStructuredPoints;
  points->DebugOn();
  points->SetDimensions(27,64, 64);
  points->SetOrigin(0.0, 0.0, 0.0);
  points->SetAspectRatio(1,1,1);
  scalars = new vtkShortScalars(64*64*27);
  ifstream inf("MRIdata.bin");
  for (int i=0;i<64*64*27;i++) {
    inf.read((char *)&val, sizeof(short));
    scalars->SetScalar(i, val);
  }
  points->GetPointData()->SetScalars(scalars);

  mc = new vtkMarchingCubes;
  mc->DebugOn();
  mc->SetInput(points);
  mc->GenerateValues(1, 225.0,225.0);

  renwin  = rm.MakeRenderWindow();
  rwi = renwin->MakeRenderWindowInteractor();
  aren    = renwin->MakeRenderer();

  mapper = new vtkPolyMapper;
  mapper->SetInput(mc->GetOutput());

  actor1 = new vtkActor;
  actor1->SetMapper(mapper);
  actor1->GetProperty()->SetColor(1.0,1.0,1.0);

  light1 = new vtkLight;
  camera1 = new vtkCamera;

  renwin->AddRenderers(aren);
  aren->AddLights(light1);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);

  renwin->Render();
  rwi->Start();
}
