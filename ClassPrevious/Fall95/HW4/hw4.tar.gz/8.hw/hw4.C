/*
	Homework 4
	Advanced Computer Graphics and Data Visualization
	By Alan Mortensen
	Date: 11/29/95
*/

#include "vtk.hh"
#include <iostream.h>
#include <fstream.h>

void main ()
{
	vtkRenderMaster rm;
	vtkRenderWindow *renwin;
	vtkRenderer	*aren;
	vtkRenderWindowInteractor *iren;
	vtkActor	*head;
	vtkStructuredPoints	*grid;
	vtkPolyMapper	*mapping;
	vtkMarchingCubes *march;
	vtkDecimate deci;
	vtkShortScalars	*data;
	int i,j,k;
	ifstream file;
	short point;

	file.open("MRIdata.bin",ios::in);

	/*Setup the rendering windows*/
	renwin=rm.MakeRenderWindow();
	iren=renwin->MakeRenderWindowInteractor();
	aren=renwin->MakeRenderer();

	/*Setup the structured points*/
	grid=new vtkStructuredPoints;
	grid->SetDimensions(27,64,64);

	/*Setup the Scalars and read them in from the binary file*/	
	data=new vtkShortScalars(110592);
	for(i=0;i<64;i++){
		for(j=0;j<64;j++){
			for(k=0;k<27;k++)
			{
				file.read((char *)&point,sizeof(point));
				data->InsertNextScalar(point);
			}
                }
        }	

	/*Add the Scalars to the Structured Points*/
	grid->GetPointData()->SetScalars(data);

	/*Setup the marching cubes process*/
	march=new vtkMarchingCubes;
	march->SetInput(grid);
	march->SetValue(0,225.0);

	/*Setup the decimator process*/
	deci.SetInput(march->GetOutput());
	deci.SetTargetReduction(0.9);
	deci.SetMaximumIterations(6);
	deci.SetMaximumSubIterations(2);
	deci.SetInitialError(0.001);
	deci.SetErrorIncrement(0.005);
	deci.SetAspectRatio(20.0);
	deci.SetInitialFeatureAngle(60.0);

	/*Setup the mapper*/
	mapping=new vtkPolyMapper;
	mapping->SetInput(deci.GetOutput());
	mapping->SetScalarsVisible(0);

	/*Setup the actor*/
	head=new vtkActor;
	head->SetMapper(mapping);
	head->GetProperty()->SetColor(0.0,1.0,0.0);

	/*Take care of details of the renderer and 
	  attach the actor to the renderer*/
	aren->AddActors(head);
	aren->SetBackground(0.0,0.0,0.0);
	
	/*Render the scene and start the interactor*/
	renwin->Render();
	iren->Start();
}
