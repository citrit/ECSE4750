#include "vtkContourFilter.hh"
#include "vtkMarchingCubes.hh"
#include "vtkOutlineFilter.hh"
#include "vtkPolyMapper.hh"
#include "vtkRenderMaster.hh"
#include "vtkRenderWindowInteractor.hh"
#include "vtkScalars.hh"
#include "vtkStructuredPointsReader.hh"
#include <iostream.h>
#include <fstream.h>


main ()
{
vtkRenderMaster rm;
vtkRenderWindow *renWin=rm.MakeRenderWindow();
vtkRenderWindowInteractor *iren=renWin->MakeRenderWindowInteractor();
vtkRenderer *ren1=renWin->MakeRenderer();

//
// create pipeline
//
vtkStructuredPointsReader *reader=new vtkStructuredPointsReader;
  reader->SetFilename("MRIdata.vtk");
//  reader->DebugOn();

vtkMarchingCubes *iso=new vtkMarchingCubes;
  iso->SetInput(reader->GetOutput());
  iso->SetValue(0,255);
//  iso->DebugOn();

vtkPolyMapper *isoMapper=new vtkPolyMapper;	
  isoMapper->SetInput(iso->GetOutput());
  isoMapper->ScalarsVisibleOff();

vtkActor *isoActor=new vtkActor;
  isoActor-> SetMapper(isoMapper);
  isoActor->GetProperty()->SetColor(1,1,1.0);

vtkOutlineFilter *outline=new vtkOutlineFilter;
  outline->SetInput(reader->GetOutput());

vtkPolyMapper *outlineMapper=new vtkPolyMapper;
  outlineMapper->SetInput(outline->GetOutput());

vtkActor *outlineActor=new vtkActor;
  outlineActor-> SetMapper( outlineMapper);
  outlineActor-> GetProperty()->SetColor(1.0,1.0,1.0);

ren1->AddActors(outlineActor);
ren1->AddActors(isoActor);
ren1->SetBackground(.1,.2,.4);

vtkCamera *cam1=new vtkCamera;

cam1->SetClippingRange( 19.1589, 957.946);
cam1->SetFocalPoint( 33.7014, 26.706, 30.5867);
cam1->SetPosition( 150.841, 89.374, -107.462);
cam1->CalcViewPlaneNormal();
cam1->SetViewUp( -0.190015, -0.944614, 0.267578);

ren1->SetActiveCamera(cam1);

renWin->Render();
iren->Start();
return 0;
}
