// Pramote Kuacharoen


// #include <stdio.h>
#include <stdlib.h>
// #include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

// #include "vtk.hh"
#include "vtkRenderMaster.hh"
#include "vtkContourFilter.hh"
#include "vtkPolyMapper.hh"
#include "vtkShortScalars.hh"
#include "vtkMarchingCubes.hh"
#include "vtkOutlineFilter.hh"
#include "vtkRenderWindowInteractor.hh"
#include <iostream.h>



#define W 27
#define L 64
#define H 64



void main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1;
  vtkActor    *actor1, *actor2;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *mc;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  float val, range[2];
  short int *data;
  int file, j;

  data = new short int[W*H*L];
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

// Read file
  file=open("MRIdata.bin",O_RDONLY);
  if(file==-1) {exit(1);}
  j=read(file,data,W*L*H*2);
  if(j!=W*L*H*2) {exit(2);}

  // define geometry of volume
  volume = new vtkStructuredPoints;
  volume->SetDimensions(W, L, H);
  volume->SetOrigin(0.0, 0.0, 0.0);
  volume->SetAspectRatio(1,1,1);

  scalars = new vtkShortScalars(W*L*H);
  for (int i=0;i<W*L*H;i++) 
    {
      scalars->SetScalar(i, data[W*L*H-i-1]);
    }
  volume->GetPointData()->SetScalars(scalars);


  mc = new vtkMarchingCubes;
  mc->SetInput(volume);
  range[0] = 225.0;range[1] = 2356.0;
//  mc->GenerateValues(50, range);
  mc->SetValue(0, 255.0);

  mapper = new vtkPolyMapper;
  mapper->SetInput(mc->GetOutput());
  mapper->ScalarsVisibleOff();

  actor1 = new vtkActor;
  actor1->SetMapper(mapper);
  actor1->GetProperty()->SetColor(0.95,0.95,0.95); 

  // draw an outline
  outline = new vtkOutlineFilter;
  outline->SetInput(volume);

  omapper = new vtkPolyMapper;
  omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
  actor2->SetMapper(omapper);
  actor2->GetProperty()->SetColor(1,1,1);

  light1 = new vtkLight;

  aren->AddLights(light1);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.0,0.0,0.0);
  renWin->Render();

  // interact with data
  iren->Start();
}







