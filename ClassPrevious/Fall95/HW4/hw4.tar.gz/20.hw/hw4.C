#include <stdio.h>
#include <assert.h>
#include "vtk.hh"

short pBuff[27*64*64];
main ()
{
  vtkRenderMaster rm;
  vtkRenderWindow *renWin;
  vtkRenderer *aren;
  vtkCamera   *camera1;
  vtkLight    *light1, *light2;
  vtkActor    *actor1, *actor2;
  vtkStructuredPoints *volume;
  vtkShortScalars *scalars;
  vtkMarchingCubes *cf;
  vtkCleanPolyData cd;
  vtkPolyMapper *mapper, *omapper;
  vtkOutlineFilter *outline;
  vtkRenderWindowInteractor *iren;
  vtkDecimate deci;
  
  renWin  = rm.MakeRenderWindow();
  iren = renWin->MakeRenderWindowInteractor();
  aren    = renWin->MakeRenderer();

  // define geometry of volume
  volume = new vtkStructuredPoints;
    volume->DebugOn();
    volume->SetDimensions(27,64,64);
    volume->SetOrigin(0,0,0);
    volume->SetAspectRatio(1.5,1,1);

  // define scalar values to contour
  scalars = new vtkShortScalars(27*64*64);
  short* pScalar = scalars->WritePtr(0,27*64*64);

  FILE *fp = fopen("MRIdata.bin","r+b");
  if (fp==NULL){
    cerr<<"MRIdata.bin file not found";
    exit(1);
  };
  fread(pBuff,sizeof(short),27*64*64,fp);
  fclose(fp);

  int i,j,k,ptr;
  short tmp;
  for(k=63,ptr=0;k>=0;k--)
    for(j=63;j>=0;j--)
      for(i=0;i<27;i++,ptr++)
	pScalar[ptr]=pBuff[i+j*27+k*27*64];
  
  volume->GetPointData()->SetScalars(scalars);

  cf = new vtkMarchingCubes;
    cf->DebugOn();
    cf->SetInput(volume);
    cf->SetValue(0, 225.0);

  cd.DebugOn();
  cd.SetTolerance(0.000);
  cd.SetInput(cf->GetOutput());

  deci.SetInput(cd.GetOutput());
  deci.SetTargetReduction(0.9);
  deci.SetMaximumIterations(10);
  deci.SetMaximumSubIterations(2);
  deci.SetInitialError(0.002);
  deci.SetErrorIncrement(0.002);
  deci.SetAspectRatio(20.0);
  deci.SetInitialFeatureAngle(30.0);
  deci.DebugOn();
  
  mapper = new vtkPolyMapper;
    mapper->SetInput(deci.GetOutput());
  mapper->ScalarsVisibleOff();

  actor1 = new vtkActor;
    actor1->SetMapper(mapper);
  actor1->GetProperty()->SetGouraud();
  actor1->GetProperty()->SetAmbientColor(1.0, 1.0, 1.0);
  actor1->GetProperty()->SetDiffuseColor(1.0, 1.0, 1.0);
  actor1->GetProperty()->SetSpecularColor(1.0, 1.0, 1.0);
  actor1->GetProperty()->SetAmbient(0.2);
  actor1->GetProperty()->SetDiffuse(0.5);
  actor1->GetProperty()->SetSpecular(0.1);

  //actor1->GetProperty()->SetColor(1,1,1);

  // draw an outline
  outline = new vtkOutlineFilter;
    outline->SetInput(volume);

  omapper = new vtkPolyMapper;
    omapper->SetInput(outline->GetOutput());

  actor2 = new vtkActor;
    actor2->SetMapper(omapper);
    actor2->GetProperty()->SetColor(1,1,1);

  light1 = new vtkLight;
  light1->SetPosition(-1.0, 1.0, -1.0);
  aren->AddLights(light1);
  light2 = new vtkLight;
  light2->SetPosition(2.0, 0.25, -1.0);
  light2->SetColor(0.5, 0.5, 0.5);
  aren->AddLights(light2);
  aren->AddActors(actor2);
  aren->AddActors(actor1);
  aren->SetBackground(0.2,0.2,0.2);

  renWin->Render();

  // interact with data
  iren->Start();

  return(0);
}
